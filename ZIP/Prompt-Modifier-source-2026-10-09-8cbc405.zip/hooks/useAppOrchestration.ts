
import React, { useCallback } from 'react';
import { Node, NodeType, Connection, Group, LibraryItem, Point, ToastType, ConnectingInfo } from '../types';
import { getEmptyValueForNodeType, getDuplicatedValueForNodeType, RATIO_INDICES, getOutputHandleType, getInputHandleType } from '../utils/nodeUtils';
import { generateThumbnail } from '../utils/imageUtils';
import { readPromptFromPNG } from '../utils/pngMetadata';
import { CARD_NODE_WIDTH_STEP, CARD_NODE_BASE_WIDTH_OFFSET } from './useEntityActions';
import { ContentCatalogItemType } from './useCatalog';

const getTimestamp = () => new Date().toISOString().replace(/:/g, '-').replace('T', '_').split('.')[0];

export const useAppOrchestration = (
    nodes: Node[],
    setNodes: React.Dispatch<React.SetStateAction<Node[]>>,
    connections: Connection[],
    setConnections: React.Dispatch<React.SetStateAction<Connection[]>>,
    groups: Group[],
    setGroups: React.Dispatch<React.SetStateAction<Group[]>>,
    fullSizeImageCache: Record<string, Record<number, string>>,
    setFullSizeImage: (nodeId: string, frameNumber: number, dataUrl: string) => void,
    getFullSizeImage: (nodeId: string, frameNumber: number) => string | undefined,
    getUpstreamNodeValues: (nodeId: string, handleId?: string, currentNodes?: Node[], optimizedForUI?: boolean) => any[],
    activeTabIdRef: React.MutableRefObject<string>,
    setSelectedNodeIds: React.Dispatch<React.SetStateAction<string[]>>,
    libraryHook: any,
    catalogHook: any,
    characterCatalogHook: any,
    scriptCatalogHook: any,
    sequenceCatalogHook: any,
    entityActionsHook: any,
    nodesHook: any,
    connectionsHook: any,
    canvasHook: any,
    geminiGenerationHook: any,
    addToast: (message: string, type?: ToastType) => void,
    setError: (error: string | null) => void,
    t: (key: string) => string,
    clearImagesForNodeFromCache: (nodeId: string) => void
) => {

    const handleDownloadImage = useCallback((nodeId: string, onDownloadImageFromUrl: (url: string, frameNumber: number, prompt: string) => void) => {
        const node = nodes.find(n => n.id === nodeId);
        if (!node) return;

        let imageUrl: string | undefined;
        let prompt = '';

        try {
            const parsed = JSON.parse(node.value || '{}');

            if (node.type === NodeType.IMAGE_OUTPUT || node.type === NodeType.VIDEO_OUTPUT) {
                imageUrl = getFullSizeImage(nodeId, 0) || (typeof parsed === 'string' ? parsed : (parsed.image || node.value));
                prompt = entityActionsHook.getPromptForNode(nodeId);
            } else if (node.type === NodeType.IMAGE_INPUT) {
                imageUrl = getFullSizeImage(nodeId, 0) || parsed.image;
                prompt = parsed.prompt || '';
            } else if (node.type === NodeType.IMAGE_EDITOR) {
                imageUrl = getFullSizeImage(nodeId, 0) || parsed.outputImage;
                prompt = parsed.prompt || '';
            } else if (node.type === NodeType.GEMINI_CHAT) {
                // EXPORT CHAT HISTORY
                const dataToSave = {
                    type: 'gemini-chat-history',
                    messages: parsed.messages || [],
                    currentInput: parsed.currentInput || '',
                    style: parsed.style || 'general',
                    attachment: parsed.attachment || null
                };

                const blob = new Blob([JSON.stringify(dataToSave, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                const timestamp = getTimestamp();
                a.download = `Gemini_Chat_History_${timestamp}.json`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                addToast(t('toast.scriptSaved'), 'success');
                return;
            }
        } catch (e) { 
            // Fallback for raw string values (Data URIs in ImageOutput often fail JSON.parse)
            if (node.type === NodeType.IMAGE_OUTPUT || node.type === NodeType.VIDEO_OUTPUT) {
                 imageUrl = getFullSizeImage(nodeId, 0) || node.value;
                 prompt = entityActionsHook.getPromptForNode(nodeId);
            } else if (node.type === NodeType.IMAGE_INPUT && node.value.startsWith('data:')) {
                 imageUrl = getFullSizeImage(nodeId, 0) || node.value;
            }
        }

        if (imageUrl) {
            onDownloadImageFromUrl(imageUrl, 0, prompt);
            addToast(t('toast.downloadStarted'), 'success');
        }
    }, [nodes, getFullSizeImage, entityActionsHook, addToast, t]);

    const handleDuplicateNode = useCallback((nodeId: string): string | undefined => {
        const nodeToDup = nodes.find(n => n.id === nodeId);
        if (!nodeToDup) return;

        // Increment counter via the ref from nodesHook
        if (nodesHook.nodeIdCounter) nodesHook.nodeIdCounter.current++;

        const newNodeId = `node-${nodesHook.nodeIdCounter.current}-${Date.now()}`;
        const newNode: Node = {
            ...nodeToDup,
            id: newNodeId,
            position: { x: nodeToDup.position.x + 30, y: nodeToDup.position.y + 30 },
            isNewlyCreated: true,
            value: getDuplicatedValueForNodeType(nodeToDup),
        };
        setNodes(nds => [...nds, newNode]);
        addToast(t('toast.nodeDuplicated'));
        return newNodeId;
    }, [nodes, nodesHook.nodeIdCounter, setNodes, addToast, t]);

    const handleDuplicateNodeWithContent = useCallback((nodeId: string): string | undefined => {
        const nodeToDup = nodes.find(n => n.id === nodeId);
        if (!nodeToDup) return;

        if (nodesHook.nodeIdCounter) nodesHook.nodeIdCounter.current++;
        const newNodeId = `node-${nodesHook.nodeIdCounter.current}-${Date.now()}`;
        const newNode: Node = {
            ...nodeToDup,
            id: newNodeId,
            position: { x: nodeToDup.position.x + 30, y: nodeToDup.position.y + 30 },
            isNewlyCreated: true,
            value: nodeToDup.value,
        };

        // Copy cache
        for (const i of Object.keys(fullSizeImageCache[nodeId] || {}).map(Number)) {
            const cachedImg = getFullSizeImage(nodeId, i);
            if (cachedImg) {
                setFullSizeImage(newNodeId, i, cachedImg);
            }
        }

        setNodes(nds => [...nds, newNode]);
        addToast(t('toast.nodeDuplicated'));
        return newNodeId;
    }, [nodes, nodesHook.nodeIdCounter, setNodes, addToast, t, getFullSizeImage, setFullSizeImage, fullSizeImageCache]);

    const copyNodeValue = useCallback((nodeId: string) => {
        return nodesHook.handleCopyNodeValue(nodeId);
    }, [nodesHook]);

    const pasteNodeValue = useCallback((nodeId: string) => {
        return nodesHook.handlePasteNodeValue(nodeId);
    }, [nodesHook]);

    const pasteImageToNode = useCallback((nodeId: string, imageFile?: File | null) => {
        return nodesHook.handlePasteImageToNode(nodeId, imageFile);
    }, [nodesHook]);

    const handlePaste = useCallback(async (selectedNodeIds: string[], pasteNodeValueFn: (nodeId: string) => Promise<boolean | string>, pasteImageToNodeFn: (nodeId: string, file?: File | null) => Promise<boolean | string>, canvasHook: any, entityActionsHook: any, nodesHook: any, isAlternativeMode?: boolean) => {
        let clipboardItems: any[] = [];
        try {
            clipboardItems = (await navigator.clipboard.read()) || [];
        } catch (e) {
            // Firefox or security restriction
        }
        
        // Check if there is an image in the clipboard
        const hasImage = clipboardItems.some(i => i.types.some((t: string) => t.startsWith('image/')));

        // Priority 1: Paste into Selected Node
        if (selectedNodeIds.length === 1 && !isAlternativeMode) {
            // If clipboard has image, try pasting image first
            if (hasImage) {
                const result = await pasteImageToNodeFn(selectedNodeIds[0]);
                if (!result) return; // Image paste handled successfully
            }
            
            // If no image or image paste failed/skipped (returned error string), try text paste
            const result = await pasteNodeValueFn(selectedNodeIds[0]);
            if (!result) return; // Paste handled successfully
            
            // If result is string (error/not handled), fall through to global paste
        }

        // Priority 2: Paste as new Node/Group/Image
        try {
            // Re-read clipboard inside loop to be safe or reuse if possible, but reading again ensures valid blob state
            const items = await navigator.clipboard.read(); 
            for (const item of items) {

                // Case A: Image -> Create Image Input
                if (item.types.some(t => t.startsWith('image/'))) {
                    const blob = await item.getType(item.types.find(t => t.startsWith('image/'))!);
                    const file = new File([blob], "pasted_image.png", { type: blob.type });

                    // Create new node at pointer center (or center of screen if pointer unavailable)
                    const pos = canvasHook.pointerPosition || { x: 0, y: 0 };
                    const newNodeId = entityActionsHook.onAddNode(NodeType.IMAGE_INPUT, pos);

                    // Populate
                    pasteImageToNodeFn(newNodeId, file);
                    return;
                }

                // Case B: Text/JSON -> Try to parse as Group/Node/Data
                if (item.types.includes('text/plain')) {
                    const text = await navigator.clipboard.readText();
                    try {
                        const json = JSON.parse(text);
                        const pos = canvasHook.pointerPosition || { x: 0, y: 0 };

                        // Paste Group/Nodes
                        if (json.type === 'prompModifierGroup' || (json.nodes && json.connections)) {
                            entityActionsHook.pasteGroup(json, pos);
                            return;
                        }

                        // Paste Image Input Node Data (Full Batch + Parameters + Images + Frames)
                        if (
                            json.type === 'image-input-data' ||
                            (typeof json === 'object' && json !== null && !Array.isArray(json) && ('framesConfig' in json || 'batchFiles' in json || 'grid' in json || ('image' in json && ('cropRect' in json || 'batchConfig' in json || 'extractedImages' in json || 'fullSizeImage' in json))))
                        ) {
                            const title = json.nodeTitle || t('node.title.image_input') || 'Image Input';
                            const newNodeId = entityActionsHook.onAddNode(NodeType.IMAGE_INPUT, pos, title);

                            // 1. Process and restore main image to cache slot 0
                            const mainImg = json.fullSizeImage || json.image || (json.batchFiles?.[0]?.dataUrl) || null;
                            let mainThumbnail = json.image || null;

                            if (mainImg && typeof mainImg === 'string' && mainImg.startsWith('data:')) {
                                setFullSizeImage(newNodeId, 0, mainImg);
                                try {
                                    mainThumbnail = await generateThumbnail(mainImg, 256, 256);
                                } catch {
                                    mainThumbnail = mainImg;
                                }
                            }

                            // 2. Restore high-res slices to cache
                            if (json.slices && typeof json.slices === 'object') {
                                Object.entries(json.slices).forEach(([frame, sliceUrl]) => {
                                    if (typeof sliceUrl === 'string' && sliceUrl.startsWith('data:')) {
                                        setFullSizeImage(newNodeId, Number(frame), sliceUrl);
                                    }
                                });
                            }

                            // 3. Process batch files & thumbnails
                            const restoredBatchFiles: any[] = [];
                            const incomingBatch = Array.isArray(json.batchFiles) ? json.batchFiles : [];
                            for (let i = 0; i < incomingBatch.length; i++) {
                                const item = incomingBatch[i];
                                let itemThumb = item.thumbnailUrl;
                                if (!itemThumb && item.dataUrl && typeof item.dataUrl === 'string' && item.dataUrl.startsWith('data:')) {
                                    try {
                                        itemThumb = await generateThumbnail(item.dataUrl, 128, 128);
                                    } catch {
                                        itemThumb = item.dataUrl;
                                    }
                                }
                                restoredBatchFiles.push({
                                    id: item.id || `batch-${Date.now()}-${i}-${Math.random().toString(36).substr(2, 7)}`,
                                    name: item.name || `image_${i + 1}.png`,
                                    dataUrl: item.dataUrl || itemThumb || mainImg,
                                    thumbnailUrl: itemThumb || item.dataUrl,
                                    width: item.width,
                                    height: item.height,
                                    size: item.size,
                                    cropRect: item.cropRect,
                                    gridConfig: item.gridConfig
                                });
                            }

                            // 4. Build node value
                            const nodeValue = JSON.stringify({
                                image: mainThumbnail,
                                prompt: json.prompt || '',
                                mode: json.mode || (json.framesConfig ? 'frames' : (restoredBatchFiles.length > 0 ? 'batch' : (json.grid ? 'grid' : (json.cropRect ? 'single' : 'full')))),
                                cropRect: json.cropRect || null,
                                croppedImage: json.croppedImage || null,
                                grid: json.grid || { cols: 2, rows: 1, bounds: { x: 0, y: 0, width: 1, height: 1 } },
                                framesConfig: json.framesConfig || null,
                                frameImages: json.frameImages || [],
                                batchConfig: json.batchConfig || { subMode: 'crop', includeOriginal: true, assetName: 'Asset_Name' },
                                batchFiles: restoredBatchFiles,
                                extractedImages: json.extractedImages || [],
                                showSlicesDrawer: json.showSlicesDrawer ?? true,
                                showControls: json.showControls ?? false
                            });

                            nodesHook.handleValueChange(newNodeId, nodeValue);

                            if (setNodes && (json.width || json.height)) {
                                setNodes((nds: Node[]) => nds.map(n => n.id === newNodeId ? {
                                    ...n,
                                    width: json.width || n.width,
                                    height: json.height || n.height
                                } : n));
                            }

                            addToast(t('toast.pastedFromClipboard'));
                            return;
                        }

                        // Paste Script Analyzer Data (Script Viewer Node)
                        if (json.type === 'script-analyzer-data' || (json.scenes && Array.isArray(json.scenes) && json.scenes[0]?.frames)) {
                            const newNodeId = entityActionsHook.onAddNode(NodeType.SCRIPT_VIEWER, pos);
                            nodesHook.handleValueChange(newNodeId, text);
                            addToast(t('toast.pastedFromClipboard'));
                            return;
                        }

                        // Paste Script Prompt Modifier Data (Finalizer format)
                        if (json.type === 'script-prompt-modifier-data' || (json.finalPrompts && Array.isArray(json.finalPrompts))) {

                            const promptsToLoad = json.finalPrompts || json.prompts || [];
                            const videoPromptsToLoad = json.videoPrompts || [];
                            const videoMap = new Map(videoPromptsToLoad.map((vp: any) => [vp.frameNumber, vp]));

                            const sourcePrompts = promptsToLoad.map((p: any, i: number) => {
                                const frameNum = p.frameNumber !== undefined ? p.frameNumber : i + 1;
                                const vData: any = videoMap.get(frameNum);

                                let characters = p.characters || [];
                                const promptText = p.prompt || '';
                                if (characters.length === 0 && promptText) {
                                    const foundTags = promptText.match(/(?:character|entity)-\d+/gi) || [];
                                    characters = [...new Set(foundTags.map((t: string) => t.toLowerCase().replace(/character-/i, 'Entity-').replace(/entity-/i, 'Entity-')))];
                                }

                                return {
                                    frameNumber: frameNum,
                                    sceneNumber: p.sceneNumber || 1,
                                    sceneTitle: p.sceneTitle || '',
                                    prompt: promptText,
                                    videoPrompt: vData?.videoPrompt || p.videoPrompt || '',
                                    shotType: p.shotType || p.ShotType || vData?.shotType || 'WS',
                                    characters: characters,
                                    duration: p.duration || 3,
                                    isCollapsed: true
                                };
                            });

                            const emptyNodeForValue = { id: '', type: NodeType.PROMPT_SEQUENCE_EDITOR, position: { x: 0, y: 0 }, title: '', value: '', width: 0, height: 0 };
                            const emptyValue = getEmptyValueForNodeType(emptyNodeForValue as any);
                            const parsedEmptyValue = JSON.parse(emptyValue);

                            const nodeValue = JSON.stringify({
                                ...parsedEmptyValue,
                                instruction: '',
                                sourcePrompts: sourcePrompts,
                                modifiedPrompts: [],
                                checkedSourceFrameNumbers: [],
                                selectedFrameNumber: null,
                                styleOverride: json.visualStyle || json.styleOverride || '',
                                usedCharacters: json.usedCharacters || [],
                                sceneContexts: json.sceneContexts || {},
                                leftPaneRatio: 0.5
                            });

                            const newNodeId = entityActionsHook.onAddNode(NodeType.PROMPT_SEQUENCE_EDITOR, pos);
                            nodesHook.handleValueChange(newNodeId, nodeValue);
                            addToast(t('toast.pastedFromClipboard'));
                            return;
                        }

                        // Paste Character Card (Array or Single)
                        let charCards = null;
                        if (json.type === 'character-card') {
                            charCards = [json];
                        } else if (Array.isArray(json) && (json[0]?.imageSources || json[0]?.type === 'character-card')) {
                            charCards = json;
                        }

                        if (charCards) {
                            const title = charCards[0].nodeTitle || charCards[0].title || (Array.isArray(json) ? "Character Cards" : "Character Card");
                            const newNodeId = entityActionsHook.onAddNode(NodeType.CHARACTER_CARD, pos, title);

                            // Restore images to cache
                            charCards.forEach((char: any, i: number) => {
                                if (char.imageSources) {
                                    Object.entries(char.imageSources).forEach(([ratio, src]) => {
                                        const index = RATIO_INDICES[ratio];
                                        if (index !== undefined && typeof src === 'string' && src.startsWith('data:')) {
                                            setFullSizeImage(newNodeId, (i * 10) + index, src);
                                        }
                                    });
                                    const activeRatio = char.selectedRatio || '1:1';
                                    const activeSrc = (char.imageSources as any)[activeRatio];
                                    if (activeSrc && typeof activeSrc === 'string' && activeSrc.startsWith('data:')) {
                                        setFullSizeImage(newNodeId, i * 10, activeSrc);
                                    }
                                }
                            });

                            // Set Node Value
                            nodesHook.handleValueChange(newNodeId, JSON.stringify(charCards));

                            // Resize if needed
                            if (setNodes) {
                                const targetWidth = (charCards.length * CARD_NODE_WIDTH_STEP) + CARD_NODE_BASE_WIDTH_OFFSET;
                                setNodes((nds: Node[]) => nds.map(n => n.id === newNodeId ? { ...n, width: targetWidth } : n));
                            }
                            return;
                        }

                        // Paste Note Data (Full Note Node with References / Text / Styles)
                        if (
                            json.type === 'note-data' ||
                            (typeof json === 'object' && json !== null && !Array.isArray(json) && ('references' in json || ('text' in json && 'activeTab' in json)))
                        ) {
                            const title = json.nodeTitle || 'Note';
                            const newNodeId = entityActionsHook.onAddNode(NodeType.NOTE, pos, title);

                            const incomingRefs = Array.isArray(json.references) ? json.references : [];
                            const processedRefs: any[] = [];

                            for (let i = 0; i < incomingRefs.length; i++) {
                                const ref = incomingRefs[i];
                                const imgSrc = ref.image;
                                let thumb = imgSrc;
                                if (imgSrc && typeof imgSrc === 'string' && imgSrc.startsWith('data:')) {
                                    setFullSizeImage(newNodeId, i, imgSrc);
                                    try {
                                        thumb = await generateThumbnail(imgSrc, 256, 256);
                                    } catch {
                                        thumb = imgSrc;
                                    }
                                }
                                processedRefs.push({
                                    id: ref.id || `ref-${Date.now()}-${i}`,
                                    image: thumb,
                                    caption: ref.caption || ''
                                });
                            }

                            const noteValue = JSON.stringify({
                                text: json.text || '',
                                references: processedRefs,
                                activeTab: json.activeTab || (processedRefs.length > 0 ? 'reference' : 'note'),
                                style: json.style || { fontSize: 14, color: '#ffffff', isBold: false, isItalic: false, textAlign: 'left' },
                                isMinimal: json.isMinimal || false
                            });

                            nodesHook.handleValueChange(newNodeId, noteValue);
                            addToast(t('toast.pastedFromClipboard'));
                            return;
                        }

                        // Paste Array of References as Note Node (if not character-card)
                        if (Array.isArray(json) && json.length > 0 && (json[0]?.image !== undefined || json[0]?.caption !== undefined) && json[0]?.type !== 'character-card' && !json[0]?.imageSources) {
                            const title = 'Note References';
                            const newNodeId = entityActionsHook.onAddNode(NodeType.NOTE, pos, title);
                            const processedRefs: any[] = [];

                            for (let i = 0; i < json.length; i++) {
                                const ref = json[i];
                                const imgSrc = ref.image || ref.src;
                                let thumb = imgSrc;
                                if (imgSrc && typeof imgSrc === 'string' && imgSrc.startsWith('data:')) {
                                    setFullSizeImage(newNodeId, i, imgSrc);
                                    try {
                                        thumb = await generateThumbnail(imgSrc, 256, 256);
                                    } catch {
                                        thumb = imgSrc;
                                    }
                                }
                                processedRefs.push({
                                    id: `ref-${Date.now()}-${i}`,
                                    image: thumb,
                                    caption: ref.caption || ref.prompt || ''
                                });
                            }

                            const noteValue = JSON.stringify({
                                text: '',
                                references: processedRefs,
                                activeTab: 'reference',
                                style: { fontSize: 14, color: '#ffffff', isBold: false, isItalic: false, textAlign: 'left' },
                                isMinimal: false
                            });

                            nodesHook.handleValueChange(newNodeId, noteValue);
                            addToast(t('toast.pastedFromClipboard'));
                            return;
                        }

                    } catch {
                        // Not JSON, just text -> New Note or Text Input
                        // If in alternative mode (e.g. Ctrl+Shift+V), maybe do something else?
                        // Default: Create Text Input
                        const pos = canvasHook.pointerPosition || { x: 0, y: 0 };
                        const newNodeId = entityActionsHook.onAddNode(NodeType.TEXT_INPUT, pos);
                        nodesHook.handleValueChange(newNodeId, text);
                        addToast(t('toast.pastedFromClipboard'));
                        return;
                    }
                }
            }
        } catch (e) {
            // Clipboard read failed or denied or simple fallback
            // Try standard text read if navigator.clipboard.read() fails
             try {
                const text = await navigator.clipboard.readText();
                if(text) {
                     const pos = canvasHook.pointerPosition || { x: 0, y: 0 };
                     const newNodeId = entityActionsHook.onAddNode(NodeType.TEXT_INPUT, pos);
                     nodesHook.handleValueChange(newNodeId, text);
                     addToast(t('toast.pastedFromClipboard'));
                }
             } catch(e2) {
                 console.warn("Paste failed or permission denied", e);
             }
        }
    }, [addToast, t, setFullSizeImage, setNodes]);

    const handleAddGroupFromCatalog = useCallback((itemId: string, position?: Point) => {
        const item = catalogHook.catalogItems.find((i: any) => i.id === itemId);
        if (!item || !item.nodes) return;

        const pos = position || canvasHook.pointerPosition || { x: 0, y: 0 };
        const data = {
            type: 'prompModifierGroup',
            name: item.name,
            nodes: item.nodes,
            connections: item.connections || [],
            fullSizeImages: item.fullSizeImages
        };

        entityActionsHook.pasteGroup(data, pos);
    }, [catalogHook.catalogItems, canvasHook.pointerPosition, entityActionsHook]);

    const handleAddNodeAndConnect = useCallback((nodeType: NodeType, info: { position: Point, connectingInfo: ConnectingInfo }, onClose: () => void) => {
        const { position, connectingInfo } = info;
        const { scale, translate } = canvasHook.viewTransform;

        const worldPos = {
            x: (position.x - translate.x) / scale,
            y: (position.y - translate.y) / scale
        };

        // Use alignToInput: true to place node to the right of cursor (x = cursor.x) and vertically centered
        const newNodeId = entityActionsHook.onAddNode(nodeType, worldPos, undefined, { alignToInput: true });

        // Auto-connect
        const targetNode = nodes.find(n => n.id === newNodeId); // It won't be in 'nodes' yet due to closure, but we know its ID
        
        let targetHandleId: string | undefined = undefined;
        // Logic similar to useConnectionHandling but streamlined for creation
        if (connectingInfo.fromType === 'image') {
            if (nodeType === NodeType.IMAGE_INPUT) targetHandleId = 'image';
            if (nodeType === NodeType.IMAGE_EDITOR) targetHandleId = 'image';
            if (nodeType === NodeType.THREE_D_GENERATOR) targetHandleId = 'image';
            if (nodeType === NodeType.IMAGE_ANALYZER) targetHandleId = 'image';
            if (nodeType === NodeType.IMAGE_OUTPUT) targetHandleId = undefined;
            if (nodeType === NodeType.VIDEO_EDITOR) targetHandleId = 'image';
        } else if (connectingInfo.fromType === 'text') {
            if (nodeType === NodeType.IMAGE_INPUT) targetHandleId = 'text';
            if (nodeType === NodeType.IMAGE_EDITOR) targetHandleId = 'text';
            if (nodeType === NodeType.THREE_D_GENERATOR) targetHandleId = 'text';
            if (nodeType === NodeType.GEMINI_CHAT) targetHandleId = undefined; // Chat accepts text on main
            if (nodeType === NodeType.PROMPT_PROCESSOR) targetHandleId = undefined;
            if (nodeType === NodeType.PROMPT_ANALYZER) targetHandleId = undefined;
            if (nodeType === NodeType.VIDEO_PROMPT_PROCESSOR) targetHandleId = undefined;
            if (nodeType === NodeType.TRANSLATOR) targetHandleId = undefined;
            if (nodeType === NodeType.IMAGE_OUTPUT) targetHandleId = undefined;
            if (nodeType === NodeType.IMAGE_SEQUENCE_GENERATOR) targetHandleId = 'prompt_input';
            if (nodeType === NodeType.PROMPT_SEQUENCE_EDITOR) targetHandleId = 'prompts_sequence';
            if (nodeType === NodeType.NOTE) targetHandleId = 'prompt_data';
        } else if (connectingInfo.fromType === 'character_data') {
            if (nodeType === NodeType.IMAGE_SEQUENCE_GENERATOR) targetHandleId = 'character_data';
        } else if (connectingInfo.fromType === 'video') {
            if (nodeType === NodeType.VIDEO_EDITOR) targetHandleId = 'video';
        } else if (connectingInfo.fromType === 'audio') {
            if (nodeType === NodeType.VIDEO_EDITOR) targetHandleId = 'audio';
        }

        // Generic fallback for Data Reader / Reroute
        if (nodeType === NodeType.DATA_READER || nodeType === NodeType.REROUTE_DOT) targetHandleId = undefined;

        // Apply coloring for Reroute Dot
        if (nodeType === NodeType.REROUTE_DOT) {
            nodesHook.handleValueChange(newNodeId, JSON.stringify({ type: connectingInfo.fromType, direction: 'LR' }));
        }

        connectionsHook.addConnection({
            fromNodeId: connectingInfo.fromNodeId,
            fromHandleId: connectingInfo.fromHandleId,
            toNodeId: newNodeId,
            toHandleId: targetHandleId
        });

        onClose();
    }, [entityActionsHook, connectionsHook, nodes, canvasHook.viewTransform, nodesHook]);

    const onSaveMediaToDisk = useCallback((nodeId: string) => {
        const node = nodes.find(n => n.id === nodeId);
        if (!node) return;

        try {
            const parsed = JSON.parse(node.value || '{}');
            if (parsed.src) {
                // If it's a blob/data URL, try to download
                const link = document.createElement('a');
                link.href = parsed.src;
                // Try to infer name/ext
                let name = parsed.name || 'media_file';
                if (!name.includes('.')) {
                    if (parsed.type === 'video') name += '.mp4';
                    else name += '.mp3';
                }
                link.download = name;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                addToast(t('toast.downloadStarted'), 'success');
            }
        } catch {
            setError("Failed to save media.");
        }
    }, [nodes, addToast, t, setError]);

    const handleDetachAndPasteConcept = useCallback((sequenceNodeId: string, conceptToPaste: any) => {
        const sourceNode = nodes.find(n => n.id === sequenceNodeId);
        const position = sourceNode 
            ? { x: sourceNode.position.x + sourceNode.width + 50, y: sourceNode.position.y } 
            : { x: 0, y: 0 };
            
        const newNodeId = entityActionsHook.onAddNode(NodeType.CHARACTER_CARD, position, conceptToPaste.name);
        
        // Prioritize full resolution image from cache if available (attached in useDerivedMemo/useSequenceNode)
        const imageToUse = conceptToPaste._fullResImage || conceptToPaste.image;

        const cardData = [{
            id: `char-card-${Date.now()}`,
            name: conceptToPaste.name || 'New Entity',
            index: conceptToPaste.index || 'Entity-1',
            image: imageToUse,
            thumbnails: { '1:1': imageToUse, '16:9': null, '9:16': null },
            selectedRatio: '1:1',
            prompt: conceptToPaste.prompt || '',
            fullDescription: conceptToPaste.fullDescription || '',
            isOutput: true,
            isActive: true
        }];
        
        // Set Full Resolution Cache for new node
        if (imageToUse && imageToUse.startsWith('data:')) {
             setFullSizeImage(newNodeId, 0, imageToUse);
             setFullSizeImage(newNodeId, 1, imageToUse); 
        }

        nodesHook.handleValueChange(newNodeId, JSON.stringify(cardData));
        addToast(t('toast.pastedFromClipboard'), 'success');
    }, [nodes, entityActionsHook, setFullSizeImage, addToast, t, nodesHook]);

    const onDetachImageToNode = useCallback((imageDataUrl: string, sourceNodeId: string) => {
        const sourceNode = nodes.find(n => n.id === sourceNodeId);
        const position = sourceNode 
            ? { x: sourceNode.position.x + sourceNode.width + 50, y: sourceNode.position.y } 
            : { x: 0, y: 0 };
            
        const newNodeId = entityActionsHook.onAddNode(NodeType.IMAGE_INPUT, position);
        
        setFullSizeImage(newNodeId, 0, imageDataUrl);
        generateThumbnail(imageDataUrl, 256, 256).then(thumb => {
             nodesHook.handleValueChange(newNodeId, JSON.stringify({ image: thumb, prompt: '' }));
        });
        
        addToast(t('toast.pastedFromClipboard'), 'success');
    }, [nodes, entityActionsHook, setFullSizeImage, addToast, t, nodesHook]);

    const handleDetachCharacterFromGenerator = useCallback((characterData: any, generatorNode: Node) => {
        const pos = { x: generatorNode.position.x + generatorNode.width + 400, y: generatorNode.position.y };

        const newNodeId = entityActionsHook.onAddNode(NodeType.CHARACTER_CARD, pos, characterData.name || t('node.title.character_card'));

        const normalizedIndex = (characterData.index || characterData.alias || 'Entity-1').replace(/^Character-/, 'Entity-');

        const imageSources: Record<string, string | null> = {};
        if (characterData.imageBase64 && !characterData.imageBase64.startsWith('data:')) {
            const dataUrl = `data:image/png;base64,${characterData.imageBase64}`;
            imageSources['1:1'] = dataUrl;
            if (setFullSizeImage) {
                setFullSizeImage(newNodeId, 0, dataUrl);
            }
        } else if (characterData.imageBase64 && characterData.imageBase64.startsWith('data:')) {
            imageSources['1:1'] = characterData.imageBase64;
            if (setFullSizeImage) {
                setFullSizeImage(newNodeId, 0, characterData.imageBase64);
            }
        }

        const cardPayload = [{
            type: 'character-card',
            id: `char-card-${Date.now()}`,
            name: characterData.name || 'New Entity',
            index: normalizedIndex,
            imageSources: imageSources,
            selectedRatio: '1:1',
            prompt: characterData.prompt || '',
            fullDescription: characterData.fullDescription || '',
            additionalPrompt: characterData.additionalPrompt,
            isOutput: true,
            isActive: true,
            isPromptCollapsed: true
        }];

        nodesHook.handleValueChange(newNodeId, JSON.stringify(cardPayload));

        if (nodesHook.handleRenameNode && characterData.name) {
            nodesHook.handleRenameNode(newNodeId, characterData.name);
        }

        addToast(t('toast.characterDetached') || "Character detached", 'success');
    }, [entityActionsHook, nodesHook, setFullSizeImage, addToast, t]);
    
    const onSaveCharacterToCatalog = useCallback((nodeId: string, cardIndex?: number) => {
        const node = nodes.find(n => n.id === nodeId);
        if (!node || node.type !== NodeType.CHARACTER_CARD) return;

        try {
            let characters = JSON.parse(node.value || '[]');
            if (!Array.isArray(characters)) characters = [characters];
            
            // If cardIndex is undefined, SAVE ALL CHARACTERS as a single item
            if (cardIndex === undefined) {
                 const allDataToSave = characters.map((char: any, i: number) => {
                     // Resolve images for each character
                     const fullSources: Record<string, string | null> = { ...(char.thumbnails || char.imageSources || {}) };
                     Object.entries(RATIO_INDICES).forEach(([ratio, index]) => {
                        const fullRes = getFullSizeImage(nodeId, (i * 10) + index);
                        if (fullRes) fullSources[ratio] = fullRes;
                     });
                     
                     // Get active image
                     const activeImg = getFullSizeImage(nodeId, i * 10) || char.image;

                     // Return formatted character object
                     return {
                        id: char.id || `char-${Date.now()}-${i}`,
                        type: 'character-card',
                        name: char.name,
                        index: char.index,
                        image: activeImg,
                        imageSources: fullSources,
                        prompt: char.prompt,
                        fullDescription: char.fullDescription,
                        selectedRatio: char.selectedRatio,
                        additionalPrompt: char.additionalPrompt,
                        // Persist other states if needed
                        isActive: char.isActive
                     };
                 });
                 
                 const collectionName = node.title || 'Character Collection';
                 
                 // Save the entire array to the catalog
                 characterCatalogHook.createItem(
                     ContentCatalogItemType.ITEM, 
                     collectionName, 
                     JSON.stringify(allDataToSave)
                 );
                 addToast(t('toast.characterSavedCatalog') + " (All)", 'success');
                 
            } else {
                 // Existing Logic: Save SPECIFIC card
                 const char = characters[cardIndex];
                 if (!char) return;
                 
                 // Resolve images
                 const fullSources: Record<string, string | null> = { ...char.thumbnails };
                 Object.entries(RATIO_INDICES).forEach(([ratio, index]) => {
                    const fullRes = getFullSizeImage(nodeId, (cardIndex * 10) + index);
                    if (fullRes) fullSources[ratio] = fullRes;
                 });
                 const activeImg = getFullSizeImage(nodeId, cardIndex * 10) || char.image;

                 const dataToSave = {
                    type: 'character-card',
                    name: char.name,
                    index: char.index,
                    image: activeImg,
                    imageSources: fullSources,
                    prompt: char.prompt,
                    fullDescription: char.fullDescription,
                    selectedRatio: char.selectedRatio,
                    additionalPrompt: char.additionalPrompt
                 };
                 
                 characterCatalogHook.createItem(ContentCatalogItemType.ITEM, char.name || 'New Character', JSON.stringify(dataToSave));
                 addToast(t('toast.characterSavedCatalog'), 'success');
            }
        } catch (e) {
            console.error("Failed to save character to catalog", e);
             addToast("Failed to save to catalog", 'error');
        }
    }, [nodes, characterCatalogHook, getFullSizeImage, addToast, t]);

    return {
        handleDownloadImage,
        handleDuplicateNode,
        handleDuplicateNodeWithContent,
        copyNodeValue,
        pasteNodeValue,
        pasteImageToNode,
        handlePaste,
        handleAddGroupFromCatalog,
        handleAddNodeAndConnect,
        onSaveMediaToDisk,
        handleDetachCharacterFromGenerator,
        handleDetachAndPasteConcept,
        onDetachImageToNode,
        onSaveCharacterToCatalog // Export the updated function
    };
};
