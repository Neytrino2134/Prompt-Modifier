




import { useState, useCallback, useRef } from 'react';
import { generateImage } from '../../services/geminiService';
import { generateThumbnail, formatImageForAspectRatio, cropImageTo169 } from '../../utils/imageUtils';
import { addMetadataToPNG } from '../../utils/pngMetadata';
import { GeminiGenerationCommonProps } from './types';
import { resolveImageEditorModel, isNanoBanana21Model } from '../../services/modelConfig';
import { notifyImageEditorSuccess } from '../../services/trayNotificationService';

// Helper for local download triggering within the hook
const triggerDownload = (url: string, prompt: string, frameNumber: number = 0) => {
    let assetUrl = url;
    if (url.startsWith('data:image/png')) {
        assetUrl = addMetadataToPNG(url, 'prompt', prompt);
    }
    
    const link = document.createElement('a');
    link.href = assetUrl;
    
    const now = new Date();
    const date = now.toISOString().split('T')[0];
    const time = now.toTimeString().split(' ')[0].replace(/:/g, '-');
    const paddedFrame = String(frameNumber).padStart(3, '0');
    const filename = `Image_${paddedFrame}_${date}_${time}.png`;
    
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};

// Helper to make the promise cancellable via AbortSignal
const raceWithAbort = <T>(promise: Promise<T>, signal: AbortSignal): Promise<T> => {
    return Promise.race([
        promise,
        new Promise<T>((_, reject) => {
            if (signal.aborted) {
                reject(new DOMException('Aborted', 'AbortError'));
            }
            const onAbort = () => {
                signal.removeEventListener('abort', onAbort);
                reject(new DOMException('Aborted', 'AbortError'));
            };
            signal.addEventListener('abort', onAbort);
        })
    ]);
};

export const useEditorNode = ({
    nodes,
    getUpstreamNodeValues,
    setError,
    t,
    registerOperation,
    unregisterOperation,
    updateNodeInStorage,
    getFullSizeImage,
    activeTabId,
    activeTabName,
    activeTabIdRef,
    addToHistory,
    taskQueue,
    batchManager
}: GeminiGenerationCommonProps) => {
    const [isEditingImageLocal, setIsEditingImageLocal] = useState<boolean>(false);
    const [isStoppingEdit, setIsStoppingEdit] = useState(false);
    const abortControllerRef = useRef<AbortController | null>(null);

    const isEditingImage = useCallback((nodeId?: string) => {
        if (nodeId && taskQueue) {
            return taskQueue.isTaskRunningForNode(nodeId);
        }
        return isEditingImageLocal;
    }, [taskQueue, isEditingImageLocal]);

    const handleEditImage = useCallback(async (nodeId: string, indicesToProcess?: number[]) => {
        const currentTabId = activeTabIdRef.current;
        const node = nodes.find(n => n.id === nodeId);
        if (!node) return;

        const parsed = JSON.parse(node.value || '{}');
        const effectiveModel = resolveImageEditorModel(parsed.model);
        const isSequenceMode = parsed.isSequenceMode;

        // Gather Inputs A
        const textInputs = [
            ...getUpstreamNodeValues(nodeId, 'text'),
            ...getUpstreamNodeValues(nodeId, 'all_data')
        ].filter(v => typeof v === 'string') as string[];
        const imageInputs = getUpstreamNodeValues(nodeId, 'image').filter(v => typeof v === 'object') as { base64ImageData: string, mimeType: string }[];
        
        // Gather Inputs B (for sequence combination)
        const imageInputsB = getUpstreamNodeValues(nodeId, 'image_b').filter(v => typeof v === 'object') as { base64ImageData: string, mimeType: string }[];

        // --- NEW: Parse Upstream Prompts (from Sequence Editor) ---
        const upstreamPromptMap = new Map<number, string>(); // Key: FrameIndex (0-based)
        textInputs.forEach(text => {
            try {
                const json = JSON.parse(text);
                let prompts = [];
                
                if (json.sourcePrompts || json.modifiedPrompts) {
                    const source = json.sourcePrompts || [];
                    const mod = json.modifiedPrompts || [];
                    
                    const mergedPromptsMap = new Map();
                    source.forEach((p: any) => mergedPromptsMap.set(p.frameNumber, p));
                    mod.forEach((p: any) => mergedPromptsMap.set(p.frameNumber, { ...mergedPromptsMap.get(p.frameNumber), ...p }));
                    
                    prompts = Array.from(mergedPromptsMap.values());
                } 
                else if (json.type === 'script-prompt-modifier-data') {
                    prompts = json.finalPrompts || json.prompts || [];
                } else if (json.type === 'multiview-batch-data') {
                    prompts = json.finalPrompts || json.prompts || json.items || [];
                } else if (Array.isArray(json)) {
                    prompts = json;
                }
                
                if (prompts.length > 0) {
                    prompts.forEach((p: any, i: number) => {
                        const frameIdx = (p.frameNumber !== undefined ? p.frameNumber : (p.index !== undefined ? p.index : i + 1)) - 1;
                        const promptText = typeof p === 'string' ? p : (p.prompt || p.text || '');
                        if (promptText) upstreamPromptMap.set(frameIdx, promptText);
                    });
                }
            } catch {
                // Regular string, handled as global prompt part later
            }
        });

        // Prepare local inputs A
        const missingA = (parsed.inputImages || []).some((preview: string, index: number) => preview && !getFullSizeImage(node.id, index + 1));
        const missingB = (parsed.inputImagesB || []).some((preview: string, index: number) => preview && !getFullSizeImage(node.id, 2001 + index));
        if (missingA || missingB) {
            setError('Original input images are unavailable. Reimport the source images; previews cannot be used for server processing.');
            return;
        }
        const localImages = (parsed.inputImages || []).map((thumbnailUrl: string, index: number) => {
             const fullRes = getFullSizeImage(node.id, index + 1);
             const imgDataUrl = fullRes;
             if (!imgDataUrl || typeof imgDataUrl !== 'string') return null;
             const parts = imgDataUrl.includes(',') ? imgDataUrl.split(',') : ['', imgDataUrl];
             return {
                 base64ImageData: parts[1] || parts[0],
                 mimeType: imgDataUrl.match(/:(.*?);/)?.[1] || 'image/png'
             };
        }).filter(Boolean) as { base64ImageData: string; mimeType: string }[];
        
        // Prepare local inputs B
        const localImagesB = (parsed.inputImagesB || []).map((thumbnailUrl: string, index: number) => {
             const fullRes = getFullSizeImage(node.id, 2000 + index + 1); 
             const imgDataUrl = fullRes;
             if (!imgDataUrl || typeof imgDataUrl !== 'string') return null;
             const parts = imgDataUrl.includes(',') ? imgDataUrl.split(',') : ['', imgDataUrl];
             return {
                 base64ImageData: parts[1] || parts[0],
                 mimeType: imgDataUrl.match(/:(.*?);/)?.[1] || 'image/png'
             };
        }).filter(Boolean) as { base64ImageData: string; mimeType: string }[];

        const allInputImages = [...imageInputs, ...localImages];
        const allInputImagesB = [...imageInputsB, ...localImagesB];

        // Validation - Relaxed for text-only potential
        if (!parsed.isSequentialEditingWithPrompts) {
             const genericTextsForCheck = textInputs.filter(t => !t.trim().startsWith('{') && !t.trim().startsWith('['));
             const hasPrompt = !!(parsed.prompt || genericTextsForCheck.length > 0);
             if (allInputImages.length === 0 && effectiveModel !== 'gemini-3-pro-image-preview' && !isNanoBanana21Model(effectiveModel) && !hasPrompt) {
                 setError("No input image or prompt provided for generation/editing.");
                 return;
             }
        }

        setError(null);
        setIsStoppingEdit(false);

        // --- BATCH API MODE INTERCEPTION ---
        if (batchManager?.isBatchMode) {
            const formingAbortCtrl = new AbortController();
            if (batchManager.registerFormingBatch) {
                batchManager.registerFormingBatch(nodeId, formingAbortCtrl);
            }

            if (isSequenceMode) {
                const targetIndices = indicesToProcess || (
                    parsed.isSequentialEditingWithPrompts 
                       ? (parsed.checkedSequenceOutputIndices || allInputImagesB.map((_: any, i: number) => i))
                       : (parsed.checkedInputIndices ?? allInputImages.map((_: any, i: number) => i))
                );

                const sequenceOutputs = parsed.sequenceOutputs || [];
                const newOutputs = [...sequenceOutputs];
                targetIndices.forEach((i: number) => {
                    newOutputs[i] = { status: 'generating', thumbnail: null };
                });
                updateNodeInStorage(currentTabId, nodeId, (prev) => ({ ...prev, sequenceOutputs: newOutputs }));

                const batchItems: Array<{
                    id: string;
                    prompt: string;
                    aspectRatio?: string;
                    images?: Array<{ base64ImageData: string; mimeType: string }>;
                    resolution?: '1K' | '2K' | '4K' | string;
                    quality?: string;
                    outputFormat?: string;
                    size?: string;
                    thinkingLevel?: string;
                    searchGrounding?: string;
                    autoCrop169?: boolean;
                    autoInsertResults?: boolean;
                    autoSaveImages?: boolean;
                    frameIndex: number;
                }> = [];

                for (const i of targetIndices) {
                    if (formingAbortCtrl.signal.aborted) {
                        return;
                    }

                    let imagesForFrame: { base64ImageData: string, mimeType: string }[] = [];

                    if (parsed.isSequentialEditingWithPrompts) {
                        imagesForFrame = allInputImagesB;
                    } else {
                        let imgA = allInputImages[i];
                        if (!imgA && allInputImages.length === 1) {
                            imgA = allInputImages[0];
                        } else if (!imgA && parsed.checkedInputIndices && parsed.checkedInputIndices.length === 1) {
                            imgA = allInputImages[parsed.checkedInputIndices[0]];
                        } else if (!imgA && allInputImages.length > 0) {
                            imgA = allInputImages[i % allInputImages.length];
                        }
                        if (!imgA && effectiveModel !== 'gemini-3-pro-image-preview' && !isNanoBanana21Model(effectiveModel)) continue;
                        if (imgA) imagesForFrame = [imgA];
                        
                        if (parsed.isSequentialCombinationMode) {
                            if (allInputImagesB.length > 0) {
                                imagesForFrame.push(...allInputImagesB);
                            }
                        }
                    }

                    // PROMPT LOGIC
                    let basePrompt = parsed.prompt;
                    if (parsed.isSequentialPromptMode || parsed.isSequentialEditingWithPrompts || parsed.isSequentialCombinationMode || upstreamPromptMap.has(i)) {
                        if (upstreamPromptMap.has(i)) {
                            basePrompt = upstreamPromptMap.get(i);
                        } else if (parsed.framePrompts && parsed.framePrompts[i]) {
                            basePrompt = parsed.framePrompts[i];
                        }
                    }

                    const genericTexts = textInputs.filter(t => !t.trim().startsWith('{') && !t.trim().startsWith('['));
                    let promptToUse = [basePrompt, ...genericTexts].filter(Boolean).join(', ');
                    if (!promptToUse.trim()) promptToUse = "High quality image";

                    const imagesToUse = await Promise.all(imagesForFrame.map(async (image) => {
                        const imageDataUrl = `data:${image.mimeType};base64,${image.base64ImageData}`;
                        if (parsed.enableAspectRatio && parsed.aspectRatio && parsed.aspectRatio !== 'Auto') {
                            const { formattedImage } = await formatImageForAspectRatio(imageDataUrl, parsed.aspectRatio);
                            return {
                                base64ImageData: formattedImage.split(',')[1],
                                mimeType: formattedImage.match(/:(.*?);/)?.[1] || 'image/png'
                            };
                        }
                        return image;
                    }));

                    let promptWithOutpaint = promptToUse;
                    if (parsed.enableOutpainting) {
                        const outpaintingTemplate = parsed.outpaintingPrompt || '{main_prompt}. Fill the background with environment - fill in the white areas to naturally expand the image area of the original scene.';
                        promptWithOutpaint = outpaintingTemplate.replace('{main_prompt}', promptToUse);
                    }

                    batchItems.push({
                        id: `frame-${i}`,
                        prompt: promptWithOutpaint,
                        aspectRatio: parsed.aspectRatio,
                        images: imagesToUse,
                        resolution: parsed.resolution,
                        quality: parsed.quality,
                        outputFormat: parsed.outputFormat,
                        size: parsed.size,
                        thinkingLevel: parsed.thinkingLevel,
                        searchGrounding: parsed.searchGrounding,
                        autoCrop169: parsed.autoCrop169,
                        autoInsertResults: !!(parsed.autoInsertResults ?? parsed.autoDownload ?? true),
                        autoSaveImages: !!parsed.autoSaveImages,
                        frameIndex: i
                    });
                }

                if (formingAbortCtrl.signal.aborted) {
                    return;
                }

                if (batchItems.length > 0) {
                    await batchManager.createBatchGeneration({
                        nodeId,
                        nodeTitle: node.title || 'Image Editor',
                        tabId: currentTabId,
                        model: effectiveModel,
                        isSequence: true,
                        items: batchItems,
                        signal: formingAbortCtrl.signal
                    });
                }
                return;
            } else {
                // Single Mode in Batch API
                let imagesToUseInputs: { base64ImageData: string; mimeType: string; }[] = [];
                const checkedInputIndices = parsed.checkedInputIndices;
                
                if (checkedInputIndices && Array.isArray(checkedInputIndices) && checkedInputIndices.length > 0) {
                    imagesToUseInputs = allInputImages.filter((_, i) => checkedInputIndices.includes(i));
                }
                
                if (imagesToUseInputs.length === 0 && allInputImages.length > 0) {
                    imagesToUseInputs = allInputImages;
                }

                const genericTexts = textInputs.filter(t => !t.trim().startsWith('{') && !t.trim().startsWith('['));
                let promptToUse = [parsed.prompt, ...genericTexts].filter(Boolean).join(', ');
                if (!promptToUse.trim()) promptToUse = "High quality image";

                const processedImages = await Promise.all(imagesToUseInputs.map(async (image) => {
                    const imageDataUrl = `data:${image.mimeType};base64,${image.base64ImageData}`;
                    if (parsed.enableAspectRatio && parsed.aspectRatio && parsed.aspectRatio !== 'Auto') {
                        const { formattedImage } = await formatImageForAspectRatio(imageDataUrl, parsed.aspectRatio);
                        return {
                            base64ImageData: formattedImage.split(',')[1],
                            mimeType: formattedImage.match(/:(.*?);/)?.[1] || 'image/png'
                        };
                    }
                    return image;
                }));

                let promptWithOutpaint = promptToUse;
                if (parsed.enableOutpainting) {
                    const outpaintingTemplate = parsed.outpaintingPrompt || '{main_prompt}. Fill the background with environment - fill in the white areas to naturally expand the image area of the original scene.';
                    promptWithOutpaint = outpaintingTemplate.replace('{main_prompt}', promptToUse);
                }

                if (formingAbortCtrl.signal.aborted) {
                    return;
                }

                await batchManager.createBatchGeneration({
                    nodeId,
                    nodeTitle: node.title || 'Image Editor',
                    tabId: currentTabId,
                    model: effectiveModel,
                    isSequence: false,
                    items: [{
                        id: 'single-0',
                        prompt: promptWithOutpaint,
                        aspectRatio: parsed.aspectRatio,
                        images: processedImages,
                        resolution: parsed.resolution,
                        quality: parsed.quality,
                        outputFormat: parsed.outputFormat,
                        size: parsed.size,
                        thinkingLevel: parsed.thinkingLevel,
                        searchGrounding: parsed.searchGrounding,
                        autoCrop169: parsed.autoCrop169,
                        autoInsertResults: !!(parsed.autoInsertResults ?? parsed.autoDownload ?? true),
                        autoSaveImages: !!parsed.autoSaveImages,
                        frameIndex: 0
                    }],
                    signal: formingAbortCtrl.signal
                });
                return;
            }
        }

        if (isSequenceMode) {
             const targetIndices = indicesToProcess || (
                 parsed.isSequentialEditingWithPrompts 
                    ? (parsed.checkedSequenceOutputIndices || allInputImagesB.map((_: any, i: number) => i))
                    : (parsed.checkedInputIndices ?? allInputImages.map((_: any, i: number) => i))
             );

             const sequenceOutputs = parsed.sequenceOutputs || [];
             const newOutputs = [...sequenceOutputs];
             targetIndices.forEach((i: number) => {
                 newOutputs[i] = { status: 'queued', thumbnail: null };
             });
             updateNodeInStorage(currentTabId, nodeId, (prev) => ({ ...prev, sequenceOutputs: newOutputs }));

             for (const i of targetIndices) {
                let imagesForFrame: { base64ImageData: string, mimeType: string }[] = [];

                if (parsed.isSequentialEditingWithPrompts) {
                    imagesForFrame = allInputImagesB;
                } else {
                    let imgA = allInputImages[i];
                    if (!imgA && allInputImages.length === 1) {
                        imgA = allInputImages[0];
                    } else if (!imgA && parsed.checkedInputIndices && parsed.checkedInputIndices.length === 1) {
                        imgA = allInputImages[parsed.checkedInputIndices[0]];
                    }
                    if (!imgA && effectiveModel !== 'gemini-3-pro-image-preview' && !isNanoBanana21Model(effectiveModel)) continue;
                    if (imgA) imagesForFrame = [imgA];
                    
                    if (parsed.isSequentialCombinationMode) {
                        if (allInputImagesB.length > 0) {
                            imagesForFrame.push(...allInputImagesB);
                        }
                    }
                }

                // PROMPT LOGIC
                let basePrompt = parsed.prompt;
                if (parsed.isSequentialPromptMode || parsed.isSequentialEditingWithPrompts || parsed.isSequentialCombinationMode || upstreamPromptMap.has(i)) {
                    if (upstreamPromptMap.has(i)) {
                        basePrompt = upstreamPromptMap.get(i);
                    } else if (parsed.framePrompts && parsed.framePrompts[i]) {
                        basePrompt = parsed.framePrompts[i];
                    }
                }

                const genericTexts = textInputs.filter(t => !t.trim().startsWith('{') && !t.trim().startsWith('['));
                let promptToUse = [basePrompt, ...genericTexts].filter(Boolean).join(', ');
                if (!promptToUse.trim()) promptToUse = "High quality image";

                const executeFrame = async (signal: AbortSignal) => {
                    updateNodeInStorage(currentTabId, nodeId, (prev) => {
                        const nextOutputs = [...(prev.sequenceOutputs || [])];
                        nextOutputs[i] = { ...nextOutputs[i], status: 'generating' };
                        return { ...prev, sequenceOutputs: nextOutputs };
                    });

                    const imagesToUse = await Promise.all(imagesForFrame.map(async (image) => {
                         const imageDataUrl = `data:${image.mimeType};base64,${image.base64ImageData}`;
                         if (parsed.enableAspectRatio && parsed.aspectRatio && parsed.aspectRatio !== 'Auto') {
                             const { formattedImage } = await formatImageForAspectRatio(imageDataUrl, parsed.aspectRatio);
                             return {
                                 base64ImageData: formattedImage.split(',')[1],
                                 mimeType: formattedImage.match(/:(.*?);/)?.[1] || 'image/png'
                             };
                         }
                         return image;
                    }));

                    let promptWithOutpaint = promptToUse;
                    if (parsed.enableOutpainting) {
                         const outpaintingTemplate = parsed.outpaintingPrompt || '{main_prompt}. Fill the background with environment - fill in the white areas to naturally expand the image area of the original scene.';
                         promptWithOutpaint = outpaintingTemplate.replace('{main_prompt}', promptToUse);
                    }

                    return await raceWithAbort(
                        generateImage(promptWithOutpaint, parsed.aspectRatio, imagesToUse, effectiveModel, parsed.resolution, {
                            quality: parsed.quality,
                            outputFormat: parsed.outputFormat,
                            size: parsed.size,
                            thinkingLevel: parsed.thinkingLevel,
                            searchGrounding: parsed.searchGrounding
                        }),
                        signal
                    );
                };

                const onSuccess = async (imageUrl: string) => {
                    if (addToHistory) addToHistory(imageUrl, promptToUse, effectiveModel, { aspectRatio: parsed.aspectRatio, resolution: parsed.resolution });
                    let finalImageUrl = imageUrl;
                    if (parsed.autoCrop169) {
                         try { finalImageUrl = await cropImageTo169(imageUrl); } catch(e) {}
                    }
                    let thumb = finalImageUrl;
                    try {
                        thumb = await generateThumbnail(finalImageUrl, 256, 256);
                    } catch {
                        thumb = finalImageUrl;
                    }
                    
                    updateNodeInStorage(currentTabId, nodeId, (prev) => {
                        const nextOutputs = [...(prev.sequenceOutputs || [])];
                        nextOutputs[i] = { status: 'done', thumbnail: thumb };
                        return { ...prev, sequenceOutputs: nextOutputs };
                    }, { frame: 1000 + i, url: finalImageUrl });

                    const shouldAutoSave = !!parsed.autoSaveImages;
                    if (shouldAutoSave) {
                         triggerDownload(finalImageUrl, promptToUse, i + 1);
                    }

                    notifyImageEditorSuccess({
                        nodeTitle: node.title || 'AI Image Editor',
                        prompt: promptToUse,
                        thumbnail: thumb,
                        frameIndex: i,
                        nodeId
                    });
                };

                const onError = (err: any) => {
                    updateNodeInStorage(currentTabId, nodeId, (prev) => {
                        const nextOutputs = [...(prev.sequenceOutputs || [])];
                        nextOutputs[i] = { status: err?.name === 'AbortError' || err?.message === 'Aborted' ? 'pending' : 'error', thumbnail: null };
                        return { ...prev, sequenceOutputs: nextOutputs };
                    });
                };

                if (taskQueue) {
                    taskQueue.enqueueTask({
                        nodeId,
                        nodeTitle: node.title || 'Image Editor',
                        frameIndex: i,
                        prompt: promptToUse,
                        type: 'sequence_frame',
                        tabId: currentTabId,
                        tabName: activeTabName,
                        execute: executeFrame,
                        onSuccess,
                        onError
                    });
                } else {
                    // Fallback local execution if taskQueue not present
                    try {
                        const abortCtrl = new AbortController();
                        abortControllerRef.current = abortCtrl;
                        setIsEditingImageLocal(true);
                        const res = await executeFrame(abortCtrl.signal);
                        await onSuccess(res);
                    } catch (e) {
                        onError(e);
                    } finally {
                        setIsEditingImageLocal(false);
                    }
                }
             }

        } else {
            // Single Mode Logic
            let imagesToUseInputs: { base64ImageData: string; mimeType: string; }[] = [];
            const checkedInputIndices = parsed.checkedInputIndices;
            
            if (checkedInputIndices && Array.isArray(checkedInputIndices)) {
                imagesToUseInputs = allInputImages.filter((_, i) => checkedInputIndices.includes(i));
            } else {
                 imagesToUseInputs = allInputImages;
            }

            const genericTexts = textInputs.filter(t => !t.trim().startsWith('{') && !t.trim().startsWith('['));
            let promptToUse = [parsed.prompt, ...genericTexts].filter(Boolean).join(', ');
            if (!promptToUse.trim()) promptToUse = "High quality image";

            const executeSingle = async (signal: AbortSignal) => {
                const processedImages = await Promise.all(imagesToUseInputs.map(async (image) => {
                     const imageDataUrl = `data:${image.mimeType};base64,${image.base64ImageData}`;
                     if (parsed.enableAspectRatio && parsed.aspectRatio && parsed.aspectRatio !== 'Auto') {
                         const { formattedImage } = await formatImageForAspectRatio(imageDataUrl, parsed.aspectRatio);
                         return {
                             base64ImageData: formattedImage.split(',')[1],
                             mimeType: formattedImage.match(/:(.*?);/)?.[1] || 'image/png'
                         };
                     }
                     return image;
                }));

                let promptWithOutpaint = promptToUse;
                if (parsed.enableOutpainting) {
                     const outpaintingTemplate = parsed.outpaintingPrompt || '{main_prompt}. Fill the background with environment - fill in the white areas to naturally expand the image area of the original scene.';
                     promptWithOutpaint = outpaintingTemplate.replace('{main_prompt}', promptToUse);
                }

                return await raceWithAbort(
                     generateImage(promptWithOutpaint, parsed.aspectRatio, processedImages, effectiveModel, parsed.resolution, {
                         quality: parsed.quality,
                         outputFormat: parsed.outputFormat,
                         size: parsed.size,
                         thinkingLevel: parsed.thinkingLevel,
                         searchGrounding: parsed.searchGrounding
                     }),
                     signal
                );
            };

            const onSuccess = async (imageUrl: string) => {
                if (addToHistory) addToHistory(imageUrl, promptToUse, effectiveModel, { aspectRatio: parsed.aspectRatio, resolution: parsed.resolution });
                let finalImageUrl = imageUrl;
                if (parsed.autoCrop169) {
                     try { finalImageUrl = await cropImageTo169(imageUrl); } catch(e) {}
                }
                let thumb = finalImageUrl;
                try {
                    thumb = await generateThumbnail(finalImageUrl, 256, 256);
                } catch {
                    thumb = finalImageUrl;
                }
                
                updateNodeInStorage(currentTabId, nodeId, (prev) => ({ ...prev, outputImage: thumb }), { frame: 0, url: finalImageUrl });

                const shouldAutoSave = !!parsed.autoSaveImages;
                if (shouldAutoSave) {
                     triggerDownload(finalImageUrl, promptToUse);
                }

                notifyImageEditorSuccess({
                    nodeTitle: node.title || 'AI Image Editor',
                    prompt: promptToUse,
                    thumbnail: thumb,
                    nodeId
                });
            };

            const onError = (e: any) => {
                if (e.name !== 'AbortError' && e.message !== 'Aborted') {
                    setError(e.message);
                }
            };

            if (taskQueue) {
                taskQueue.enqueueTask({
                    nodeId,
                    nodeTitle: node.title || 'Image Editor',
                    frameIndex: 0,
                    prompt: promptToUse,
                    type: 'image_edit',
                    tabId: currentTabId,
                    tabName: activeTabName,
                    execute: executeSingle,
                    onSuccess,
                    onError
                });
            } else {
                try {
                    const abortCtrl = new AbortController();
                    abortControllerRef.current = abortCtrl;
                    setIsEditingImageLocal(true);
                    const res = await executeSingle(abortCtrl.signal);
                    await onSuccess(res);
                } catch (e) {
                    onError(e);
                } finally {
                    setIsEditingImageLocal(false);
                }
            }
        }
    }, [nodes, getUpstreamNodeValues, getFullSizeImage, setError, updateNodeInStorage, activeTabName, activeTabIdRef, addToHistory, taskQueue]);

    const handleStopEdit = useCallback((nodeId?: string) => {
        if (nodeId) {
            if (taskQueue) {
                taskQueue.cancelAllNodeTasks(nodeId);
            }
            if (batchManager?.cancelBatchForNode) {
                batchManager.cancelBatchForNode(nodeId);
            }
        }
        if (abortControllerRef.current) {
            setIsStoppingEdit(true);
            abortControllerRef.current.abort();
        }
    }, [taskQueue, batchManager]);

    return {
        isEditingImage,
        isStoppingEdit,
        handleEditImage,
        handleStopEdit
    };
};
