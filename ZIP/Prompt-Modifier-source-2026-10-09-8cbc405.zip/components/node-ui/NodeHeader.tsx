
import React from 'react';
import { Node, NodeType, ToastType, DockMode } from '../../types';
import { ActionButton } from '../ActionButton';
import { Tooltip } from '../Tooltip';
import { EditorTooltip } from '../nodes/image-editor/EditorTooltip';
import { useLanguage } from '../../localization';
import { HEADER_HEIGHT, isRestrictedDockingNode } from '../../utils/nodeUtils';
import { CopyIcon, DetachIcon, PinLeftIcon, PinRightIcon, FullScreenIcon, ExitFullScreenIcon, PinIcon, EyeIcon, EyeOffIcon, PhotoIcon } from '../icons/AppIcons';
import { useAppContext } from '../../contexts/AppContext';

interface NodeHeaderProps {
    node: Node;
    isDockedWindow: boolean;
    isRerouteDot: boolean;
    headerBgClass: string;
    onMouseDown: (e: React.MouseEvent<HTMLDivElement>) => void;
    onTouchStart?: (e: React.TouchEvent<HTMLDivElement>) => void;
    onMouseUp?: (e: React.MouseEvent<HTMLDivElement>) => void;
    onDoubleClick: (e: React.MouseEvent<HTMLDivElement>) => void;
    onToggleCollapse: (nodeId: string) => void;
    onRenameNode: (nodeId: string, currentTitle: string) => void;
    onDeleteNode: (nodeId: string) => void;
    onCutConnections: (nodeId: string) => void;
    onDuplicateNode: (nodeId: string) => void;
    onDuplicateNodeWithContent: (nodeId: string) => void;
    onCopyNodeValue: (nodeId: string) => void;
    onPasteNodeValue: (nodeId: string) => Promise<void>;
    onPasteImage: (nodeId: string, imageFile?: File | null) => Promise<void>;
    onDownloadImage: (nodeId: string) => void;
    onRefreshImageEditor: (nodeId: string) => void;
    onRefreshChat: (nodeId: string) => void;
    onValueChange: (nodeId: string, value: string) => void;
    clearImagesForNodeFromCache: (nodeId: string) => void;
    addToast: (message: string, type?: ToastType) => void;
    getEmptyValueForNodeType: (node: Node) => string;
    // Specific handlers
    onSaveSequenceToCatalog?: (nodeId: string) => void;
    onSaveScriptToDisk?: (nodeId: string) => void;
    onSaveMediaToDisk?: (nodeId: string) => void;
    onSaveCharacterToCatalog?: (nodeId: string) => void;
    onSaveCharacterCard?: (nodeId: string) => void;
    handleUndockNode?: (nodeId: string) => void;
    handleOpenNodeContextMenu?: (e: React.MouseEvent, nodeId: string) => void;
    handleRequestDelete: (e: React.MouseEvent) => void;
    handleDetachNodeFromGroup: (nodeId: string) => void;
    isInstantCloseEnabled?: boolean;
    onToggleCharacterImages?: () => void;
    allImagesCollapsed?: boolean;
    handleDetachNodeToMiniApp?: (nodeId: string) => void;
    handleReattachNodeFromMiniApp?: (nodeId: string) => void;
    isMiniAppWindow?: boolean;
    onToggleMiniAppPin?: () => void;
    isMiniAppPinned?: boolean;
}

export const NodeHeader: React.FC<NodeHeaderProps> = ({
    node,
    isDockedWindow,
    isRerouteDot,
    headerBgClass,
    onMouseDown,
    onTouchStart,
    onMouseUp,
    onDoubleClick,
    onToggleCollapse,
    onRenameNode,
    onCutConnections,
    onDuplicateNode,
    onDuplicateNodeWithContent,
    onCopyNodeValue,
    onPasteNodeValue,
    onPasteImage,
    onDownloadImage,
    onRefreshImageEditor,
    onRefreshChat,
    onValueChange,
    clearImagesForNodeFromCache,
    addToast,
    getEmptyValueForNodeType,
    onSaveSequenceToCatalog,
    onSaveScriptToDisk,
    onSaveMediaToDisk,
    onSaveCharacterToCatalog,
    onSaveCharacterCard,
    handleUndockNode,
    handleOpenNodeContextMenu,
    handleRequestDelete,
    isInstantCloseEnabled,
    onToggleCharacterImages,
    allImagesCollapsed,
    handleDetachNodeToMiniApp: propHandleDetach,
    handleReattachNodeFromMiniApp: propHandleReattach,
    isMiniAppWindow,
    onToggleMiniAppPin,
    isMiniAppPinned
}) => {
    const { t } = useLanguage();
    const context = useAppContext();
    const { 
        handleDockNode, 
        toggleNodeFullScreen, 
        focusedNodeId, 
        handleToggleNodePin, 
        handleToggleNodeHandles, 
        batchJobs,
        fetchingJobIds,
        fetchBatchJobResults
    } = context || {};

    const handleDetachNode = propHandleDetach || context?.handleDetachNodeToMiniApp;
    const handleReattachNode = propHandleReattach || context?.handleReattachNodeFromMiniApp;

    const isFullScreen = focusedNodeId === node.id;
    const isRestricted = isRestrictedDockingNode(node.type);

    const nodeBatchJobs = React.useMemo(() => {
        if (node.type !== NodeType.IMAGE_EDITOR && node.type !== NodeType.IMAGE_OUTPUT && node.type !== NodeType.CHARACTER_CARD) return [];
        return (batchJobs || []).filter(j => j && j.nodeId === node.id);
    }, [node.type, node.id, batchJobs]);

    const isWaitingBatch = React.useMemo(() => {
        return nodeBatchJobs.some(j => j.state === 'PENDING' || j.state === 'RUNNING');
    }, [nodeBatchJobs]);

    const completedBatchJob = React.useMemo(() => {
        if (isWaitingBatch) return null;
        const completed = nodeBatchJobs.filter(j => j.state === 'SUCCEEDED');
        if (completed.length === 0) return null;
        return [...completed].sort((a, b) => (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0))[0];
    }, [nodeBatchJobs, isWaitingBatch]);

    const isDownloadingBatch = completedBatchJob ? !!fetchingJobIds?.[completedBatchJob.id] : false;

    const totalActiveBatchCount = React.useMemo(() => {
        return (batchJobs || []).filter(j => j && (j.state === 'PENDING' || j.state === 'RUNNING')).length;
    }, [batchJobs]);

    const totalCompletedBatchCount = React.useMemo(() => {
        return (batchJobs || []).filter(j => j && j.state === 'SUCCEEDED').length;
    }, [batchJobs]);

    // Batch result insertion toggle
    const isBatchAutoInsertEligible = node.type === NodeType.IMAGE_EDITOR || node.type === NodeType.IMAGE_OUTPUT;
    const isBatchActive = (context?.isBatchMode) || node.useBatch || isWaitingBatch || !!completedBatchJob;

    const isAutoInsertEnabled = React.useMemo(() => {
        if (node.type === NodeType.IMAGE_EDITOR) {
            try {
                const parsed = JSON.parse(node.value || '{}');
                return !!(parsed.autoInsertResults ?? parsed.autoDownload ?? true);
            } catch { }
        }
        return !!node.autoDownload;
    }, [node.type, node.value, node.autoDownload]);

    const handleToggleBatchAutoInsert = (e: React.MouseEvent) => {
        e.stopPropagation();
        const nextVal = !isAutoInsertEnabled;
        if (node.type === NodeType.IMAGE_OUTPUT) context?.handleAutoDownloadChange?.(node.id, nextVal);

        if (node.type === NodeType.IMAGE_EDITOR) {
            try {
                const parsed = JSON.parse(node.value || '{}');
                const updated = { ...parsed, autoInsertResults: nextVal };
                onValueChange(node.id, JSON.stringify(updated));
            } catch { }
        }

        if (context?.setBatchJobs) {
            context.setBatchJobs((prev: any[]) => prev.map(j => {
                if (j.nodeId === node.id) {
                    return {
                        ...j,
                        items: (j.items || []).map((it: any) => ({ ...it, ...(node.type === NodeType.IMAGE_EDITOR ? { autoInsertResults: nextVal } : { autoDownload: nextVal }) }))
                    };
                }
                return j;
            }));
        }

        if (nextVal && completedBatchJob && fetchBatchJobResults && !isDownloadingBatch && (node.type !== NodeType.IMAGE_EDITOR || completedBatchJob.resultsCached || (completedBatchJob.items.some(item => !!item.resultUrl) && completedBatchJob.items.every(item => !!item.resultUrl || item.status === 'failed' || item.status === 'cancelled')))) {
            fetchBatchJobResults(completedBatchJob.id, { forceRestore: true });
        }

        if (addToast) {
            addToast(
                nextVal
                    ? (t(node.type === NodeType.IMAGE_EDITOR ? 'batch.autoInsertEnabledToast' : 'batch.autoDownloadEnabledToast') || 'Автовставка в ноду включена')
                    : (t(node.type === NodeType.IMAGE_EDITOR ? 'batch.autoInsertDisabledToast' : 'batch.autoDownloadDisabledToast') || 'Автовставка в ноду выключена'),
                'info'
            );
        }
    };

    // Note Specific Logic
    const isNote = node.type === NodeType.NOTE;
    let isNoteMinimal = false;
    let noteData: any = {};
    if (isNote) {
        try {
            noteData = JSON.parse(node.value || '{}');
            isNoteMinimal = !!noteData.isMinimal;
        } catch { }
    }

    const handleToggleNoteMinimal = (e: React.MouseEvent) => {
        e.stopPropagation();
        const newData = { ...noteData, isMinimal: !isNoteMinimal };
        onValueChange(node.id, JSON.stringify(newData));
    };

    const hasImageContent = React.useMemo(() => {
        if (node.type === NodeType.IMAGE_OUTPUT || node.type === NodeType.VIDEO_OUTPUT) return !!node.value;
        if (node.type === NodeType.IMAGE_INPUT || node.type === NodeType.IMAGE_ANALYZER || node.type === NodeType.IMAGE_EDITOR || node.type === NodeType.CHARACTER_CARD || node.type === NodeType.DATA_READER) {
            try {
                const parsed = JSON.parse(node.value || '{}');
                return !!parsed.image || (parsed.inputImages && parsed.inputImages.length > 0) || !!parsed.outputImage;
            } catch {
                if (node.type === NodeType.IMAGE_INPUT) return !!node.value;
                return false;
            }
        }
        return false;
    }, [node.type, node.value]);

    const helpTexts = React.useMemo(() => ({
        [NodeType.TEXT_INPUT]: t('node.help.text_input'),
        [NodeType.IMAGE_INPUT]: t('node.help.image_input'),
        [NodeType.PROMPT_PROCESSOR]: t('node.help.prompt_processor'),
        [NodeType.PROMPT_SANITIZER]: t('node.help.prompt_sanitizer'),
        [NodeType.VIDEO_PROMPT_PROCESSOR]: t('node.help.video_prompt_processor'),
        [NodeType.IMAGE_OUTPUT]: t('node.help.image_output'),
        [NodeType.VIDEO_OUTPUT]: t('node.help.video_output'),
        [NodeType.PROMPT_ANALYZER]: t('node.help.prompt_analyzer'),
        [NodeType.CHARACTER_ANALYZER]: t('node.help.character_analyzer'),
        [NodeType.CHARACTER_GENERATOR]: t('node.help.character_generator'),
        [NodeType.CHARACTER_CARD]: t('node.help.character_card'),
        [NodeType.IMAGE_ANALYZER]: t('node.help.image_analyzer'),
        [NodeType.IMAGE_EDITOR]: t('node.help.image_editor'),
        [NodeType.IMAGE_SEQUENCE_GENERATOR]: t('node.help.image_sequence_generator'),
        [NodeType.PROMPT_SEQUENCE_EDITOR]: t('node.help.prompt_sequence_editor'),
        [NodeType.GEMINI_CHAT]: t('node.help.gemini_chat'),
        [NodeType.TRANSLATOR]: t('node.help.translator'),
        [NodeType.SCRIPT_GENERATOR]: t('node.help.script_generator'),
        [NodeType.SCRIPT_VIEWER]: t('node.help.script_viewer'),
        [NodeType.NOTE]: t('node.help.note'),
        [NodeType.REROUTE_DOT]: t('node.help.reroute_dot'),
        [NodeType.DATA_READER]: t('node.help.data_reader'),
        [NodeType.VIDEO_EDITOR]: t('node.help.video_editor'),
        [NodeType.MEDIA_VIEWER]: t('node.help.media_viewer'),
        [NodeType.DATA_PROTECTION]: t('node.help.data_protection'),
        [NodeType.POSE_CREATOR]: t('node.help.pose_creator'),
        [NodeType.THREE_D_GENERATOR]: t('node.help.three_d_generator' as any) || 'Generate 3D models using Tripo AI (Single Image or Multiview)',
        [NodeType.THREE_D_VIEWER]: t('node.help.three_d_viewer' as any) || 'Interactive 3D model viewport for inspecting, rotating, lighting, snapshots & wireframe preview for .glb and .gltf files',
        [NodeType.BATCH_PREPARE]: t('node.help.batch_prepare' as any) || 'Multichannel multiview preparation & slicing (Front, Back, Left, Right) for 3D generation',
    }), [t]);

    const nodeTypeTitleMap: Record<NodeType, string> = React.useMemo(() => ({
        [NodeType.TEXT_INPUT]: 'node.title.text_input',
        [NodeType.IMAGE_INPUT]: 'node.title.image_input',
        [NodeType.PROMPT_PROCESSOR]: 'node.title.prompt_processor',
        [NodeType.PROMPT_SANITIZER]: 'node.title.prompt_sanitizer',
        [NodeType.VIDEO_PROMPT_PROCESSOR]: 'node.title.video_prompt_processor',
        [NodeType.IMAGE_OUTPUT]: 'node.title.image_output',
        [NodeType.VIDEO_OUTPUT]: 'node.title.video_output',
        [NodeType.PROMPT_ANALYZER]: 'node.title.prompt_analyzer',
        [NodeType.CHARACTER_ANALYZER]: 'node.title.character_analyzer',
        [NodeType.CHARACTER_GENERATOR]: 'node.title.character_generator',
        [NodeType.CHARACTER_CARD]: 'node.title.character_card',
        [NodeType.IMAGE_ANALYZER]: 'node.title.image_analyzer',
        [NodeType.IMAGE_EDITOR]: 'node.title.image_editor',
        [NodeType.IMAGE_SEQUENCE_GENERATOR]: 'node.title.image_sequence_generator',
        [NodeType.PROMPT_SEQUENCE_EDITOR]: 'node.title.prompt_sequence_editor',
        [NodeType.GEMINI_CHAT]: 'node.title.gemini_chat',
        [NodeType.TRANSLATOR]: 'node.title.translator',
        [NodeType.SCRIPT_GENERATOR]: 'node.title.script_generator',
        [NodeType.SCRIPT_VIEWER]: 'node.title.script_viewer',
        [NodeType.NOTE]: 'node.title.note',
        [NodeType.REROUTE_DOT]: 'node.title.reroute_dot',
        [NodeType.DATA_READER]: 'node.title.data_reader',
        [NodeType.VIDEO_EDITOR]: 'node.title.video_editor',
        [NodeType.MEDIA_VIEWER]: 'node.title.media_viewer',
        [NodeType.DATA_PROTECTION]: 'node.title.data_protection',
        [NodeType.POSE_CREATOR]: 'node.title.pose_creator',
        [NodeType.THREE_D_GENERATOR]: 'node.title.three_d_generator',
        [NodeType.THREE_D_VIEWER]: 'node.title.three_d_viewer',
        [NodeType.BATCH_PREPARE]: 'node.title.batch_prepare',
    }), []);

    const displayTitle = React.useMemo(() => {
        if (!node.title) {
            const key = nodeTypeTitleMap[node.type];
            return key ? (t(key as any) || node.type) : node.type;
        }
        if (node.title.startsWith('node.title.') || node.title.startsWith('search.node.')) {
            return t(node.title as any) || node.title;
        }
        const defaultTitles: Record<NodeType, string[]> = {
            [NodeType.TEXT_INPUT]: ['Text Input', 'Текстовый узел', 'Ввод текста'],
            [NodeType.IMAGE_INPUT]: ['Image Input', 'Узел изображения', 'Ввод изображения'],
            [NodeType.PROMPT_PROCESSOR]: ['Prompt Processor', 'Обработчик промпта', 'Обработчик запроса'],
            [NodeType.PROMPT_SANITIZER]: ['Prompt Sanitizer', 'Очиститель промпта'],
            [NodeType.VIDEO_PROMPT_PROCESSOR]: ['Video Prompt Proc.', 'Обработчик видео промпта', 'Видео Промпт Проц.', 'Video Prompt Processor'],
            [NodeType.IMAGE_OUTPUT]: ['Image Output', 'Вывод изображения'],
            [NodeType.VIDEO_OUTPUT]: ['Video Output', 'Вывод видео'],
            [NodeType.PROMPT_ANALYZER]: ['Prompt Analyzer', 'Анализатор промпта'],
            [NodeType.CHARACTER_ANALYZER]: ['Character Analyzer', 'Анализатор персонажа'],
            [NodeType.CHARACTER_GENERATOR]: ['Character Generator', 'Генератор персонажей', 'Генератор персонажа'],
            [NodeType.CHARACTER_CARD]: ['Character Card', 'Карточка персонажа'],
            [NodeType.IMAGE_ANALYZER]: ['Image Analyzer', 'Анализатор изображений', 'Анализ изображения'],
            [NodeType.IMAGE_EDITOR]: ['AI Image Editor', 'Редактор изображений ИИ', 'AI Редактор изображений', 'Редактор изображений'],
            [NodeType.IMAGE_SEQUENCE_GENERATOR]: ['Image Sequence Gen.', 'Генератор последовательности изображений', 'Генератор послед. изобр.', 'Image Sequence Generator'],
            [NodeType.PROMPT_SEQUENCE_EDITOR]: ['Prompt Sequence Editor', 'Редактор последовательности промптов'],
            [NodeType.GEMINI_CHAT]: ['Gemini Chat', 'Чат с Gemini', 'Чат Gemini'],
            [NodeType.TRANSLATOR]: ['Translator', 'Переводчик'],
            [NodeType.SCRIPT_GENERATOR]: ['Script Generator', 'Генератор сценария'],
            [NodeType.SCRIPT_VIEWER]: ['Script Viewer', 'Просмотрщик сценария'],
            [NodeType.NOTE]: ['Note', 'Заметка'],
            [NodeType.REROUTE_DOT]: ['Reroute Dot', 'Точка маршрутизации'],
            [NodeType.DATA_READER]: ['Data Reader', 'Считыватель данных', 'Читатель данных'],
            [NodeType.VIDEO_EDITOR]: ['Video Editor Alpha', 'Видео редактор Альфа версия', 'Видеоредактор Alpha', 'Video Editor', 'Видеоредактор'],
            [NodeType.MEDIA_VIEWER]: ['Media Viewer', 'Просмотр медиа данных', 'Медиаплеер', 'Медиа плеер'],
            [NodeType.DATA_PROTECTION]: ['Data Protection', 'Защита данных'],
            [NodeType.POSE_CREATOR]: ['Pose Creator', 'Создание поз', 'Конструктор поз'],
            [NodeType.THREE_D_GENERATOR]: ['3D Generation', '3D Генерация', '3D Generation (Tripo)', '3D Моделирование', '3D Генератор'],
            [NodeType.THREE_D_VIEWER]: ['3D Viewer (GLB / glTF)', '3D Просмотрщик (GLB / glTF)', '3D Viewer (GLB)', '3D GLB Viewer', '3D GLB Просмотрщик', '3D Просмотрщик'],
            [NodeType.BATCH_PREPARE]: ['3D Batch Prepare', '3D Multiview Batch Prepare', '3D Batch Prepare (Мультиканальная подготовка)', 'Подготовка 3D / Batch Prepare', '3D Batch Prepare (Подготовка ракурсов)'],
        };
        const defaults = defaultTitles[node.type];
        if (defaults && defaults.includes(node.title.trim())) {
            const key = nodeTypeTitleMap[node.type];
            if (key) {
                return t(key as any) || node.title;
            }
        }
        return node.title;
    }, [node.title, node.type, nodeTypeTitleMap, t]);

    const handleClearContent = (e: React.MouseEvent) => {
        e.stopPropagation();
        onValueChange(node.id, getEmptyValueForNodeType(node));
        if (node.type === NodeType.IMAGE_INPUT || node.type === NodeType.IMAGE_OUTPUT || node.type === NodeType.IMAGE_ANALYZER || node.type === NodeType.IMAGE_SEQUENCE_GENERATOR) {
            clearImagesForNodeFromCache(node.id);
        }
        addToast(t('toast.contentCleared'));
    };

    const handleFullFocus = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (handleDockNode) handleDockNode(node.id, 'full');
        if (toggleNodeFullScreen) {
            setTimeout(() => toggleNodeFullScreen(node.id), 50);
        }
    };

    const handleDockCycle = (direction: number) => {
        if (!handleDockNode || !node.dockState) return;
        const modes: string[] = ['q1', 'q2', 'q3', 'q4'];
        const currentMode = node.dockState.mode;
        let index = modes.indexOf(currentMode);
        if (index === -1) {
            if (['left', 'tl', 'bl'].includes(currentMode)) index = 0;
            else if (['right', 'tr', 'br'].includes(currentMode)) index = 3;
            else index = 0;
        }
        let newIndex = index + direction;
        if (newIndex < 0) newIndex = 0;
        if (newIndex >= modes.length) newIndex = modes.length - 1;
        if (modes[newIndex] !== currentMode) {
            handleDockNode(node.id, modes[newIndex] as DockMode);
        }
    };

    const handleVerticalDockCycle = (side: 'left' | 'right') => {
        if (!handleDockNode || !node.dockState) return;
        const currentMode = node.dockState.mode;
        if (side === 'left') {
            if (currentMode === 'tl') handleDockNode(node.id, 'bl');
            else handleDockNode(node.id, 'tl');
        } else {
            if (currentMode === 'tr') handleDockNode(node.id, 'br');
            else handleDockNode(node.id, 'tr');
        }
    };

    const handleAddCard = (e: React.MouseEvent) => {
        e.stopPropagation();
        let characters: any[] = [];
        try {
            const parsed = JSON.parse(node.value || '[]');
            characters = Array.isArray(parsed) ? parsed : [parsed];
        } catch {
            characters = [];
        }
        let nextNameIndex = 1;
        const existingNames = new Set(characters.map((c: any) => c.name));
        while (existingNames.has(`New Character ${nextNameIndex}`)) {
            nextNameIndex++;
        }
        const newChar = {
            id: `char-card-${Date.now()}`,
            name: `New Character ${nextNameIndex}`,
            index: `Character-${characters.length + 1}`,
            image: null,
            thumbnails: { '1:1': null, '16:9': null, '9:16': null },
            selectedRatio: '1:1',
            prompt: '',
            fullDescription: '',
            targetLanguage: 'en',
            isOutput: characters.length === 0,
            isDescriptionCollapsed: false,
            additionalPrompt: "Full body character concept on a gray background"
        };
        const newChars = [...characters, newChar];
        onValueChange(node.id, JSON.stringify(newChars));
        if (context?.setNodes) {
            const NODE_WIDTH_STEP = 410;
            const BASE_WIDTH_OFFSET = 90;
            const newWidth = newChars.length * NODE_WIDTH_STEP + BASE_WIDTH_OFFSET;
            context.setNodes(nds => nds.map(n => n.id === node.id ? { ...n, width: newWidth } : n));
        }
    };

    return (
        <div
            className={`${headerBgClass} text-white font-bold p-2 ${node.isCollapsed && !isDockedWindow ? 'rounded-md' : 'rounded-t-md'} flex justify-between items-center flex-shrink-0 ${!isRerouteDot && !isDockedWindow ? 'cursor-move' : ''}`}
            onMouseDown={onMouseDown}
            onTouchStart={!isRerouteDot && !isDockedWindow ? onTouchStart : undefined}
            onMouseUp={onMouseUp}
            onContextMenu={(e) => { if (handleOpenNodeContextMenu) handleOpenNodeContextMenu(e, node.id); }}
            onDoubleClick={onDoubleClick}
            style={isRerouteDot ? { height: '100%' } : { height: `${HEADER_HEIGHT}px` }}
        >
            {isRerouteDot ? (
                <div className="w-full h-full flex justify-center items-center"></div>
            ) : (
                <>
                    {/* Left Side: Collapse, Pin, Title (Hidden if minimal note) */}
                    <div className="flex items-center space-x-1 min-w-0">
                        {!isNoteMinimal && (
                            <>
                                {!isDockedWindow && !isFullScreen && <ActionButton title={node.isCollapsed ? t('node.action.expand') : t('node.action.collapse')} onClick={() => onToggleCollapse(node.id)}>
                                    {node.isCollapsed ? (<svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" /></svg>) : (<svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M5 15l7-7 7 7" /></svg>)}
                                </ActionButton>}

                                {isMiniAppWindow && onToggleMiniAppPin && (
                                    <ActionButton
                                        title={isMiniAppPinned ? (t('titlebar.unpinAlwaysOnTop') || 'Открепить поверх окон') : (t('titlebar.pinAlwaysOnTop') || 'PIN - закрепить поверх остальных окон')}
                                        onClick={(e) => { e.stopPropagation(); onToggleMiniAppPin(); }}
                                        className={`p-1 rounded transition-all border ${
                                            isMiniAppPinned 
                                                ? 'border-cyan-500 bg-cyan-950/70 text-cyan-400 shadow-[0_0_8px_rgba(6,182,212,0.4)]' 
                                                : 'border-transparent text-gray-400 hover:text-white hover:bg-gray-600'
                                        }`}
                                    >
                                        <PinIcon className={`h-4 w-4 transition-transform duration-200 ${isMiniAppPinned ? 'rotate-[-45deg] scale-110 text-cyan-400' : ''}`} />
                                    </ActionButton>
                                )}

                                {!isDockedWindow && !isFullScreen && !isMiniAppWindow && handleToggleNodePin && (
                                    <ActionButton
                                        title={node.isPinned ? t('node.action.unpin') : t('node.action.pin')}
                                        onClick={(e) => { e.stopPropagation(); handleToggleNodePin(node.id); }}
                                        // Theme Change: Use dynamic theme color instead of hardcoded cyan
                                        className={`p-1 rounded hover:bg-gray-600 transition-colors border ${node.isPinned ? 'border-accent-text text-accent-text' : 'border-transparent text-gray-500 hover:text-white'}`}
                                    >
                                        <PinIcon className="h-4 w-4" />
                                    </ActionButton>
                                )}
                                <span className="truncate pr-2">{displayTitle}</span>
                            </>
                        )}
                    </div>

                    {/* Right Side: Actions */}
                    <div
                        className="flex items-center space-x-1 flex-shrink-0"
                        onMouseDown={(e) => e.stopPropagation()}
                        onTouchStart={(e) => e.stopPropagation()}
                        onDoubleClick={(e) => e.stopPropagation()}
                    >

                        {/* Note Minimal Toggle (Eye) */}
                        {isNote && (
                            <ActionButton
                                title={isNoteMinimal ? (t('node.action.expand') || "Show Controls") : (t('node.action.collapse') || "Hide Controls")}
                                onClick={handleToggleNoteMinimal}
                                className={`p-1 rounded hover:bg-gray-600 transition-colors ${isNoteMinimal ? 'text-gray-500' : 'text-gray-400 hover:text-white'}`}
                            >
                                {isNoteMinimal ? <EyeIcon className="h-4 w-4" /> : <EyeOffIcon className="h-4 w-4" />}
                            </ActionButton>
                        )}

                        {/* Character Card Toggles */}
                        {node.type === NodeType.CHARACTER_CARD && !isNoteMinimal && (
                            <>
                                <div className="flex bg-gray-800/50 rounded-md border border-gray-600/50 p-0.5 space-x-0.5">
                                    {onSaveCharacterCard && (
                                        <ActionButton
                                            title={t('node.action.saveCharacter')} // Save to Disk
                                            onClick={(e) => { e.stopPropagation(); onSaveCharacterCard(node.id); }}
                                            className="p-1 rounded hover:bg-gray-600 transition-colors text-gray-400 hover:text-white"
                                        >
                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                            </svg>
                                        </ActionButton>
                                    )}
                                    {onSaveCharacterToCatalog && (
                                        <ActionButton 
                                            title={t('catalog.saveTo')} 
                                            onClick={(e) => { e.stopPropagation(); onSaveCharacterToCatalog(node.id); }}
                                            className="p-1 rounded hover:bg-gray-600 transition-colors text-gray-400 hover:text-white"
                                        >
                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1-4l-3 3-3-3m3 3V3" /></svg>
                                        </ActionButton>
                                    )}
                                </div>
                                <div className="w-px h-3 bg-gray-600/50 mx-0.5"></div>
                                {onToggleCharacterImages && (
                                    <ActionButton
                                        title={allImagesCollapsed ? t('node.action.showImages') : t('node.action.hideImages')}
                                        onClick={(e) => { e.stopPropagation(); onToggleCharacterImages(); }}
                                        className={`p-1 rounded hover:bg-gray-600 transition-colors border ${allImagesCollapsed ? 'border-transparent text-gray-400 hover:text-white' : 'border-accent text-accent-text'}`}
                                    >
                                        <PhotoIcon className="h-4 w-4" />
                                    </ActionButton>
                                )}
                                {handleToggleNodeHandles && (
                                    <ActionButton
                                        title={node.collapsedHandles ? t('node.action.showOutputs') : t('node.action.hideOutputs')}
                                        onClick={(e) => { e.stopPropagation(); handleToggleNodeHandles(node.id); }}
                                        // Theme Change: Use dynamic theme color instead of hardcoded cyan
                                        className={`p-1 rounded hover:bg-gray-600 transition-colors border ${node.collapsedHandles ? 'border-accent text-accent-text' : 'border-transparent text-gray-400 hover:text-white'}`}
                                    >
                                        {node.collapsedHandles ? <EyeOffIcon className="h-4 w-4" /> : <EyeIcon className="h-4 w-4" />}
                                    </ActionButton>
                                )}
                            </>
                        )}

                        {/* Insert downloaded batch results into this image editor */}
                        {isBatchAutoInsertEligible && isBatchActive && (
                            <EditorTooltip
                                title={t(node.type === NodeType.IMAGE_EDITOR ? 'batch.autoInsertLabel' : 'batch.autoDownloadLabel') || 'Автовставка в ноду'}
                                status={{
                                    enabled: isAutoInsertEnabled,
                                    labelOn: t('common.enabled') || 'Включено',
                                    labelOff: t('common.disabled') || 'Выключено'
                                }}
                                description={t(node.type === NodeType.IMAGE_EDITOR ? 'batch.autoInsertTooltip' : 'batch.autoDownloadTooltip') || 'Автоматически вставлять скачанные результаты Batch API в эту ноду'}
                                position="bottom"
                            >
                                <button
                                    type="button"
                                    onClick={handleToggleBatchAutoInsert}
                                    className={`flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-medium transition-all select-none border cursor-pointer ${
                                        isAutoInsertEnabled
                                            ? 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border-emerald-500/60 shadow-sm'
                                            : 'bg-gray-800/80 hover:bg-gray-700 text-gray-400 hover:text-gray-200 border-gray-600/60'
                                    }`}
                                >
                                    <svg className={`w-3.5 h-3.5 shrink-0 ${isAutoInsertEnabled ? 'text-emerald-400' : 'text-gray-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                    </svg>
                                    <span className="truncate">{t(node.type === NodeType.IMAGE_EDITOR ? 'batch.autoInsertLabel' : 'batch.autoDownloadLabel') || 'Автовставка в ноду'}</span>
                                    <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${isAutoInsertEnabled ? 'bg-emerald-400 animate-pulse' : 'bg-gray-500'}`} />
                                </button>
                            </EditorTooltip>
                        )}

                        {/* Mini-Games Lounge Batch API Status Badge */}
                        {node.type === NodeType.DATA_PROTECTION && (
                            <div 
                                className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border text-[11px] font-semibold font-mono select-none transition-all shadow-sm ${
                                    totalActiveBatchCount > 0
                                        ? 'bg-amber-500/20 border-amber-500/60 text-amber-300 animate-pulse shadow-amber-900/30'
                                        : totalCompletedBatchCount > 0
                                        ? 'bg-emerald-500/20 border-emerald-500/60 text-emerald-300 shadow-emerald-900/30'
                                        : 'bg-slate-800/80 border-slate-700 text-slate-400'
                                }`}
                                title={t('batch.loungeMonitorTooltip') || 'Статус фоновых задач Batch API в реальном времени'}
                            >
                                <span className={`w-2 h-2 rounded-full ${
                                    totalActiveBatchCount > 0 ? 'bg-amber-400 animate-ping' : totalCompletedBatchCount > 0 ? 'bg-emerald-400' : 'bg-slate-500'
                                }`} />
                                <span>
                                    Batch API: {totalActiveBatchCount > 0 ? `${totalActiveBatchCount} в работе` : totalCompletedBatchCount > 0 ? `${totalCompletedBatchCount} готово` : 'Ожидание задач'}
                                </span>
                            </div>
                        )}

                        {/* Batch Waiting Status Badge */}
                        {isWaitingBatch && (
                            <div 
                                className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/50 text-emerald-300 text-[11px] font-medium animate-pulse select-none"
                                title={t('batch.waitingServerTooltip') || 'Задача отправлена в Batch API и обрабатывается на сервере (до 24ч). Нода защищена от случайного закрытия.'}
                            >
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                                <span className="truncate max-w-[170px] sm:max-w-none">{t('batch.waitingServerStatus') || 'Waiting for server response'}</span>
                            </div>
                        )}

                        {/* Batch Job Done Status & Download Button */}
                        {!isWaitingBatch && completedBatchJob && (
                            <div className="flex items-center gap-1.5">
                                <div 
                                    className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/50 text-emerald-300 text-[11px] font-medium select-none shadow-sm"
                                    title={t('batch.jobDoneTooltip') || 'Задача успешно завершена на сервере.'}
                                >
                                    <svg className="w-3 h-3 text-emerald-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                                    </svg>
                                    <span className="truncate max-w-[120px] sm:max-w-none font-semibold">{t('batch.jobDone') || 'Job done'}</span>
                                </div>

                                <button
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        if (completedBatchJob && fetchBatchJobResults && !isDownloadingBatch) {
                                            fetchBatchJobResults(completedBatchJob.id, { forceRestore: true });
                                        }
                                    }}
                                    disabled={isDownloadingBatch}
                                    className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[11px] font-semibold shadow-sm transition-all select-none ${
                                        isDownloadingBatch 
                                            ? 'bg-cyan-900/70 text-cyan-300 border border-cyan-700/50 cursor-wait'
                                            : 'bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white border border-emerald-400/40 hover:shadow-emerald-900/40 active:scale-95'
                                    }`}
                                    title={t('batch.downloadResultsTooltip') || 'Скачать сгенерированные изображения с сервера и поместить в эту ноду'}
                                >
                                    {isDownloadingBatch ? (
                                        <>
                                            <svg className="w-3 h-3 animate-spin text-cyan-300 shrink-0" fill="none" viewBox="0 0 24 24">
                                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                                            </svg>
                                            <span>{t('batch.downloading') || 'Downloading...'}</span>
                                        </>
                                    ) : (
                                        <>
                                            <svg className="w-3 h-3 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.2}>
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                            </svg>
                                            <span>{t('batch.download') || 'Download'}</span>
                                        </>
                                    )}
                                </button>
                            </div>
                        )}

                        {/* Help Tooltip */}
                        {!isNoteMinimal && (
                            <div className="relative flex items-center group/help-tooltip">
                                <button onMouseDown={(e) => e.stopPropagation()} className="p-1 text-gray-400 rounded hover:bg-gray-600 hover:text-white transition-colors duration-150 focus:outline-none focus:ring-1 focus:ring-cyan-500" aria-label={t('node.action.help')}>
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                </button>
                                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 bg-slate-700 text-slate-200 text-xs whitespace-normal w-64 rounded-lg shadow-xl z-50 opacity-0 pointer-events-none group-hover/help-tooltip:opacity-100 transition-opacity duration-200 ease-out">
                                    {helpTexts[node.type] || t('node.action.help')}
                                </div>
                            </div>
                        )}

                        {/* Rename */}
                        {!isDockedWindow && !isNoteMinimal && (
                            <ActionButton title={t('node.action.rename')} onClick={() => onRenameNode(node.id, node.title)}>
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                                </svg>
                            </ActionButton>
                        )}

                        {/* Conditional Save/Disk Actions */}
                        {!isNoteMinimal && node.type === NodeType.PROMPT_SEQUENCE_EDITOR && onSaveSequenceToCatalog && onSaveScriptToDisk && (
                            <>
                                <ActionButton title={t('catalog.saveTo')} onClick={() => onSaveSequenceToCatalog(node.id)}>
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2v15" />
                                    </svg>
                                </ActionButton>
                                <ActionButton title={t('group.saveToDisk')} onClick={() => onSaveScriptToDisk(node.id)}>
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                    </svg>
                                </ActionButton>
                            </>
                        )}

                        {!isNoteMinimal && node.type === NodeType.SCRIPT_VIEWER && onSaveScriptToDisk && (
                            <ActionButton title={t('group.saveToDisk')} onClick={() => onSaveScriptToDisk(node.id)}>
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                </svg>
                            </ActionButton>
                        )}
                        {!isNoteMinimal && node.type === NodeType.MEDIA_VIEWER && onSaveMediaToDisk && (
                            <ActionButton title={t('group.saveToDisk')} onClick={() => onSaveMediaToDisk(node.id)}>
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                </svg>
                            </ActionButton>
                        )}

                        {!isNoteMinimal && (node.type === NodeType.IMAGE_OUTPUT || node.type === NodeType.VIDEO_OUTPUT || node.type === NodeType.IMAGE_INPUT || node.type === NodeType.GEMINI_CHAT) && (hasImageContent || node.type === NodeType.GEMINI_CHAT) && (<ActionButton title={t('node.action.download')} onClick={() => onDownloadImage(node.id)}><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg></ActionButton>)}
                        {!isNoteMinimal && (node.type === NodeType.IMAGE_INPUT || node.type === NodeType.IMAGE_OUTPUT || node.type === NodeType.DATA_READER) && hasImageContent && (<ActionButton title={t('node.action.clear')} onClick={handleClearContent}><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></ActionButton>)}
                        {!isNoteMinimal && (node.type === NodeType.IMAGE_ANALYZER) && hasImageContent && (<ActionButton title={t('node.action.clear')} onClick={handleClearContent}><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></ActionButton>)}
                        {!isNoteMinimal && node.type === NodeType.IMAGE_EDITOR && (<ActionButton title={t('node.action.clear')} onClick={() => onRefreshImageEditor(node.id)}><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></ActionButton>)}
                        {!isNoteMinimal && node.type === NodeType.GEMINI_CHAT && (<ActionButton title={t('node.action.refreshChat')} onClick={() => onRefreshChat(node.id)}>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-4 w-4">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182m0-4.991v4.99" />
                            </svg>
                        </ActionButton>)}
                        {!isNoteMinimal && (node.type === NodeType.PROMPT_ANALYZER || node.type === NodeType.CHARACTER_ANALYZER || node.type === NodeType.CHARACTER_GENERATOR) && (<ActionButton title={t('node.action.clear')} onClick={handleClearContent}><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></ActionButton>)}

                        {!isNoteMinimal && (node.type === NodeType.IMAGE_SEQUENCE_GENERATOR || node.type === NodeType.PROMPT_SEQUENCE_EDITOR) && (
                            <ActionButton title={t('node.action.clear')} onClick={() => {
                                if (node.type === NodeType.IMAGE_SEQUENCE_GENERATOR) {
                                    try {
                                        const current = JSON.parse(node.value || '{}');
                                        const resetValue = { ...current, prompts: [], images: {}, frameStatuses: {}, checkedFrameNumbers: [], selectedFrameNumber: null, usedCharacters: [] };
                                        onValueChange(node.id, JSON.stringify(resetValue));
                                        clearImagesForNodeFromCache(node.id);
                                        addToast(t('toast.contentCleared'));
                                    } catch {
                                        handleClearContent(null as any);
                                    }
                                } else {
                                    handleClearContent(null as any);
                                }
                            }}>
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                            </ActionButton>
                        )}

                        {!isNoteMinimal && (node.type === NodeType.IMAGE_INPUT || node.type === NodeType.IMAGE_ANALYZER || node.type === NodeType.IMAGE_EDITOR) && (<> <ActionButton title={t('node.action.paste')} onClick={() => onPasteImage(node.id)}><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2M9 14l2 2 4-4" /></svg></ActionButton> </>)}

                        {!isNoteMinimal && node.type === NodeType.CHARACTER_CARD && (
                            <>
                                <ActionButton title={t('node.action.addCard')} onClick={handleAddCard}>
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
                                    </svg>
                                </ActionButton>

                                {onSaveCharacterToCatalog && onSaveCharacterCard && (
                                    <>
                                        {/* Paste & Copy are specific to single card ops usually, kept here */}
                                        <ActionButton title={t('node.action.paste')} onClick={() => onPasteNodeValue(node.id)}>
                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2M9 14l2 2 4-4" /></svg>
                                        </ActionButton>
                                        <ActionButton title={t('node.action.copy')} onClick={() => onCopyNodeValue(node.id)}>
                                            <CopyIcon className="h-4 w-4" />
                                        </ActionButton>
                                        <ActionButton title={t('node.action.clear')} onClick={handleClearContent}>
                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                        </ActionButton>
                                    </>
                                )}
                            </>
                        )}

                        {!isNoteMinimal && (node.type === NodeType.TEXT_INPUT || node.type === NodeType.NOTE || node.type === NodeType.SCRIPT_GENERATOR || node.type === NodeType.SCRIPT_VIEWER || node.type === NodeType.MEDIA_VIEWER) && (<> <ActionButton title={t('node.action.clear')} onClick={handleClearContent}><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></ActionButton><ActionButton title={t('node.action.paste')} onClick={() => onPasteNodeValue(node.id)}> <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2M9 14l2 2 4-4" /></svg></ActionButton> </>)}

                        {!isNoteMinimal && node.type !== NodeType.IMAGE_EDITOR && node.type !== NodeType.CHARACTER_CARD && (<ActionButton title={t('node.action.copy')} onClick={() => onCopyNodeValue(node.id)}>
                            <CopyIcon className="h-4 w-4" />
                        </ActionButton>)}

                        {!isDockedWindow && !isNoteMinimal && (
                            <ActionButton title={t('toolbar.duplicateWithContent')} onClick={() => onDuplicateNodeWithContent(node.id)}>
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <rect x="5" y="5" width="14" height="14" rx="2" ry="2"></rect>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v6m-3-3h6" />
                                </svg>
                            </ActionButton>
                        )}
                        {!isDockedWindow && !isNoteMinimal && (
                            <ActionButton title={t('toolbar.duplicate')} onClick={() => onDuplicateNode(node.id)}>
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <rect x="5" y="5" width="14" height="14" rx="2" ry="2"></rect>
                                </svg>
                            </ActionButton>
                        )}

                        {!isNoteMinimal && node.type !== NodeType.NOTE && !isDockedWindow && (
                            <ActionButton
                                title={t('node.action.cutConnections')}
                                onClick={(e) => { e.stopPropagation(); onCutConnections(node.id); }}
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M14.121 14.121L19 19m-7-7l7-7m-7 7l-2.879 2.879M12 12L9.121 9.121M12 12L4.5 4.5" /><path strokeLinecap="round" strokeLinejoin="round" d="M4.5 19.5l.707-.707M19.5 4.5l-.707.707" /></svg>
                            </ActionButton>
                        )}

                        {/* Detach Node into Mini-App Window Button (when on canvas) */}
                        {!isDockedWindow && !isFullScreen && !isMiniAppWindow && !isNoteMinimal && handleDetachNode && (
                            <ActionButton
                                title={t('node.action.detachMiniApp') || 'Открепить в отдельное мини-приложение'}
                                onClick={(e) => {
                                    e.stopPropagation();
                                    handleDetachNode(node.id);
                                }}
                                className="p-1 rounded hover:bg-gray-600 transition-colors text-gray-400 hover:text-cyan-400"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                </svg>
                            </ActionButton>
                        )}

                        {/* Reattach to Canvas Button (when inside mini-app window) */}
                        {isMiniAppWindow && handleReattachNode && (
                            <ActionButton
                                title={t('node.action.reattachToCanvas') || 'Вернуть ноду обратно на холст'}
                                onClick={(e) => {
                                    e.stopPropagation();
                                    handleReattachNode(node.id);
                                }}
                                className="p-1 rounded hover:bg-gray-600 transition-colors text-cyan-400 hover:text-cyan-300"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                                </svg>
                            </ActionButton>
                        )}

                        {/* Close button - Only if NOT minimal note. If minimal note, we need a way to close? Users can expand to close. Or add close here. */}
                        {!isDockedWindow && !isNoteMinimal && (
                            <ActionButton 
                                title={
                                    isWaitingBatch 
                                        ? (t('batch.nodeCloseBlocked') || 'Нельзя закрыть: выполняется пакетная задача Batch API')
                                        : (isInstantCloseEnabled ? t('node.action.closeNodeSimple') : t('node.action.closeNode'))
                                } 
                                onClick={isWaitingBatch ? (e) => {
                                    e.stopPropagation();
                                    addToast(t('batch.nodeCloseBlockedToast') || 'Нода не может быть закрыта, пока выполняется пакетная задача в Batch API!', 'info');
                                } : handleRequestDelete}
                                className={isWaitingBatch ? 'opacity-30 cursor-not-allowed text-gray-500 hover:text-gray-500 hover:bg-transparent' : undefined}
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </ActionButton>
                        )}

                        {/* Positioning Controls (Moved to End) */}
                        {!isNoteMinimal && (isDockedWindow || isFullScreen) && handleUndockNode && (
                            <>
                                <div className="w-px h-3 bg-gray-500 mx-1"></div>

                                {!isFullScreen && (
                                    <>
                                        {/* Move Dock Left (Horizontal Cycle) */}
                                        {!isRestricted && (
                                            <Tooltip content={t('toolbar.dock.cycleHorizontalLeft') || "Cycle Horizontal Left"}>
                                                <button
                                                    onClick={(e) => { e.stopPropagation(); handleDockCycle(-1); }}
                                                    className="text-gray-400 hover:text-white transition-colors p-1"
                                                >
                                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M15 18l-6-6 6-6" /></svg>
                                                </button>
                                            </Tooltip>
                                        )}

                                        {/* NEW: Vertical Left Cycle */}
                                        {!isRestricted && (
                                            <Tooltip content={t('toolbar.dock.cycleVerticalLeft') || "Cycle Vertical Left (TL/BL)"}>
                                                <button
                                                    onClick={(e) => { e.stopPropagation(); handleVerticalDockCycle('left'); }}
                                                    className="text-gray-400 hover:text-white transition-colors p-1"
                                                >
                                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                                                        <path d="M7 15l5 5 5-5" />
                                                        <path d="M7 9l5-5 5 5" />
                                                    </svg>
                                                </button>
                                            </Tooltip>
                                        )}

                                        {/* Pin Left */}
                                        <Tooltip content={t('toolbar.dock.left')}>
                                            <button
                                                onClick={(e) => { e.stopPropagation(); handleDockNode && handleDockNode(node.id, 'left'); }}
                                                className="text-gray-400 hover:text-white transition-colors p-1"
                                            >
                                                <PinLeftIcon />
                                            </button>
                                        </Tooltip>

                                        {/* Pin Right */}
                                        <Tooltip content={t('toolbar.dock.right')}>
                                            <button
                                                onClick={(e) => { e.stopPropagation(); handleDockNode && handleDockNode(node.id, 'right'); }}
                                                className="text-gray-400 hover:text-white transition-colors p-1"
                                            >
                                                <PinRightIcon />
                                            </button>
                                        </Tooltip>

                                        {/* NEW: Vertical Right Cycle */}
                                        {!isRestricted && (
                                            <Tooltip content={t('toolbar.dock.cycleVerticalRight') || "Cycle Vertical Right (TR/BR)"}>
                                                <button
                                                    onClick={(e) => { e.stopPropagation(); handleVerticalDockCycle('right'); }}
                                                    className="text-gray-400 hover:text-white transition-colors p-1"
                                                >
                                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                                                        <path d="M7 15l5 5 5-5" />
                                                        <path d="M7 9l5-5 5 5" />
                                                    </svg>
                                                </button>
                                            </Tooltip>
                                        )}

                                        {/* Move Dock Right (Horizontal Cycle) */}
                                        {!isRestricted && (
                                            <Tooltip content={t('toolbar.dock.cycleHorizontalRight') || "Cycle Horizontal Right"}>
                                                <button
                                                    onClick={(e) => { e.stopPropagation(); handleDockCycle(1); }}
                                                    className="text-gray-400 hover:text-white transition-colors p-1"
                                                >
                                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M9 18l6-6-6-6" /></svg>
                                                </button>
                                            </Tooltip>
                                        )}
                                    </>
                                )}

                                {isFullScreen ? (
                                    <Tooltip content={t('toolbar.dock.exitFull')}>
                                        <button
                                            onClick={(e) => { e.stopPropagation(); toggleNodeFullScreen?.(null); }}
                                            className="text-cyan-400 hover:text-white transition-colors p-1"
                                        >
                                            <ExitFullScreenIcon />
                                        </button>
                                    </Tooltip>
                                ) : (
                                    <Tooltip content={t('toolbar.dock.fullFocus')}>
                                        <button
                                            onClick={handleFullFocus}
                                            className="text-gray-400 hover:text-white transition-colors p-1"
                                        >
                                            <FullScreenIcon />
                                        </button>
                                    </Tooltip>
                                )}

                                <Tooltip content={t('toolbar.detach')}>
                                    <button
                                        onClick={(e) => { e.stopPropagation(); if (isFullScreen) toggleNodeFullScreen?.(null); handleUndockNode(node.id); }}
                                        className="text-gray-400 hover:text-white transition-colors ml-1 p-1"
                                    >
                                        <DetachIcon />
                                    </button>
                                </Tooltip>
                            </>
                        )}
                    </div>
                </>
            )}
        </div>
    );
};
