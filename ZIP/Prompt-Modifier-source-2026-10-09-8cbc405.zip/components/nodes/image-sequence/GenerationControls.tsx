
import React, { useMemo } from 'react';
import CustomSelect from '../../CustomSelect';
import { CustomCheckbox } from '../../CustomCheckbox';
import { getImageModelCapabilities } from '../../../services/modelConfig';

interface GenerationControlsProps {
    model: string;
    aspectRatio: string;
    resolution: string;
    autoCrop169: boolean;
    autoDownload: boolean;
    createZip: boolean;
    isGeneratingSequence: boolean;
    isAnyFrameGenerating: boolean;
    checkedCount: number;
    promptsLength: number;
    onUpdateState: (updates: any) => void;
    onGenerateSelected: () => void;
    onDownloadSelected: () => void;
    onStartQueue: () => void;
    onExpandSelected: (ratio: string) => void;
    t: (key: string) => string;
}

export const GenerationControls: React.FC<GenerationControlsProps> = ({
    model,
    aspectRatio,
    resolution,
    autoCrop169,
    autoDownload,
    createZip,
    isGeneratingSequence,
    isAnyFrameGenerating,
    checkedCount,
    promptsLength,
    onUpdateState,
    onGenerateSelected,
    onDownloadSelected,
    onStartQueue,
    onExpandSelected,
    t
}) => {
    
    const modelOptions = [
        { value: 'imagen-4.0-generate-001', label: 'Imagen 4.0' },
        { value: 'gemini-nano-banana-2.1', label: 'Gemini 3.6 Flash Image (Nana Banana 2.1)' },
        { value: 'gemini-3-pro-image-preview', label: 'Gemini 3.0 Pro Image (Nano Banana Pro)' },
        { value: 'gemini-3.1-flash-image', label: 'Gemini 3.1 Flash Image (Nano Banana 2)' },
        { value: 'gemini-3.1-flash-image-preview', label: 'Gemini 3.1 Flash Image Preview (Nana Banana 2 Lite)' },
        { value: 'gemini-2.5-flash-image', label: 'Gemini 2.5 Flash Image (Nano Banana)' }
    ];

    const capabilities = useMemo(() => getImageModelCapabilities(model), [model]);
    const aspectRatios = useMemo(() => capabilities.supportedAspectRatios.map(r => ({ value: r, label: r })), [capabilities]);
    const resolutions = useMemo(() => capabilities.supportedResolutions.map(r => ({ value: r, label: r })), [capabilities]);
    const showResolution = resolutions.length > 0;

    return (
        <div className="flex-shrink-0 space-y-2 mt-2">
            {/* Top Row: Model | Aspect Ratio | Resolution */}
            <div className="flex gap-2">
                <div className="flex-grow">
                    <label className="block text-xs font-medium text-gray-400 mb-1">{t('node.content.generationMode')}</label>
                    <CustomSelect
                        value={model}
                        onChange={(value) => onUpdateState({ model: value })}
                        disabled={isGeneratingSequence}
                        options={modelOptions}
                    />
                </div>
                
                <div className="w-24 flex-shrink-0">
                    <label className="block text-xs font-medium text-gray-400 mb-1">{t('node.content.aspectRatio')}</label>
                    <CustomSelect
                        value={aspectRatio || '1:1'}
                        onChange={(value) => onUpdateState({ aspectRatio: value })}
                        disabled={isGeneratingSequence}
                        options={aspectRatios}
                    />
                </div>

                {showResolution && (
                    <div className="w-24 flex-shrink-0 animate-fade-in">
                        <label className="block text-xs font-medium text-gray-400 mb-1">Resolution</label>
                        <CustomSelect
                            value={resolution || '1K'}
                            onChange={(value) => onUpdateState({ resolution: value })}
                            disabled={isGeneratingSequence}
                            options={resolutions}
                        />
                    </div>
                )}
            </div>

            <div className="flex flex-wrap gap-x-4 gap-y-2">
                <CustomCheckbox 
                    id="auto-crop-169"
                    checked={!!autoCrop169}
                    onChange={(checked) => onUpdateState({ autoCrop169: checked })}
                    label={t('image_sequence.auto_crop')}
                    title={t('image_sequence.tooltip.autoCrop')}
                    className="text-sm text-gray-300"
                />
                <CustomCheckbox 
                    id="auto-download"
                    checked={autoDownload}
                    onChange={(checked) => onUpdateState({ autoDownload: checked })}
                    label={t('node.content.autoDownload')}
                    title={t('image_sequence.tooltip.autoDownload')}
                    className="text-sm text-gray-300"
                />
                <CustomCheckbox 
                    id="create-zip"
                    checked={!!createZip}
                    onChange={(checked) => onUpdateState({ createZip: checked })}
                    label={t('image_sequence.create_zip')}
                    title={t('image_sequence.tooltip.createZip')}
                    className="text-sm text-gray-300"
                />
            </div>
            <div className="flex space-x-2 mb-2">
                <button 
                    onClick={onGenerateSelected} 
                    disabled={isGeneratingSequence || isAnyFrameGenerating || checkedCount === 0} 
                    className="flex-1 py-2 text-sm font-semibold text-white bg-accent-secondary hover:bg-accent-secondary-hover rounded-md disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors"
                >
                    {t('image_sequence.run_selected')} ({checkedCount})
                </button>
                
                {/* Batch Expand Buttons */}
                <button 
                    onClick={() => onExpandSelected('16:9')}
                    disabled={isGeneratingSequence || isAnyFrameGenerating || checkedCount === 0}
                    className="flex-shrink-0 w-20 py-2 text-xs font-bold text-white bg-accent hover:bg-accent-hover rounded-md disabled:bg-gray-700 disabled:text-gray-500 transition-colors flex items-center justify-center gap-2"
                    title="Expand Selected to 16:9"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="currentColor" viewBox="0 0 24 24"><rect x="2" y="8" width="20" height="8" rx="1" /></svg>
                    16:9
                </button>
                <button 
                    onClick={() => onExpandSelected('9:16')}
                    disabled={isGeneratingSequence || isAnyFrameGenerating || checkedCount === 0}
                    className="flex-shrink-0 w-20 py-2 text-xs font-bold text-white bg-accent hover:bg-accent-hover rounded-md disabled:bg-gray-700 disabled:text-gray-500 transition-colors flex items-center justify-center gap-2"
                    title="Expand Selected to 9:16"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="currentColor" viewBox="0 0 24 24"><rect x="8" y="2" width="8" height="20" rx="1" /></svg>
                    9:16
                </button>

                <button 
                    onClick={onDownloadSelected} 
                    disabled={checkedCount === 0} 
                    className="flex-1 py-2 text-sm font-semibold text-white bg-accent-secondary hover:bg-accent-secondary-hover rounded-md disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors"
                >
                    {createZip ? 'Download ZIP' : `${t('image_sequence.download_selected')} (${checkedCount})`}
                </button>
            </div>
            <div>
               <button 
                   onClick={onStartQueue} 
                   disabled={isGeneratingSequence || isAnyFrameGenerating || promptsLength === 0} 
                   className={`w-full py-2 rounded-md font-semibold transition-colors ${
                       isGeneratingSequence || isAnyFrameGenerating 
                           ? 'bg-gray-600 text-gray-300 cursor-not-allowed' 
                           : 'bg-accent hover:bg-accent-hover text-white'
                   }`}
               >
                   {(isGeneratingSequence || isAnyFrameGenerating) ? t('node.content.generating') : t('image_sequence.start_queue')}
               </button>
            </div>
        </div>
    );
};
