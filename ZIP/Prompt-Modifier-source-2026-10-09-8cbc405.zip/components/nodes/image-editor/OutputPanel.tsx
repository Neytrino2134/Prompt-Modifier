import { VisibleImage } from '../../VisibleImage';


import React, { useState, useRef, useEffect, useMemo } from 'react';
import { ActionButton } from '../../ActionButton';
import { ChevronLeft, ChevronRight, Banana, Sparkles, Zap, Image as ImageIcon, X, Square, StickyNote } from 'lucide-react';
import CustomSelect from '../../CustomSelect';
import { ImageEditorState, ImageSlot } from './types';
import { CopyIcon } from '../../../components/icons/AppIcons';
import { Tooltip } from '../../Tooltip';
import { EditorTooltip } from './EditorTooltip';
import JSZip from 'jszip';
import { CustomCheckbox } from '../../CustomCheckbox';
import { DebouncedTextarea } from '../../DebouncedTextarea';
import { setupImageDragData } from '../../../utils/imageUtils';
import ConfirmDialog from '../../ConfirmDialog';
import { useAppSelector } from '../../../contexts/AppContext';
import { ImageModelOption, isGptImage2Model, isOpenAiImageModel, resolveImageEditorModel, isNanoBanana21Model, getImageModelCapabilities } from '../../../services/modelConfig';
import { OptimizedThumbnail } from './OptimizedThumbnail';
import { ThinkingToggleDropdown } from './ThinkingToggleDropdown';
import { SearchToggleDropdown } from './SearchToggleDropdown';
import { ModelSelectorDropdown } from './ModelSelectorDropdown';
import { AspectRatioDropdown } from './AspectRatioDropdown';
import { ResolutionDropdown } from './ResolutionDropdown';

// Helper component for input with stylish spinners

const getModelIcon = (modelValue: string) => {
    if (isNanoBanana21Model(modelValue)) return <div className="flex -space-x-1 items-center"><Banana className="w-4 h-4 text-amber-400" /><Sparkles className="w-3 h-3 text-amber-300 relative -top-1" /></div>;
    if (modelValue === 'gemini-3-pro-image-preview') return <div className="flex -space-x-1 items-center"><Banana className="w-4 h-4 text-yellow-400" /><Sparkles className="w-3 h-3 text-yellow-300 relative -top-1" /></div>;
    if (modelValue === 'gemini-3.1-flash-image') return <div className="flex -space-x-1 items-center"><Banana className="w-4 h-4 text-yellow-400" /><Zap className="w-3 h-3 text-blue-400 relative -top-1" /></div>;
    if (modelValue === 'gemini-3.1-flash-image-preview') return <div className="flex -space-x-1 items-center"><Banana className="w-4 h-4 text-gray-400" /><Zap className="w-3 h-3 text-blue-300 relative -top-1" /></div>;
    if (modelValue === 'gemini-2.5-flash-image') return <Banana className="w-4 h-4 text-yellow-500" />;
    return <ImageIcon className="w-4 h-4 text-gray-400" />;
};

const getModelShortName = (modelValue: string, label: string) => {
    if (isNanoBanana21Model(modelValue)) return 'Nana Banana 2.1 (3.6)';
    if (modelValue === 'gemini-3-pro-image-preview') return 'Nano Banana Pro 3.0';
    if (modelValue === 'gemini-3.1-flash-image') return 'Nano Banana 2 (3.1)';
    if (modelValue === 'gemini-3.1-flash-image-preview') return 'Nano Banana 2 Lite (3.1)';
    if (modelValue === 'gemini-2.5-flash-image') return 'Nano Banana (2.5)';
    return label;
};

const InputWithSpinners: React.FC<{
    value: string;
    placeholder?: string;
    onChange: (val: string) => void;
    min?: number;
    className?: string;
    title?: string;
}> = ({ value, placeholder, onChange, min, className, title }) => {
    const handleStep = (step: number) => {
        const currentVal = parseInt(value, 10);
        let nextVal = isNaN(currentVal) ? (min || 1) : currentVal + step;
        if (min !== undefined && nextVal < min) nextVal = min;
        onChange(nextVal.toString());
    };
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = e.target.value;
        if (val === '') {
            onChange('');
            return;
        }
        const num = parseInt(val, 10);
        if (!isNaN(num) && min !== undefined && num < min) {
             return; 
        }
        onChange(val);
    };

    return (
        <div className={`relative flex items-center bg-gray-800 rounded border border-gray-600 h-6 ${className}`} title={title}>
             <input
                type="number"
                min={min}
                value={value}
                placeholder={placeholder}
                onChange={handleChange}
                className="appearance-none w-full h-full bg-transparent text-[10px] text-white text-center focus:outline-none px-1 placeholder-gray-500 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                onClick={e => e.stopPropagation()}
                onMouseDown={e => e.stopPropagation()}
            />
             <div className="flex flex-col h-full border-l border-gray-600 w-3 flex-shrink-0">
                <button 
                    className="h-1/2 flex items-center justify-center hover:bg-gray-700 text-gray-400 hover:text-white transition-colors"
                    onClick={(e) => { e.stopPropagation(); handleStep(1); }}
                >
                    <svg width="6" height="3" viewBox="0 0 8 4" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 0L8 4H0L4 0Z" fill="currentColor"/></svg>
                </button>
                <button 
                    className="h-1/2 flex items-center justify-center hover:bg-gray-700 text-gray-400 hover:text-white transition-colors border-t border-gray-600"
                    onClick={(e) => { e.stopPropagation(); handleStep(-1); }}
                >
                    <svg width="6" height="3" viewBox="0 0 8 4" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 4L0 0H8L4 4Z" fill="currentColor"/></svg>
                </button>
             </div>
        </div>
    );
};

interface OutputPanelProps {
    state: ImageEditorState;
    imageSlots: ImageSlot[];
    hasInputImages: boolean;
    isEditing: boolean;
    isStopping: boolean;
    isGlobalProcessing: boolean;
    totalFrames: number;
    doneCount: number;
    currentGeneratingDisplay: string | number;
    fullSizeOutputForCopy: string | null;
    imageForEditor: string | null;
    modelOptions: (ImageModelOption | { value: string; label: string })[];
    isNanoBanana: boolean;
    onUpdateState: (updates: Partial<ImageEditorState>) => void;
    onRunSelected: () => void;
    onDownloadSelected: () => void;
    onDownloadSelectedZip: () => void;
    onStartQueue: () => void;
    onStop: () => void;
    onEdit: () => void;
    onOpenEditor: () => void;
    onSetOutputToInput: () => void;
    onDownload: () => void;
    onCopy: () => void;
    onSelectAll: () => void;
    onSelectNone: () => void;
    onInvertSelection: () => void;
    onManualRefresh: () => void;
    onOutputClick: () => void;
    onSequenceOutputClick: (index: number, src: string) => void;
    onCheckOutput: (index: number) => void;
    onCopyFrame: (e: React.MouseEvent, index: number, original?: string | null) => void;
    onDownloadFrame: (e: React.MouseEvent, index: number) => void;
    onRegenerateFrame: (e: React.MouseEvent, index: number) => void;
    onStopFrame: (e: React.MouseEvent, index: number) => void;
    getFullSizeImage: (frameIndex: number) => string | undefined;
    t: (key: string) => string;
    upstreamPrompt?: string;
    upstreamPromptsCount?: number;
    isTextConnected?: boolean;
    // New Props for Editing
    onEditPrompt: (index: number) => void;
    onEditInSource: (index: number) => void;
    deselectAllNodes: () => void;
    nodeId: string;
    onClearOutputs?: () => void;
    onSendToNote?: () => void;
}

const ITEM_SIZE = 136;
const GAP = 8; // gap-2 is 0.5rem = 8px

export const OutputPanel: React.FC<OutputPanelProps> = ({
    state, imageSlots, hasInputImages, isEditing, isStopping, isGlobalProcessing,
    totalFrames, doneCount, currentGeneratingDisplay, fullSizeOutputForCopy, imageForEditor,
    modelOptions, isNanoBanana,
    onUpdateState, onRunSelected, onDownloadSelected, onDownloadSelectedZip, onStartQueue, onStop, onEdit, onOpenEditor, onSetOutputToInput,
    onDownload, onCopy, onSelectAll, onSelectNone, onInvertSelection, onManualRefresh,
    onOutputClick, onSequenceOutputClick, onCheckOutput, onCopyFrame, onDownloadFrame, onRegenerateFrame, onStopFrame,
    getFullSizeImage, t, upstreamPrompt, upstreamPromptsCount, isTextConnected,
    onEditPrompt, onEditInSource, deselectAllNodes, nodeId, onClearOutputs, onSendToNote
}) => {
    const { isSequenceMode, sequenceOutputs, checkedSequenceOutputIndices, model, autoCrop169, autoInsertResults, autoSaveImages, checkedInputIndices, prompt, outputImage, resolution, quality, outputFormat, size, thinkingLevel, searchGrounding, isSequentialEditingWithPrompts, createZip, enableAspectRatio, enableOutpainting, outpaintingPrompt, aspectRatio } = state;
    const { isBatchMode, isForming, activeBatchJob, isBatchActive, cancelBatchForNode } = useAppSelector(context => ({
        isBatchMode: context.isBatchMode,
        isForming: context.isFormingBatch?.(nodeId) || false,
        activeBatchJob: context.getNodeActiveBatchJob?.(nodeId),
        isBatchActive: context.isNodeBatchActive?.(nodeId) || false,
        cancelBatchForNode: context.cancelBatchForNode
    }));
    
    // Range State
    const [rangeStart, setRangeStart] = useState('');
    const [rangeEnd, setRangeEnd] = useState('');

    // Confirmation State for Clearing Outputs
    const [showConfirmClear, setShowConfirmClear] = useState(false);

    // Confirmation State for Cancelling Batch Formation & Server Request
    const [showConfirmCancelBatch, setShowConfirmCancelBatch] = useState(false);

    // Confirmation State for Run Batch / Run Selected (Sequence Mode)
    const [showConfirmRun, setShowConfirmRun] = useState(false);
    const pendingRunRef = useRef<(() => void) | null>(null);

    const triggerRunWithConfirmation = (action: () => void) => {
        if (isBatchMode || isSequenceMode) {
            pendingRunRef.current = action;
            setShowConfirmRun(true);
        } else {
            action();
        }
    };

    const handleConfirmRun = () => {
        setShowConfirmRun(false);
        if (pendingRunRef.current) {
            pendingRunRef.current();
            pendingRunRef.current = null;
        }
    };

    const handleConfirmClear = () => {
        setShowConfirmClear(false);
        if (onClearOutputs) {
            onClearOutputs();
        } else {
            onUpdateState({ sequenceOutputs: [], checkedSequenceOutputIndices: [] });
        }
    };

    const handleConfirmCancelBatch = async () => {
        setShowConfirmCancelBatch(false);
        if (cancelBatchForNode) {
            await cancelBatchForNode(nodeId);
        }
        if (onStop) {
            onStop();
        }
    };

    // Virtualization State
    const containerRef = useRef<HTMLDivElement>(null);
    const [scrollTop, setScrollTop] = useState(0);
    const [containerWidth, setContainerWidth] = useState(0);

    const effectiveModel = resolveImageEditorModel(model);
    const isNanoBanana21 = isNanoBanana21Model(effectiveModel);
    const isGpt2 = isGptImage2Model(effectiveModel);
    const isDalle3 = effectiveModel === 'dall-e-3';
    const isDalle2 = effectiveModel === 'dall-e-2';

    const capabilities = useMemo(() => getImageModelCapabilities(effectiveModel), [effectiveModel]);
    const availableAspectRatios = capabilities.supportedAspectRatios;
    const availableResolutions = capabilities.supportedResolutions;
    const availableThinkingLevels = capabilities.supportedThinkingLevels;

    const showAspectRatio = availableAspectRatios.length > 0;
    const showResolution = availableResolutions.length > 0;
    const showThinking = availableThinkingLevels.length > 0;
    const showSearchGrounding = capabilities.supportedSearchTypes.length > 0;
    const showQuality = capabilities.supportsQuality;
    const showGptSize = capabilities.supportsSize;
    const showOutputFormat = capabilities.supportsOutputFormat;

    const gpt2QualityOptions = [
        { value: 'standard', label: 'Standard' },
        { value: 'hd', label: 'HD' },
        { value: 'high', label: 'High' },
        { value: 'medium', label: 'Medium' },
        { value: 'low', label: 'Low' },
    ];
    const dalle3QualityOptions = [
        { value: 'standard', label: 'Standard' },
        { value: 'hd', label: 'HD' },
    ];
    const gpt2SizeOptions = [
        { value: '1024x1024', label: '1024x1024' },
        { value: '1536x1024', label: '1536x1024' },
        { value: '1024x1536', label: '1024x1536' },
        { value: 'auto', label: 'Auto' },
    ];
    const dalle2SizeOptions = [
        { value: '1024x1024', label: '1024x1024' },
        { value: '512x512', label: '512x512' },
        { value: '256x256', label: '256x256' },
    ];
    const gpt2FormatOptions = [
        { value: 'png', label: 'PNG' },
        { value: 'jpeg', label: 'JPEG' },
        { value: 'webp', label: 'WebP' },
    ];

    useEffect(() => {
        if (!isSequenceMode || !containerRef.current) return;
        const observer = new ResizeObserver((entries) => {
            if (entries[0]) setContainerWidth(entries[0].contentRect.width);
        });
        observer.observe(containerRef.current);
        return () => observer.disconnect();
    }, [isSequenceMode]);

    // Active frame indices that should be shown in the sequence output grid
    const activeFrameIndices = useMemo(() => {
        if (isSequentialEditingWithPrompts) {
            return Array.from({ length: totalFrames }, (_, i) => i);
        }
        if (!checkedInputIndices) {
            return imageSlots.map((_, i) => i);
        }
        return imageSlots
            .map((_, i) => i)
            .filter(i => checkedInputIndices.includes(i));
    }, [isSequentialEditingWithPrompts, totalFrames, checkedInputIndices, imageSlots]);

    const activeSelectedCount = useMemo(() => {
        return checkedSequenceOutputIndices.filter(i => activeFrameIndices.includes(i)).length;
    }, [checkedSequenceOutputIndices, activeFrameIndices]);

    // Validation: prompt presence and input selection
    const hasValidPrompt = useMemo(() => {
        if (isSequentialEditingWithPrompts) {
            const hasAnyFramePrompt = Object.values(state.framePrompts || {}).some(p => typeof p === 'string' && !!p.trim());
            const hasUpstreamMapPrompts = (upstreamPromptsCount || 0) > 0;
            const hasGlobalPrompt = isTextConnected ? (!!upstreamPrompt?.trim() || hasUpstreamMapPrompts) : !!prompt?.trim();
            return hasAnyFramePrompt || hasGlobalPrompt;
        }
        if (isTextConnected) {
            return !!upstreamPrompt?.trim() || (upstreamPromptsCount || 0) > 0;
        }
        return !!prompt?.trim();
    }, [isSequentialEditingWithPrompts, state.framePrompts, upstreamPromptsCount, isTextConnected, upstreamPrompt, prompt]);

    const hasCheckedInputImages = useMemo(() => {
        return !!(checkedInputIndices && checkedInputIndices.length > 0);
    }, [checkedInputIndices]);

    const isMainActionDisabled = useMemo(() => {
        if (isEditing || isForming || !!activeBatchJob) return false;

        if (isSequenceMode) {
            // Sequence Mode ('Run selected'):
            // 1. Must have valid prompt (field prompt or connected upstream prompt)
            if (!hasValidPrompt) return true;
            // 2. Must have at least one output image selected
            if (activeSelectedCount === 0) return true;
            // 3. If sequence mode has input images, must have at least one input image selected
            if (!isSequentialEditingWithPrompts && hasInputImages && !hasCheckedInputImages) return true;
            return false;
        } else {
            // Single Mode:
            if (hasInputImages) {
                // 'Apply Edit':
                // 1. Must have at least one input image selected
                if (!hasCheckedInputImages) return true;
                // 2. Must have valid prompt
                if (!hasValidPrompt) return true;
                return false;
            } else {
                // 'Generate Image' (Text-to-image without input image):
                // 1. Must have valid prompt
                if (!hasValidPrompt) return true;
                return false;
            }
        }
    }, [isEditing, isForming, activeBatchJob, isSequenceMode, hasValidPrompt, activeSelectedCount, isSequentialEditingWithPrompts, hasInputImages, hasCheckedInputImages]);

    const confirmRunDetails = useMemo(() => {
        const rawPrompt = isTextConnected ? (upstreamPrompt || prompt) : prompt;
        const promptDisplay = rawPrompt?.trim()
            ? (rawPrompt.length > 120 ? `${rawPrompt.substring(0, 117)}...` : rawPrompt)
            : (isSequentialEditingWithPrompts ? t('node.content.framePrompts') || 'Индивидуальные промпты кадров' : t('common.empty') || 'Пустой');

        const imagesCountDisplay = isSequenceMode
            ? `${activeSelectedCount} ${t('common.items') || 'шт.'}`
            : `1 ${t('common.items') || 'шт.'}`;

        const modelDisplay = getModelShortName(effectiveModel, effectiveModel);
        const aspectRatioDisplay = showAspectRatio ? (aspectRatio || '1:1') : 'Auto (1:1)';
        const resolutionDisplay = showResolution 
            ? (resolution || '1K') 
            : showQuality 
                ? (quality || 'standard') 
                : showGptSize 
                    ? (size || '1024x1024') 
                    : '1K (Standard)';
        const modeDisplay = isBatchMode 
            ? `${t('batch.mode') || 'Batch API'} (-50%)` 
            : `${t('stats.normalMode') || 'Realtime'}`;

        const question = t('dialog.confirmRun.question') || 'Вы действительно проверили промпт, количество изображений, выбранную модель, соотношение и разрешение?';
        const lblPrompt = t('dialog.confirmRun.prompt') || 'Промпт';
        const lblCount = t('dialog.confirmRun.imagesCount') || 'Количество изображений';
        const lblModel = t('dialog.confirmRun.model') || 'Модель';
        const lblAspect = t('dialog.confirmRun.aspectRatio') || 'Соотношение сторон';
        const lblResolution = t('dialog.confirmRun.resolution') || 'Разрешение / Качество';
        const lblMode = t('dialog.confirmRun.mode') || 'Режим генерации';

        const message = `${question}\n\n• ${lblPrompt}: ${promptDisplay}\n• ${lblCount}: ${imagesCountDisplay}\n• ${lblModel}: ${modelDisplay}\n• ${lblAspect}: ${aspectRatioDisplay}\n• ${lblResolution}: ${resolutionDisplay}\n• ${lblMode}: ${modeDisplay}`;

        return {
            title: t('dialog.confirmRun.title') || 'Проверка параметров перед запуском',
            message,
        };
    }, [isTextConnected, upstreamPrompt, prompt, isSequentialEditingWithPrompts, isSequenceMode, activeSelectedCount, effectiveModel, showAspectRatio, aspectRatio, showResolution, resolution, showQuality, quality, showGptSize, size, isBatchMode, t]);

    // Layout Calculations
    const layout = useMemo(() => {
        if (!isSequenceMode) return { columns: 0, totalHeight: 0, totalItems: 0 };

        const effectiveWidth = Math.max(0, containerWidth - 16); // p-2 is 8px * 2
        const columns = Math.max(1, Math.floor((effectiveWidth + GAP) / (ITEM_SIZE + GAP)));
        
        const totalItems = activeFrameIndices.length;
        const totalRows = Math.ceil(totalItems / columns);
        const totalHeight = totalRows * (ITEM_SIZE + GAP) + GAP; // Add bottom padding

        return { columns, totalHeight, totalItems };
    }, [containerWidth, activeFrameIndices.length, isSequenceMode]);

    const getVisibleItems = () => {
        const { columns, totalItems } = layout;
        if (columns <= 0 || totalItems === 0) return [];

        const buffer = 400; // pixels to render offscreen
        const visibleStart = Math.max(0, scrollTop - buffer);
        const visibleEnd = scrollTop + (containerRef.current?.clientHeight || 500) + buffer;

        const startRow = Math.max(0, Math.floor(visibleStart / (ITEM_SIZE + GAP)));
        const endRow = Math.ceil(visibleEnd / (ITEM_SIZE + GAP));
        
        const visibleIndices = [];
        for (let r = startRow; r <= endRow; r++) {
            for (let c = 0; c < columns; c++) {
                const gridIndex = (r * columns) + c;
                if (gridIndex < totalItems) {
                    const originalIndex = activeFrameIndices[gridIndex];
                    visibleIndices.push({
                        gridIndex,
                        index: originalIndex,
                        top: r * (ITEM_SIZE + GAP),
                        left: c * (ITEM_SIZE + GAP)
                    });
                }
            }
        }
        return visibleIndices;
    };

    const handleSelectRange = () => {
        const start = parseInt(rangeStart, 10);
        const end = parseInt(rangeEnd, 10);
        
        if (isNaN(start)) return;
        
        // Total valid inputs for sequence
        const maxFrames = isSequentialEditingWithPrompts ? totalFrames : imageSlots.length;

        const effectiveEnd = isNaN(end) ? maxFrames : Math.min(end, maxFrames);
        const effectiveStart = Math.max(1, start);
        
        if (effectiveStart > effectiveEnd) return;

        const newIndices: number[] = [];
        // Convert 1-based input to 0-based index
        for(let i = effectiveStart - 1; i < effectiveEnd; i++) {
            if (activeFrameIndices.includes(i)) {
                newIndices.push(i);
            }
        }
        onUpdateState({ checkedSequenceOutputIndices: newIndices });
    };
    
    const handlePage = (direction: 'prev' | 'next') => {
        const currentStart = parseInt(rangeStart, 10) || 1;
        const pageSize = 5;
        // Logic: Snap to next/prev block of 5
        let pageNum = Math.ceil(currentStart / pageSize);
        if (direction === 'next') pageNum++;
        else pageNum--;
        
        if (pageNum < 1) pageNum = 1;
        
        const maxFrames = isSequentialEditingWithPrompts ? totalFrames : imageSlots.length;

        const newStart = (pageNum - 1) * pageSize + 1;
        const newEnd = Math.min(newStart + pageSize - 1, maxFrames);
        
        setRangeStart(newStart.toString());
        setRangeEnd(newEnd.toString());
        
        // Apply Selection immediately
        const newIndices: number[] = [];
        for(let i = newStart - 1; i < newEnd; i++) {
            if (activeFrameIndices.includes(i)) {
                newIndices.push(i);
            }
        }
        onUpdateState({ checkedSequenceOutputIndices: newIndices });
    };
    
    const LargeCopyIcon = (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white/80" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <rect x="8" y="8" width="12" height="12" rx="2" ry="2" />
            <path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" />
        </svg>
    );

    return (
        <div className="h-full flex flex-col space-y-2 flex-grow min-w-0 pl-1">
             
             {/* Header Row: Title, Stats and Reset/Clear Button */}
             <div className="flex justify-between items-center bg-gray-900/50 p-1 rounded-md border border-gray-700">
                <div className="flex items-center gap-2">
                     <label className="text-xs font-medium text-gray-400 pl-1">{isSequenceMode ? t('image_sequence.output_images_title') : t('node.content.outputImage')}</label>
                     {isBatchMode && (
                         <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-gray-800 text-accent-secondary border border-gray-700 flex items-center gap-1" title={t('batch.modeDesc') || 'Batch API Mode (-50% cost)'}>
                             <span className="w-1.5 h-1.5 rounded-full bg-accent-secondary animate-pulse"></span>
                             {t('batch.badgeDelayed') || 'Batch'}
                         </span>
                     )}
                     {isSequenceMode && (
                         <div className="text-[10px] text-gray-500 flex space-x-2 border-l border-gray-600 pl-3">
                             <span>Total: <span className="text-gray-300">{activeFrameIndices.length}</span></span>
                             <span className={doneCount > 0 ? "text-cyan-400 font-semibold" : ""}>Done: {doneCount}</span>
                             <span className="text-emerald-400">Selected: {activeSelectedCount}</span>
                             {isEditing && <span className="text-cyan-400 animate-pulse">Processing: {currentGeneratingDisplay} of {activeFrameIndices.length}</span>}
                         </div>
                     )}
                </div>

                {isSequenceMode && (
                    <div className="flex items-center gap-1">
                        <button
                            type="button"
                            onClick={() => setShowConfirmClear(true)}
                            disabled={isEditing || (sequenceOutputs.length === 0 && doneCount === 0)}
                            title={t('image_sequence.clear_outputs_tooltip') || "Clear generated images and reset state"}
                            className={`flex items-center gap-1 px-1.5 py-0.5 text-[10px] font-medium rounded transition-colors ${
                                isEditing || (sequenceOutputs.length === 0 && doneCount === 0)
                                    ? 'text-gray-600 bg-transparent cursor-not-allowed opacity-50'
                                    : 'text-gray-300 hover:text-red-300 bg-gray-800 hover:bg-red-950/50 border border-gray-700 hover:border-red-700/60'
                            }`}
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                            <span>{t('image_sequence.clear_outputs') || "Clear State"}</span>
                        </button>
                    </div>
                )}
             </div>

             {/* Second Row: Toolbar (Only visible in Sequence Mode) */}
             {isSequenceMode && (
                 <div className="flex justify-between items-center bg-gray-900/50 p-1 rounded-md border border-gray-700">
                     {/* Left: Range Selector */}
                     <div className="flex items-center space-x-1 pl-1">
                         {/* Removed 'border border-gray-700' from the container as requested */}
                         <div className="flex items-center gap-1 bg-gray-800 rounded p-0.5">
                                <InputWithSpinners 
                                    value={rangeStart}
                                    onChange={setRangeStart}
                                    placeholder="1"
                                    title="Start Index"
                                    className="w-12 border-none" 
                                    min={1}
                                />
                                <span className="text-[10px] text-gray-500">-</span>
                                <InputWithSpinners 
                                    value={rangeEnd}
                                    onChange={setRangeEnd}
                                    placeholder={isSequentialEditingWithPrompts ? totalFrames.toString() : imageSlots.length.toString()}
                                    title="End Index"
                                    className="w-12 border-none" 
                                    min={1}
                                />
                                
                                {/* Grouped Arrows Right Side */}
                                <div className="flex items-center ml-1 border-l border-gray-600 pl-1">
                                     <button 
                                        className="p-0.5 text-gray-400 hover:text-white transition-colors"
                                        onClick={(e) => { e.stopPropagation(); handlePage('prev'); }}
                                        title="Previous 5"
                                    >
                                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M15 18l-6-6 6-6" /></svg>
                                    </button>
                                     <button 
                                        className="p-0.5 text-gray-400 hover:text-white transition-colors"
                                        onClick={(e) => { e.stopPropagation(); handlePage('next'); }}
                                        title="Next 5"
                                    >
                                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M9 18l6-6-6-6" /></svg>
                                    </button>
                                </div>

                                <div className="w-px h-3 bg-gray-600 mx-1"></div>
                                <button 
                                    onClick={handleSelectRange} 
                                    className="p-0.5 text-gray-400 hover:text-white transition-colors"
                                    title="Select Range"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                                    </svg>
                                </button>
                         </div>
                     </div>

                     {/* Right: Actions */}
                     <div className="flex items-center space-x-1">
                            <EditorTooltip title={t('image_sequence.select_all')} description="Выбрать все доступные кадры в последовательности">
                                <ActionButton title="" onClick={onSelectAll} disabled={activeFrameIndices.length === 0}>
                                    <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 ${activeFrameIndices.length === 0 ? 'text-gray-600' : 'text-green-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                </ActionButton>
                            </EditorTooltip>

                            <EditorTooltip title={t('image_sequence.select_none')} description="Снять выбор со всех кадров">
                                <ActionButton title="" onClick={onSelectNone} disabled={activeSelectedCount === 0}>
                                    <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 ${activeSelectedCount === 0 ? 'text-gray-600' : 'text-red-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15 12H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                </ActionButton>
                            </EditorTooltip>

                            <EditorTooltip title={t('image_sequence.invert_selection')} description="Инвертировать выбор кадров">
                                <ActionButton title="" onClick={onInvertSelection} disabled={activeFrameIndices.length === 0}>
                                    <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 ${activeFrameIndices.length === 0 ? 'text-gray-600' : 'text-gray-300'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg>
                                </ActionButton>
                            </EditorTooltip>

                            <div className="w-px h-4 bg-gray-600 mx-1"></div>

                            <EditorTooltip title={t('image_sequence.run_selected')} description="Запустить генерацию или обработку для выбранных кадров">
                                <ActionButton 
                                    title="" 
                                    onClick={() => triggerRunWithConfirmation(onRunSelected)} 
                                    disabled={isEditing || activeSelectedCount === 0 || !hasValidPrompt || (!isSequentialEditingWithPrompts && hasInputImages && !hasCheckedInputImages)}
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 ${(isEditing || activeSelectedCount === 0 || !hasValidPrompt || (!isSequentialEditingWithPrompts && hasInputImages && !hasCheckedInputImages)) ? 'text-gray-600' : 'text-emerald-400'}`} viewBox="0 0 20 20" fill="currentColor">
                                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                                    </svg>
                                </ActionButton>
                            </EditorTooltip>

                            {/* Download Selected (individual files) */}
                            <EditorTooltip title={`${t('image_sequence.download_selected')} (${activeSelectedCount})`} description="Скачать выбранные кадры отдельными файлами">
                                <ActionButton title="" onClick={onDownloadSelected} disabled={activeSelectedCount === 0}>
                                    <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 ${(activeSelectedCount === 0) ? 'text-gray-600' : 'text-sky-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                    </svg>
                                </ActionButton>
                            </EditorTooltip>

                            {/* Download Selected as ZIP */}
                            <EditorTooltip title={`${t('image_sequence.download_selected_zip')} (${activeSelectedCount})`} description="Скачать все выбранные кадры единым архивом ZIP">
                                <ActionButton title="" onClick={onDownloadSelectedZip} disabled={activeSelectedCount === 0}>
                                    <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 ${(activeSelectedCount === 0) ? 'text-gray-600' : 'text-amber-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                                    </svg>
                                </ActionButton>
                            </EditorTooltip>

                            {/* Send to Note References */}
                            {onSendToNote && (
                                <EditorTooltip 
                                    title={t('imageEditor.sendFramesToNoteReferences') || "Send all frames to Note (References)"} 
                                    description={t('imageEditor.tooltip.sendFramesToNote') || "Создать ноду Note в режиме References и вложить все кадры/результаты туда"}
                                >
                                    <ActionButton 
                                        title="" 
                                        onClick={onSendToNote} 
                                        disabled={isEditing || (sequenceOutputs.length === 0 && doneCount === 0)}
                                    >
                                        <StickyNote className={`h-4 w-4 ${isEditing || (sequenceOutputs.length === 0 && doneCount === 0) ? 'text-gray-600' : 'text-amber-400 hover:text-amber-300'}`} />
                                    </ActionButton>
                                </EditorTooltip>
                            )}

                            <div className="w-px h-4 bg-gray-600 mx-1"></div>

                            <EditorTooltip title={t('image_sequence.clear_outputs_tooltip') || t('node.action.clear')} description="Очистить сгенерированные результаты и сбросить состояние">
                                <ActionButton 
                                    title="" 
                                    onClick={() => setShowConfirmClear(true)} 
                                    disabled={isEditing || (sequenceOutputs.length === 0 && doneCount === 0)}
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 ${isEditing || (sequenceOutputs.length === 0 && doneCount === 0) ? 'text-gray-600' : 'text-gray-300 hover:text-red-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                </ActionButton>
                            </EditorTooltip>
                            
                            <div className="w-px h-4 bg-gray-600 mx-1"></div>

                            <EditorTooltip title="Force Refresh" description="Принудительно перезагрузить и синхронизировать изображения">
                                <ActionButton title="" onClick={onManualRefresh}>
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-cyan-400" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 110 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" /></svg>
                                </ActionButton>
                            </EditorTooltip>
                     </div>
                 </div>
             )}
            
            {!isSequenceMode && (
                <div onClick={onOutputClick} onWheel={(e) => e.stopPropagation()} className="relative w-full flex-grow bg-gray-900/50 rounded-md flex items-center justify-center overflow-hidden group cursor-pointer">
                    {(outputImage || fullSizeOutputForCopy) ? <OptimizedThumbnail size={512} src={outputImage} fallbackSrc={fullSizeOutputForCopy} alt="Output" className="object-contain w-full h-full" onMouseDown={(e) => e.stopPropagation()} draggable={true} onDragStart={(e) => { const imageToDrag = fullSizeOutputForCopy || outputImage; if (imageToDrag) { setupImageDragData(e, imageToDrag, `Output_${Date.now()}.png`); e.stopPropagation(); }}}/> : <span className="text-gray-400">{t('node.content.imageHere')}</span>}
                    {outputImage && !isEditing && !isBatchActive && (
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none gap-4">
                            <button onClick={(e) => { e.stopPropagation(); onCopy(); }} className="w-20 h-20 flex items-center justify-center rounded-full bg-black/50 hover:bg-black/60 transition-colors pointer-events-auto" aria-label={t('node.action.copy')} title={t('node.action.copy')}>
                                {LargeCopyIcon}
                            </button>
                            <button onClick={(e) => { e.stopPropagation(); onDownload(); }} className="w-20 h-20 flex items-center justify-center rounded-full bg-black/50 hover:bg-black/60 transition-colors pointer-events-auto" aria-label={t('node.action.download')} title={t('node.action.download')}><svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white/80" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg></button>
                            {onSendToNote && (
                                <button onClick={(e) => { e.stopPropagation(); onSendToNote(); }} className="w-20 h-20 flex items-center justify-center rounded-full bg-black/50 hover:bg-black/60 transition-colors pointer-events-auto" aria-label={t('imageEditor.sendToNoteReferences') || "Send to Note References"} title={t('imageEditor.sendToNoteReferences') || "Send to Note References"}>
                                    <StickyNote className="h-10 w-10 text-amber-400/90 hover:text-amber-300" />
                                </button>
                            )}
                        </div>
                    )}
                    {(isEditing || isBatchActive) && (
                        <div className="absolute inset-0 bg-gray-800/80 backdrop-blur-sm flex flex-col items-center justify-center text-white z-10 px-4 text-center">
                            <svg className="animate-spin h-8 w-8 text-white mb-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            <span className="font-semibold text-sm">
                                {isForming 
                                    ? (t('batch.formingRequest') || 'Forming batch request...')
                                    : activeBatchJob 
                                        ? (t('batch.waitingForResponse') || 'Waiting for response from service')
                                        : (hasInputImages ? t('node.content.editing') : t('node.content.generating'))
                                }
                            </span>
                            {activeBatchJob && (
                                <span className="text-[11px] text-accent-secondary mt-1 font-mono">
                                    {activeBatchJob.displayName || activeBatchJob.name} ({activeBatchJob.state})
                                </span>
                            )}
                            {(isForming || activeBatchJob) && (
                                <button
                                    type="button"
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        setShowConfirmCancelBatch(true);
                                    }}
                                    className="mt-3 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-md shadow flex items-center gap-1.5 transition-colors cursor-pointer"
                                >
                                    <X className="w-3.5 h-3.5" />
                                    <span>{t('dialog.confirmCancelBatch.actionButton') || t('common.cancel') || 'Отмена batch'}</span>
                                </button>
                            )}
                        </div>
                    )}
                    {outputImage && !isBatchActive && (
                        <div className="absolute top-1 right-1 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            {onSendToNote && (
                                <ActionButton title={t('imageEditor.sendToNoteReferences') || "Send to Note References"} onClick={(e) => { e.stopPropagation(); onSendToNote(); }}>
                                    <StickyNote className="h-4 w-4 text-amber-400 hover:text-amber-300" />
                                </ActionButton>
                            )}
                            <ActionButton title={t('node.action.copy')} onClick={(e) => { e.stopPropagation(); onCopy(); }}>
                                <CopyIcon />
                            </ActionButton>
                            <ActionButton title={t('node.action.download')} onClick={(e) => { e.stopPropagation(); onDownload(); }}><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg></ActionButton>
                        </div>
                    )}
                </div>
            )}

            {isSequenceMode && (
                <div className="flex-grow min-h-0 flex flex-col space-y-2">
                    <div 
                        ref={containerRef}
                        className="flex-grow bg-gray-900/50 rounded-md overflow-y-auto p-2 custom-scrollbar relative"
                        onScroll={(e) => setScrollTop(e.currentTarget.scrollTop)}
                        onWheel={e => e.stopPropagation()}
                    >
                        <div style={{ height: layout.totalHeight, width: '100%', position: 'relative' }}>
                        {getVisibleItems().map(({ index, top, left }) => {
                            const slot = imageSlots[index];
                            // Allow slot to be undefined in Sequential Editing mode (we just need index existence)
                            if (!slot && !isSequentialEditingWithPrompts) return null;

                            const output = sequenceOutputs[index];
                            const isChecked = checkedSequenceOutputIndices.includes(index);
                            const isPending = output && output.status === 'pending';
                            const isGenerating = output && output.status === 'generating';
                            const isError = output && output.status === 'error';
                            const fullSizeUrl = getFullSizeImage(1000 + index);
                            const isGenerated = (output && output.status === 'done' && (output.thumbnail || fullSizeUrl)) || (!output && fullSizeUrl);
                            
                            // Visual Fallback Logic: prioritize thumbnail, fallback to cached full-res, then slot
                            let displaySrc = (output && output.thumbnail) || fullSizeUrl || (slot ? slot.src : null);
                            
                            // If in Sequential Editing With Prompts mode and we don't have a generated image yet
                            // AND there is no source image for this slot (because input B list is shorter than frames)
                            // Fallback to the first image from Input B (slot 0)
                            if (!isGenerated && isSequentialEditingWithPrompts && !displaySrc && imageSlots.length > 0) {
                                displaySrc = imageSlots[0].src;
                            }
                            
                            const isPreview = !isGenerated && !isPending && !isGenerating && !isError && displaySrc;
                            const originalSlot = slot || (isSequentialEditingWithPrompts ? imageSlots[0] : undefined);
                            const getSourceToView = () => isGenerated ? (fullSizeUrl || displaySrc) : (originalSlot?.getOriginal?.() || null);

                            // Calculate if this frame has an upstream connection for edit (if applicable)
                            const showEditActions = isSequentialEditingWithPrompts;

                            return (
                                <div 
                                    key={index} 
                                    className={`absolute rounded-lg border-2 overflow-hidden cursor-pointer border-gray-700 bg-gray-800 group`}
                                    style={{ top, left, width: ITEM_SIZE, height: ITEM_SIZE }}
                                    onClick={(e) => { e.stopPropagation(); onSequenceOutputClick(index, getSourceToView() || ''); }}
                                >
                                     {displaySrc ? (
                                        <OptimizedThumbnail 
                                            src={displaySrc}
                                            fallbackSrc={getSourceToView()}
                                            size={128}
                                            alt={`Output ${index + 1}`} 
                                            className={`w-full h-full object-contain ${isPreview ? 'opacity-60' : ''}`}
                                            draggable={true}
                                            onMouseDown={(e) => e.stopPropagation()}
                                            onDragStart={(e) => {
                                                const srcToDrag = getSourceToView();
                                                if (srcToDrag) {
                                                    setupImageDragData(e, srcToDrag, `Frame_${index + 1}_${Date.now()}.png`);
                                                    e.stopPropagation();
                                                }
                                            }}
                                        />
                                    ) : (
                                        <div className="w-full h-full flex items-center justify-center text-gray-600 text-xs">
                                            Frame {index + 1}
                                        </div>
                                    )}
                                    {/* Gradient Overlay */}
                                    <div className="absolute inset-x-0 top-0 h-12 bg-gradient-to-b from-black/80 to-transparent z-20 pointer-events-none" />

                                    {isPending && <div className="absolute inset-0 flex items-center justify-center bg-black/60"><span className="text-xs text-gray-400 font-medium">{t('imageEditor.status.queued')}</span></div>}
                                    {isGenerating && (
                                        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 z-10">
                                            <svg className="animate-spin h-6 w-6 text-cyan-500 mb-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                                            <span className="text-xs text-white font-medium mb-2">{t('imageEditor.status.generating')}</span>
                                            <button onClick={(e) => { e.stopPropagation(); onStopFrame(e, index); }} className="px-2 py-0.5 bg-red-600/90 hover:bg-red-700 text-white text-[10px] font-bold rounded shadow-sm border border-red-500/50">Stop Queue</button>
                                        </div>
                                    )}
                                    {isError && <div className="absolute inset-0 flex items-center justify-center bg-red-900/50"><span className="text-xs text-red-200 font-medium">Error</span></div>}
                                    
                                    <div className="absolute top-1 right-1 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity z-30">
                                        <ActionButton title={t('node.action.copy')} onClick={(e) => onCopyFrame(e, index, getSourceToView())} className="p-1 text-gray-200 hover:text-white rounded hover:bg-gray-600 transition-colors">
                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                                <rect x="8" y="8" width="12" height="12" rx="2" ry="2" />
                                                <path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" />
                                            </svg>
                                        </ActionButton>
                                        {isGenerated && <ActionButton title={t('node.action.download')} onClick={(e) => onDownloadFrame(e, index)} className="p-1 text-gray-200 hover:text-white rounded hover:bg-gray-600 transition-colors"><svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg></ActionButton>}
                                        <ActionButton title={t('imageEditor.action.regenerate')} onClick={(e) => onRegenerateFrame(e, index)} disabled={isEditing} className="p-1 text-gray-200 hover:text-white rounded hover:bg-gray-600 transition-colors"><svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 110 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" /></svg></ActionButton>

                                        {showEditActions && (
                                            <ActionButton 
                                                title={isTextConnected ? t('image_sequence.edit_in_source') : t('image_sequence.edit_prompt')} 
                                                onClick={(e) => { 
                                                    e.stopPropagation(); 
                                                    if (isTextConnected) onEditInSource(index);
                                                    else onEditPrompt(index);
                                                }} 
                                                className="p-1 text-gray-200 hover:text-white rounded hover:bg-gray-600 transition-colors"
                                            >
                                                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                                    <path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                                </svg>
                                            </ActionButton>
                                        )}
                                    </div>
                                    
                                    <div className="absolute top-1 left-1 z-20" onClick={(e) => { e.stopPropagation(); onCheckOutput(index); }}>
                                        <input type="checkbox" checked={isChecked} readOnly className="h-4 w-4 rounded bg-gray-900/50 border-gray-500 text-accent focus:ring-accent cursor-pointer" />
                                    </div>
                                    <div className="absolute bottom-1 left-1 right-1 flex justify-between items-end pointer-events-none z-20">
                                        <div>{/* placeholder for aspect ratio badge */}</div>
                                        <div className="bg-black/60 text-white text-[10px] px-1.5 py-0.5 rounded backdrop-blur-sm">{index + 1}</div>
                                    </div>
                                </div>
                            );
                        })}
                        </div>
                    </div>
                </div>
            )}

            {/* Bottom Controls Area: Integrated Model Switcher & Single Mode Buttons */}
            <div 
                className="flex-shrink-0 flex flex-nowrap items-center justify-between gap-1.5 mt-2 pt-2 border-t border-gray-700/50 min-w-0 w-full"
            >
                {/* Left Controls Group: Model Switcher & Parameter Selectors & Toggles */}
                <div className="flex-shrink-0 flex items-center gap-1.5 min-w-0">
                    {/* Model Switch Dropdown */}
                    <div className="flex-shrink-0 flex items-center gap-1">
                        <button
                            title="Previous Model"
                            type="button"
                            className="h-[38px] w-[38px] flex-shrink-0 flex items-center justify-center bg-gray-700 hover:bg-gray-600 disabled:opacity-40 disabled:hover:bg-gray-700 border border-gray-600 rounded-md text-gray-200 hover:text-white transition-colors"
                            onClick={(e) => {
                                e.stopPropagation();
                                const currentIndex = modelOptions.findIndex(m => m.value === effectiveModel);
                                if (currentIndex > 0) {
                                    onUpdateState({ model: modelOptions[currentIndex - 1].value });
                                }
                            }}
                            disabled={isEditing || modelOptions.findIndex(m => m.value === effectiveModel) <= 0}
                        >
                            <ChevronLeft className="w-4 h-4 text-gray-200 hover:text-white" />
                        </button>

                        <ModelSelectorDropdown
                            model={model}
                            effectiveModel={effectiveModel}
                            modelOptions={modelOptions as ImageModelOption[]}
                            onUpdateState={onUpdateState}
                            disabled={isEditing}
                            t={t}
                        />

                        <button
                            title="Next Model"
                            type="button"
                            className="h-[38px] w-[38px] flex-shrink-0 flex items-center justify-center bg-gray-700 hover:bg-gray-600 disabled:opacity-40 disabled:hover:bg-gray-700 border border-gray-600 rounded-md text-gray-200 hover:text-white transition-colors"
                            onClick={(e) => {
                                e.stopPropagation();
                                const currentIndex = modelOptions.findIndex(m => m.value === effectiveModel);
                                if (currentIndex !== -1 && currentIndex < modelOptions.length - 1) {
                                    onUpdateState({ model: modelOptions[currentIndex + 1].value });
                                }
                            }}
                            disabled={isEditing || modelOptions.findIndex(m => m.value === effectiveModel) >= modelOptions.length - 1 || modelOptions.findIndex(m => m.value === effectiveModel) === -1}
                        >
                            <ChevronRight className="w-4 h-4 text-gray-200 hover:text-white" />
                        </button>
                    </div>

                    {/* Quality Selector for GPT-Image-2 and DALL-E 3 */}
                    {showQuality && (
                        <div className="flex-shrink-0 min-w-[80px]">
                             <CustomSelect
                                value={quality || (isGpt2 ? 'high' : 'standard')}
                                onChange={(value) => onUpdateState({ quality: value })}
                                disabled={isEditing}
                                options={isGpt2 ? gpt2QualityOptions : dalle3QualityOptions}
                                id="quality-selector"
                                title="Quality"
                            />
                        </div>
                    )}

                    {/* Resolution / Size for GPT-Image-2 and DALL-E 2 */}
                    {showGptSize && (
                        <div className="flex-shrink-0 min-w-[90px]">
                             <CustomSelect
                                value={size || '1024x1024'}
                                onChange={(value) => onUpdateState({ size: value })}
                                disabled={isEditing}
                                options={isGpt2 ? gpt2SizeOptions : dalle2SizeOptions}
                                id="gpt-size-selector"
                                title="Resolution / Size"
                            />
                        </div>
                    )}

                    {/* Format for GPT-Image-2 */}
                    {showOutputFormat && (
                        <div className="flex-shrink-0 w-20">
                             <CustomSelect
                                value={outputFormat || 'png'}
                                onChange={(value) => onUpdateState({ outputFormat: value })}
                                disabled={isEditing}
                                options={gpt2FormatOptions}
                                id="gpt-format-selector"
                                title="Output Format"
                            />
                        </div>
                    )}

                    {/* Aspect Ratio Selector */}
                    {showAspectRatio && (
                        <AspectRatioDropdown
                            aspectRatio={aspectRatio}
                            availableAspectRatios={availableAspectRatios}
                            onUpdateState={onUpdateState}
                            disabled={isEditing}
                            t={t}
                        />
                    )}

                    {/* Resolution Selector (Only for models supporting imageSize: Nano Banana Pro & Nana Banana 2.1) */}
                    {showResolution && (
                        <ResolutionDropdown
                            resolution={resolution}
                            availableResolutions={availableResolutions}
                            onUpdateState={onUpdateState}
                            disabled={isEditing}
                            t={t}
                        />
                    )}

                </div>

                {/* Right Actions & Menus Group (Aligned to the right border) */}
                <div className="flex-shrink-0 flex items-center gap-1.5 ml-auto">
                    {/* Thinking Mode Switch Toggle with Dropdown */}
                    {showThinking && (
                        <ThinkingToggleDropdown
                            thinkingLevel={thinkingLevel}
                            availableThinkingLevels={availableThinkingLevels}
                            onUpdateState={onUpdateState}
                            disabled={isEditing}
                            t={t}
                        />
                    )}

                    {/* Search Grounding Switch Toggle with Dropdown */}
                    {showSearchGrounding && (
                        <SearchToggleDropdown
                            searchGrounding={searchGrounding}
                            isNanoBanana21={isNanoBanana21}
                            onUpdateState={onUpdateState}
                            disabled={isEditing}
                            t={t}
                        />
                    )}

                    {/* Auto Crop Toggle */}
                    <EditorTooltip
                        title="Crop 16:9"
                        status={{
                            enabled: !!autoCrop169,
                            labelOn: t('common.enabled') || 'Включено',
                            labelOff: t('common.disabled') || 'Выключено'
                        }}
                        description={t('image_sequence.tooltip.autoCrop')}
                    >
                        <button
                            type="button"
                            onClick={() => onUpdateState({ autoCrop169: !autoCrop169 })}
                            className={`h-[36px] px-2.5 flex-shrink-0 flex items-center justify-center rounded-md cursor-pointer transition-all border outline-none ${
                                autoCrop169 
                                    ? 'bg-indigo-950/60 border-indigo-500/60 shadow-[0_0_10px_rgba(99,102,241,0.25)]' 
                                    : 'bg-gray-800 border-gray-700 hover:border-gray-600 hover:bg-gray-750'
                            }`}
                            aria-label={`Crop 16:9: ${autoCrop169 ? 'ON' : 'OFF'}`}
                        >
                            <div className={`w-8 h-4 rounded-full relative transition-colors ${autoCrop169 ? 'bg-indigo-500' : 'bg-gray-600'}`}>
                                <div className={`absolute top-0.5 bottom-0.5 w-3 h-3 bg-white rounded-full shadow-sm transition-transform duration-200 ${autoCrop169 ? 'translate-x-[16px]' : 'translate-x-[2px]'}`}></div>
                            </div>
                        </button>
                    </EditorTooltip>

                    {/* Auto Download Toggle */}
                    <EditorTooltip
                        title={t('image_sequence.auto_save') || "Autosave images"}
                        status={{
                            enabled: !!autoSaveImages,
                            labelOn: t('common.enabled') || 'Включено',
                            labelOff: t('common.disabled') || 'Выключено'
                        }}
                        description={t('image_sequence.tooltip.autoSave') || "Автоматически сохранять сгенерированные изображения на устройство при завершении генерации."}
                    >
                        <button
                            type="button"
                            onClick={() => onUpdateState({ autoSaveImages: !autoSaveImages })}
                            className={`h-[36px] px-2.5 flex-shrink-0 flex items-center justify-center rounded-md cursor-pointer transition-all border outline-none ${
                                autoSaveImages 
                                    ? 'bg-indigo-950/60 border-indigo-500/60 shadow-[0_0_10px_rgba(99,102,241,0.25)]' 
                                    : 'bg-gray-800 border-gray-700 hover:border-gray-600 hover:bg-gray-750'
                            }`}
                            aria-label={`Autosave images: ${autoSaveImages ? 'ON' : 'OFF'}`}
                        >
                            <div className={`w-8 h-4 rounded-full relative transition-colors ${autoSaveImages ? 'bg-indigo-500' : 'bg-gray-600'}`}>
                                <div className={`absolute top-0.5 bottom-0.5 w-3 h-3 bg-white rounded-full shadow-sm transition-transform duration-200 ${autoSaveImages ? 'translate-x-[16px]' : 'translate-x-[2px]'}`}></div>
                            </div>
                        </button>
                    </EditorTooltip>

                    {/* Main Action Button - Dynamic State Machine */}
                    {isEditing ? (
                        <button 
                            type="button"
                            onClick={onStop} 
                            className="flex-shrink-0 min-w-max px-3.5 h-[36px] items-center justify-center whitespace-nowrap font-bold text-white bg-red-600 hover:bg-red-700 active:bg-red-800 rounded-md transition-colors flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
                            title={isStopping ? (t('node.action.stopping') || 'Остановка...') : (t('node.action.stop') || 'Стоп')}
                        >
                            <Square className="w-3.5 h-3.5 fill-current" />
                            <span>{isStopping ? (t('node.action.stopping') || 'Остановка...') : (t('node.action.stop') || 'Стоп')}</span>
                        </button>
                    ) : isForming ? (
                        <button
                            type="button"
                            onClick={() => setShowConfirmCancelBatch(true)}
                            className="flex-shrink-0 min-w-max px-3.5 h-[36px] items-center justify-center whitespace-nowrap font-bold text-white bg-rose-600 hover:bg-rose-700 active:bg-rose-800 rounded-md transition-all flex items-center justify-center gap-1.5 shadow-md shadow-rose-900/30 cursor-pointer animate-pulse"
                            title={t('batch.stopForming') || 'Стоп формирования'}
                        >
                            <Square className="w-3.5 h-3.5 fill-current" />
                            <span>{t('batch.stopForming') || 'Стоп формирования'}</span>
                        </button>
                    ) : activeBatchJob ? (
                        <button
                            type="button"
                            onClick={() => setShowConfirmCancelBatch(true)}
                            className="flex-shrink-0 min-w-max px-3.5 h-[36px] items-center justify-center whitespace-nowrap font-bold text-white bg-rose-600 hover:bg-rose-700 active:bg-rose-800 rounded-md transition-all flex items-center justify-center gap-1.5 shadow-md shadow-rose-900/30 cursor-pointer"
                            title={t('batch.stopGeneration') || 'Стоп (отмена)'}
                        >
                            <X className="w-4 h-4" />
                            <span>{t('batch.stopGeneration') || 'Стоп (отмена)'}</span>
                        </button>
                    ) : (
                        <button 
                            type="button"
                            onClick={() => triggerRunWithConfirmation(isSequenceMode ? onRunSelected : onEdit)}
                            disabled={isMainActionDisabled} 
                            className={`flex-shrink-0 min-w-[100px] px-3.5 h-[36px] items-center justify-center whitespace-nowrap font-bold text-white rounded-md disabled:bg-gray-500 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-1.5 ${
                                isBatchMode 
                                    ? 'bg-accent-secondary hover:bg-accent-secondary-hover active:bg-accent-secondary shadow-md' 
                                    : 'bg-cyan-600 hover:bg-cyan-700'
                            }`}
                        >
                            {isSequenceMode 
                                ? (isBatchMode ? (t('image_sequence.run_selected_batch') || `${t('image_sequence.run_selected')} (Batch)`) : t('image_sequence.run_selected')) 
                                : (!hasInputImages 
                                    ? (isBatchMode ? (t('node.content.generateImage_batch') || `${t('node.content.generateImage')} (Batch)`) : t('node.content.generateImage')) 
                                    : (isBatchMode ? (t('node.content.applyEdit_batch') || `${t('node.content.applyEdit')} (Batch)`) : t('node.content.applyEdit'))
                                  )
                            }
                        </button>
                    )}
                    
                    {/* Single Mode: Edit in Canvas Button */}
                    {!isSequenceMode && (
                         <EditorTooltip 
                            title="Edit in Canvas"
                            description={t('node.action.editInCanvas.desc') || "Открыть полноэкранный холст для рисования и редактирования"}
                         >
                             <button onClick={onOpenEditor} disabled={!outputImage && !imageForEditor} className="h-[36px] px-3 font-bold text-white bg-teal-600 rounded-md hover:bg-teal-700 disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" /></svg>
                            </button>
                        </EditorTooltip>
                    )}
                    
                    {/* Sequence Mode: Download Selected ZIP Button */}
                    {isSequenceMode && (
                        <EditorTooltip 
                            title={`${t('image_sequence.download_selected_zip')} (${checkedSequenceOutputIndices.length})`}
                            description="Скачать выбранные кадры единым ZIP-архивом"
                        >
                            <button 
                                onClick={onDownloadSelectedZip} 
                                disabled={checkedSequenceOutputIndices.length === 0} 
                                className="flex-shrink-0 h-[36px] w-[36px] flex items-center justify-center font-bold text-white bg-sky-600 rounded-md hover:bg-sky-700 disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                                </svg>
                            </button>
                        </EditorTooltip>
                    )}

                    {/* Single Mode: Output to Input */}
                    {!isSequenceMode && outputImage && (
                        <EditorTooltip
                            title={t('node.action.outputToInput')}
                            description="Перенести сгенерированное изображение во входной слот для повторной обработки"
                        >
                            <ActionButton title="" onClick={onSetOutputToInput} className="flex-shrink-0 h-[36px]">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm.707-10.293a1 1 0 00-1.414-1.414l-3 3a1 1 0 000 1.414l3 3a1 1 0 001.414-1.414L9.414 11H13a1 1 0 100-2H9.414l1.293-1.293z" clipRule="evenodd" /></svg>
                            </ActionButton>
                        </EditorTooltip>
                    )}
                </div>
            </div>
            
             {/* Confirmation Dialog for Clearing Generated Images and State */}
             <ConfirmDialog
                 isOpen={showConfirmClear}
                 onClose={() => setShowConfirmClear(false)}
                 onConfirm={handleConfirmClear}
                 title={t('dialog.confirmClearOutputs.title') || "Clear Generated Images"}
                 message={t('dialog.confirmClearOutputs.message') || "Are you sure you want to clear all generated images and reset the generation status? This action cannot be undone."}
                 confirmLabel={t('dialog.deleteNode.confirm') || "Yes"}
                 cancelLabel={t('dialog.deleteNode.cancel') || "No"}
                 confirmVariant="danger"
             />

             {/* Confirmation Dialog for Cancelling Batch Formation & Server Request */}
             <ConfirmDialog
                 isOpen={showConfirmCancelBatch}
                 onClose={() => setShowConfirmCancelBatch(false)}
                 onConfirm={handleConfirmCancelBatch}
                 title={t('dialog.confirmCancelBatch.title') || "Отмена формирования batch-запроса"}
                 message={t('dialog.confirmCancelBatch.message') || "Вы действительно хотите отменить формирование batch-запроса и остановить отправку на сервер?"}
                 confirmLabel={t('dialog.confirmCancelBatch.confirm') || "Да, отменить"}
                 cancelLabel={t('dialog.confirmCancelBatch.cancel') || "Продолжить"}
                 confirmVariant="danger"
             />

             {/* Confirmation Dialog for Run Batch / Run Selected (Sequence Mode) */}
             <ConfirmDialog
                 isOpen={showConfirmRun}
                 onClose={() => {
                     setShowConfirmRun(false);
                     pendingRunRef.current = null;
                 }}
                 onConfirm={handleConfirmRun}
                 title={confirmRunDetails.title}
                 message={confirmRunDetails.message}
                 confirmLabel={t('dialog.confirmRun.confirm') || "Да, запустить"}
                 cancelLabel={t('dialog.confirmRun.cancel') || "Отмена"}
                 confirmVariant={isBatchMode ? "accent" : "primary"}
             />
        </div>
    );
};
