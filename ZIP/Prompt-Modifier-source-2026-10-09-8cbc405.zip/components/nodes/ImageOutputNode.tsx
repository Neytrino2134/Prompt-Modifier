
import React, { useState, useMemo } from 'react';
import type { NodeContentProps } from '../../types';
import CustomSelect from '../CustomSelect';
import { useAppContext } from '../../contexts/AppContext';
import { TutorialTooltip } from '../TutorialTooltip';
import { CustomCheckbox } from '../CustomCheckbox';
import { ActionButton } from '../ActionButton';
import { CopyIcon } from '../../components/icons/AppIcons';
import { expandImageAspectRatio } from '../../services/imageActions';
import { generateThumbnail, setupImageDragData } from '../../utils/imageUtils';
import { useOpenAiEnabled, getImageModelOptions, isGptImage2Model, isOpenAiImageModel, resolveImageModel, isNanoBanana21Model, getImageModelCapabilities } from '../../services/modelConfig';

export const ImageOutputNode: React.FC<NodeContentProps> = ({ 
    node, 
    isGeneratingImage, 
    isExecutingChain, 
    onModelChange, 
    onQualityChange,
    onOutputFormatChange,
    onSizeChange,
    onAspectRatioChange, 
    onResolutionChange, 
    onAutoDownloadChange, 
    onGenerateImage, 
    onStopChainExecution, 
    onExecuteChain, 
    t, 
    onDownloadImage, 
    setImageViewer, 
    getFullSizeImage, 
    setFullSizeImage, 
    onValueChange, 
    getUpstreamNodeValues, 
    isGlobalProcessing, 
    onCopyImageToClipboard, 
    addToast 
}) => {
    const context = useAppContext();
    const { 
        tutorialStep, 
        tutorialTargetId, 
        advanceTutorial, 
        skipTutorial, 
        isBatchMode, 
        setIsBatchMode,
        isFormingBatch,
        getNodeActiveBatchJob,
        isNodeBatchActive
    } = context || {};

    const isForming = isFormingBatch ? isFormingBatch(node.id) : false;
    const activeBatchJob = getNodeActiveBatchJob ? getNodeActiveBatchJob(node.id) : undefined;
    const isBatchBusy = isNodeBatchActive ? isNodeBatchActive(node.id) : false;
    
    const [transformingRatio, setTransformingRatio] = useState<string | null>(null);

    const isTutorialActive = tutorialTargetId === node.id && tutorialStep === 'image_output_generate';

    const handleQualitySelect = (val: string) => {
        if (onQualityChange) {
            onQualityChange(node.id, val);
        } else if (context?.handleQualityChange) {
            context.handleQualityChange(node.id, val);
        }
    };

    const handleOutputFormatSelect = (val: string) => {
        if (onOutputFormatChange) {
            onOutputFormatChange(node.id, val);
        } else if (context?.handleOutputFormatChange) {
            context.handleOutputFormatChange(node.id, val);
        }
    };

    const handleSizeSelect = (val: string) => {
        if (onSizeChange) {
            onSizeChange(node.id, val);
        } else if (context?.handleSizeChange) {
            context.handleSizeChange(node.id, val);
        }
    };

    const handleThinkingLevelSelect = (val: string) => {
        if (context?.setNodes) {
            context.setNodes((nds: any[]) => nds.map(n => n.id === node.id ? { ...n, thinkingLevel: val } : n));
        }
    };

    const handleSearchGroundingSelect = (val: string) => {
        if (context?.setNodes) {
            context.setNodes((nds: any[]) => nds.map(n => n.id === node.id ? { ...n, searchGrounding: val } : n));
        }
    };

    // Calculate prompt for drag/drop context
    const texts = getUpstreamNodeValues(node.id).filter(v => typeof v === 'string') as string[];
    const hasUpstreamText = texts.length > 0;
    const currentPrompt = hasUpstreamText ? texts.join(', ') : (node.customPrompt || '');

    const handleCustomPromptChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        if (context?.handleCustomPromptChange) {
            context.handleCustomPromptChange(node.id, e.target.value);
        }
    };

    const handleGenerateClick = () => {
        onGenerateImage(node.id);
        // Advance to 'generating' step, not completion yet
        if (isTutorialActive && advanceTutorial) {
            advanceTutorial();
        }
    };

    const handleCopyLarge = (e: React.MouseEvent) => {
        e.stopPropagation();
        const fullSizeSrc = getFullSizeImage(node.id, 0) || node.value;
        if (fullSizeSrc && onCopyImageToClipboard) {
            onCopyImageToClipboard(fullSizeSrc);
        }
    };

    const handleRatioExpand = async (targetRatio: string) => {
        const fullSizeSrc = getFullSizeImage(node.id, 0) || node.value;
        if (!fullSizeSrc) return;

        setTransformingRatio(targetRatio);
        try {
            // Use the node's selected model or default to flash for speed/cost if not specified
            // Note: expansion usually works best with the flash model for editing tasks
            const expansionModel = 'gemini-2.5-flash-image'; 

            const newImage = await expandImageAspectRatio(fullSizeSrc, targetRatio, currentPrompt, expansionModel);
            
            // 1. Update High Res Cache
            setFullSizeImage(node.id, 0, newImage);
            
            // 2. Update Thumbnail/Value
            const thumb = await generateThumbnail(newImage, 256, 256);
            onValueChange(node.id, thumb);

            if (addToast) addToast(`Expanded to ${targetRatio}`, 'success');
        } catch (error: any) {
            console.error("Ratio expansion failed:", error);
            if (addToast) addToast(`Failed to expand: ${error.message}`, 'error');
        } finally {
            setTransformingRatio(null);
        }
    };

    const isOpenAiActive = useOpenAiEnabled();
    const modelOptions = useMemo(() => getImageModelOptions(), [isOpenAiActive]);
    
    const effectiveModel = resolveImageModel(node.model);
    const isGpt2 = isGptImage2Model(effectiveModel);
    const isDalle3 = effectiveModel === 'dall-e-3';
    const isDalle2 = effectiveModel === 'dall-e-2';
    const isNanoBanana21 = isNanoBanana21Model(effectiveModel);

    const capabilities = useMemo(() => getImageModelCapabilities(effectiveModel), [effectiveModel]);
    const availableAspectRatios = capabilities.supportedAspectRatios;
    const isAspectRatioEnabled = availableAspectRatios.length > 0;
    const availableResolutions = capabilities.supportedResolutions.map(r => ({ value: r, label: r }));
    const showResolution = availableResolutions.length > 0;
    const showThinkingMode = capabilities.supportedThinkingLevels.length > 0;
    const showSearchGrounding = capabilities.supportedSearchTypes.length > 0;

    const allThinkingLevelOptions = [
        { value: 'AUTO', label: 'Auto (Default)' },
        { value: 'MINIMAL', label: 'Minimal (Fastest)' },
        { value: 'LOW', label: 'Low' },
        { value: 'MEDIUM', label: 'Medium (Balanced)' },
        { value: 'HIGH', label: 'High (Deep Reasoning)' },
    ];
    const thinkingLevelOptions = allThinkingLevelOptions.filter(o => capabilities.supportedThinkingLevels.includes(o.value));

    const searchGroundingOptions = isNanoBanana21
        ? [
            { value: 'none', label: 'Off' },
            { value: 'web', label: 'Google Web Search' },
            { value: 'image', label: 'Google Image Search' },
            { value: 'both', label: 'Web + Image Search' },
        ]
        : [
            { value: 'none', label: 'Off' },
            { value: 'web', label: 'Google Web Search' },
        ];

    const gpt2QualityOptions = [
        { value: 'standard', label: 'Standard' },
        { value: 'hd', label: 'HD' },
        { value: 'high', label: 'High' },
        { value: 'medium', label: 'Medium' },
        { value: 'low', label: 'Low' },
    ];

    const dalle3QualityOptions = [
        { value: 'standard', label: 'Standard' },
        { value: 'hd', label: 'HD (High Definition)' },
    ];

    const gpt2SizeOptions = [
        { value: '1024x1024', label: '1024 × 1024 (1:1 Square)' },
        { value: '1536x1024', label: '1536 × 1024 (3:2 Landscape)' },
        { value: '1024x1536', label: '1024 × 1536 (2:3 Portrait)' },
        { value: 'auto', label: 'Auto' },
    ];

    const gpt2FormatOptions = [
        { value: 'png', label: 'PNG' },
        { value: 'jpeg', label: 'JPEG' },
        { value: 'webp', label: 'WebP' },
    ];

    const dalle2SizeOptions = [
        { value: '1024x1024', label: '1024 × 1024' },
        { value: '512x512', label: '512 × 512' },
        { value: '256x256', label: '256 × 256' },
    ];

    const handleClick = () => {
        if (!node.value) return;
        const fullSizeSrc = getFullSizeImage(node.id, 0) || node.value; // Frame 0 for single image nodes
        if (fullSizeSrc) {
            setImageViewer({
                sources: [{ 
                    src: fullSizeSrc, 
                    frameNumber: 0, 
                    prompt: currentPrompt,
                    model: node.model || 'imagen-4.0-generate-001',
                    aspectRatio: node.aspectRatio,
                    resolution: node.resolution
                }],
                initialIndex: 0,
            });
        }
    };

    const LargeCopyIcon = (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white/80" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <rect x="8" y="8" width="12" height="12" rx="2" ry="2" />
            <path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" />
        </svg>
    );
    
    const LoadingSpinner = () => (
        <svg className="animate-spin h-3 w-3 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
    );

    return (
        <div className="flex flex-col h-full">
            <div onClick={handleClick} onWheel={(e) => e.stopPropagation()} className="relative w-full flex-grow bg-gray-700 rounded-md flex items-center justify-center overflow-hidden mb-2 group cursor-pointer border border-gray-600 hover:border-gray-500 transition-colors">
                {node.value ? (
                    <img
                        src={getFullSizeImage(node.id, 0) || node.value}
                        alt="Generated result"
                        className="object-contain w-full h-full"
                        draggable={true}
                        onMouseDown={(e) => e.stopPropagation()}
                        onDragStart={(e) => {
                            // Prioritize High Resolution Image
                            const imageToDrag = getFullSizeImage(node.id, 0) || node.value;
                            if (imageToDrag) {
                                const filename = `Output_Image_${Date.now()}.png`;
                                setupImageDragData(e, imageToDrag, filename, currentPrompt);
                                e.stopPropagation();
                            }
                        }}
                    />
                ) : (
                    <span className="text-gray-400">{t('node.content.imageHere')}</span>
                )}
                <div className={`absolute inset-0 bg-gray-800/70 backdrop-blur-sm flex flex-col items-center justify-center text-white z-10 transition-opacity duration-300 ${(isGeneratingImage || (isExecutingChain && !node.value) || isBatchBusy) ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
                    <svg className="animate-spin h-8 w-8 text-accent-text" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span className="mt-2 font-semibold text-accent-text text-center px-4">
                        {isForming
                            ? (t('batch.formingRequest') || 'Forming batch request...')
                            : activeBatchJob
                                ? (t('batch.waitingForResponse') || 'Waiting for response from service')
                                : (isExecutingChain ? 'Executing...' : t('node.content.generating'))}
                    </span>
                    {activeBatchJob && (
                        <span className="text-[11px] text-accent-secondary mt-1 font-mono">
                            {activeBatchJob.displayName || activeBatchJob.name} ({activeBatchJob.state})
                        </span>
                    )}
                </div>
                {node.value && !(isGeneratingImage || (isExecutingChain && !node.value) || isBatchBusy) && (
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none gap-4">
                        <button
                            onClick={handleCopyLarge}
                            className="w-20 h-20 flex items-center justify-center rounded-full bg-black/50 hover:bg-black/60 transition-colors pointer-events-auto"
                            aria-label={t('node.action.copy')}
                            title={t('node.action.copy')}
                        >
                            {LargeCopyIcon}
                        </button>
                        <button
                            onClick={(e) => { e.stopPropagation(); onDownloadImage(node.id); }}
                            className="w-20 h-20 flex items-center justify-center rounded-full bg-black/50 hover:bg-black/60 transition-colors pointer-events-auto"
                            aria-label={t('node.action.download')}
                            title={t('node.action.download')}
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white/80" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                            </svg>
                        </button>
                    </div>
                )}
                {node.value && (
                    <div className="absolute top-1 right-1 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <ActionButton title={t('node.action.copy')} onClick={handleCopyLarge}>
                            <CopyIcon />
                        </ActionButton>
                        <ActionButton title={t('node.action.download')} onClick={(e) => { e.stopPropagation(); onDownloadImage(node.id); }}><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg></ActionButton>
                    </div>
                )}
                
                {/* Expansion Controls - Bottom Right Overlay */}
                {node.value && !(isGeneratingImage || (isExecutingChain && !node.value)) && (
                    <div className="absolute bottom-2 right-2 flex gap-1 z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                         <button
                            onClick={(e) => { e.stopPropagation(); handleRatioExpand('16:9'); }}
                            disabled={isGeneratingImage || isExecutingChain || !!transformingRatio}
                            className="px-2 py-1 text-[10px] font-bold text-gray-200 bg-gray-800/80 hover:bg-gray-700 hover:text-white border border-gray-600/50 rounded backdrop-blur-sm shadow-sm flex items-center gap-1 transition-colors pointer-events-auto"
                            title="Expand to 16:9"
                        >
                            {transformingRatio === '16:9' ? (
                                <LoadingSpinner />
                            ) : (
                                <>
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="currentColor" viewBox="0 0 24 24"><rect x="2" y="8" width="20" height="8" rx="1" /></svg>
                                    16:9
                                </>
                            )}
                        </button>
                        <button
                            onClick={(e) => { e.stopPropagation(); handleRatioExpand('9:16'); }}
                            disabled={isGeneratingImage || isExecutingChain || !!transformingRatio}
                            className="px-2 py-1 text-[10px] font-bold text-gray-200 bg-gray-800/80 hover:bg-gray-700 hover:text-white border border-gray-600/50 rounded backdrop-blur-sm shadow-sm flex items-center gap-1 transition-colors pointer-events-auto"
                            title="Expand to 9:16"
                        >
                            {transformingRatio === '9:16' ? (
                                <LoadingSpinner />
                            ) : (
                                 <>
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="currentColor" viewBox="0 0 24 24"><rect x="8" y="2" width="8" height="20" rx="1" /></svg>
                                    9:16
                                </>
                            )}
                        </button>
                    </div>
                )}
            </div>
            <div className="mb-2">
                <textarea
                    value={node.customPrompt || ''}
                    onChange={handleCustomPromptChange}
                    disabled={hasUpstreamText || isGeneratingImage || isExecutingChain}
                    placeholder={hasUpstreamText ? t('node.content.promptOverridden') : t('node.content.enterPrompt')}
                    className={`w-full text-sm bg-gray-800 border ${hasUpstreamText ? 'border-gray-600 text-gray-500' : 'border-gray-600 text-gray-200'} rounded-md p-2 resize-none focus:outline-none focus:ring-1 focus:ring-accent`}
                    rows={2}
                />
            </div>
            <div className="mb-2">
                <label className="block text-xs font-medium text-gray-400 mb-1">{t('node.content.generationMode')}</label>
                <CustomSelect
                    id={`model-select-${node.id}`}
                    value={effectiveModel}
                    onChange={(value) => onModelChange(node.id, value)}
                    disabled={isGeneratingImage || isExecutingChain}
                    options={modelOptions}
                />
            </div>

            {/* Quality selection for GPT-Image-2 and DALL-E 3 */}
            {isGpt2 && (
                <>
                    <div className="mb-2">
                        <label className="block text-xs font-medium text-gray-400 mb-1">Quality</label>
                        <CustomSelect
                            id={`quality-select-${node.id}`}
                            value={node.quality || 'high'}
                            onChange={handleQualitySelect}
                            disabled={isGeneratingImage || isExecutingChain}
                            options={gpt2QualityOptions}
                        />
                    </div>
                    <div className="mb-2">
                        <label className="block text-xs font-medium text-gray-400 mb-1">Resolution / Size</label>
                        <CustomSelect
                            id={`size-select-${node.id}`}
                            value={node.size || '1024x1024'}
                            onChange={handleSizeSelect}
                            disabled={isGeneratingImage || isExecutingChain}
                            options={gpt2SizeOptions}
                        />
                    </div>
                    <div className="mb-2">
                        <label className="block text-xs font-medium text-gray-400 mb-1">Output Format</label>
                        <CustomSelect
                            id={`format-select-${node.id}`}
                            value={node.outputFormat || 'png'}
                            onChange={handleOutputFormatSelect}
                            disabled={isGeneratingImage || isExecutingChain}
                            options={gpt2FormatOptions}
                        />
                    </div>
                </>
            )}

            {isDalle3 && (
                <div className="mb-2">
                    <label className="block text-xs font-medium text-gray-400 mb-1">Quality</label>
                    <CustomSelect
                        id={`quality-select-${node.id}`}
                        value={node.quality || 'standard'}
                        onChange={handleQualitySelect}
                        disabled={isGeneratingImage || isExecutingChain}
                        options={dalle3QualityOptions}
                    />
                </div>
            )}

            {isDalle2 && (
                <div className="mb-2">
                    <label className="block text-xs font-medium text-gray-400 mb-1">Resolution / Size</label>
                    <CustomSelect
                        id={`size-select-${node.id}`}
                        value={node.size || '1024x1024'}
                        onChange={handleSizeSelect}
                        disabled={isGeneratingImage || isExecutingChain}
                        options={dalle2SizeOptions}
                    />
                </div>
            )}

            {showResolution && (
                <div className="mb-2">
                    <label className="block text-xs font-medium text-gray-400 mb-1">Resolution</label>
                    <CustomSelect
                        value={node.resolution && availableResolutions.some(r => r.value === node.resolution) ? node.resolution : '1K'}
                        onChange={(value) => onResolutionChange(node.id, value as any)}
                        disabled={isGeneratingImage || isExecutingChain}
                        options={availableResolutions}
                    />
                </div>
            )}

            {showThinkingMode && (
                <div className="mb-2">
                    <label className="block text-xs font-medium text-gray-400 mb-1">Thinking Mode</label>
                    <CustomSelect
                        id={`thinking-select-${node.id}`}
                        value={node.thinkingLevel || 'AUTO'}
                        onChange={handleThinkingLevelSelect}
                        disabled={isGeneratingImage || isExecutingChain}
                        options={thinkingLevelOptions}
                    />
                </div>
            )}

            {showSearchGrounding && (
                <div className="mb-2">
                    <label className="block text-xs font-medium text-gray-400 mb-1">Search Grounding</label>
                    <CustomSelect
                        id={`grounding-select-${node.id}`}
                        value={node.searchGrounding || 'none'}
                        onChange={handleSearchGroundingSelect}
                        disabled={isGeneratingImage || isExecutingChain}
                        options={searchGroundingOptions}
                    />
                </div>
            )}

            {isAspectRatioEnabled && (
                <div className="mb-2">
                    <label htmlFor={`aspect-ratio-${node.id}`} className={`block text-xs font-medium mb-1 transition-colors ${!isAspectRatioEnabled ? 'text-gray-600' : 'text-gray-400'}`}>
                        {t('node.content.aspectRatio')}
                    </label>
                    <CustomSelect
                        id={`aspect-ratio-${node.id}`}
                        value={node.aspectRatio || '1:1'}
                        onChange={(value) => onAspectRatioChange(node.id, value)}
                        disabled={isGeneratingImage || !isAspectRatioEnabled || isExecutingChain}
                        title={!isAspectRatioEnabled ? t('node.content.aspectRatioNotSupportedFast') : t('node.content.aspectRatioHelp')}
                        options={availableAspectRatios.map(ratio => ({ value: ratio, label: ratio }))}
                    />
                </div>
            )}
            <div className="mb-2">
                <CustomCheckbox
                    id={`auto-download-toggle-${node.id}`}
                    checked={!!node.autoDownload}
                    onChange={(checked) => onAutoDownloadChange(node.id, checked)}
                    disabled={isGeneratingImage || isExecutingChain}
                    label={t('node.content.autoDownload')}
                />
            </div>

            {/* Batch API Synchronized Mode Toggle & Status Indicator */}
            <div 
                onClick={() => {
                    if (!isGeneratingImage && !isExecutingChain && setIsBatchMode) {
                        setIsBatchMode(!isBatchMode);
                    }
                }}
                className={`mb-2 p-2 rounded-md border cursor-pointer select-none transition-all ${
                    isBatchMode 
                        ? 'bg-gray-900 border-gray-700 text-gray-200' 
                        : 'bg-gray-800/40 border-gray-700/50 hover:border-gray-600 text-gray-300'
                } ${(isGeneratingImage || isExecutingChain) ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs font-medium">
                        <span className={`w-2 h-2 rounded-full ${isBatchMode ? 'bg-accent-secondary animate-pulse' : 'bg-gray-500'}`}></span>
                        <span>{t('batch.mode') || 'Batch API Mode'}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-gray-800 text-accent-secondary border border-gray-700 font-mono font-semibold">
                            -50% Cost
                        </span>
                    </div>
                    <div className={`w-8 h-4 rounded-full relative transition-colors flex-shrink-0 ${isBatchMode ? 'bg-accent-secondary' : 'bg-gray-600'}`}>
                        <div className={`absolute top-0.5 bottom-0.5 w-3 h-3 bg-white rounded-full shadow-sm transition-transform duration-200 ${isBatchMode ? 'translate-x-[16px]' : 'translate-x-[2px]'}`}></div>
                    </div>
                </div>
                <div className={`mt-1.5 text-[11px] leading-tight flex items-start gap-1 transition-colors ${
                    isBatchMode ? 'text-accent-secondary font-medium' : 'text-gray-400'
                }`}>
                    <span className={isBatchMode ? '' : 'opacity-70'}>⏳</span>
                    <span>{t('batch.statusDelayed') || 'Batch API Active (Delayed ~24h, -50% cost)'}</span>
                </div>
            </div>
            
            <div className="flex space-x-2 h-10">
                <TutorialTooltip 
                    content={t('tutorial.step3')} 
                    isActive={!!isTutorialActive} 
                    position="top" 
                    onSkip={skipTutorial} 
                    className="flex-grow h-full"
                >
                    {isGeneratingImage ? (
                        <button
                            onClick={() => {
                                if (context?.handleStopImage) {
                                    context.handleStopImage(node.id);
                                }
                            }}
                            className="w-full h-full px-4 font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors duration-200 flex items-center justify-center gap-1.5"
                            title={t('node.action.stop') || 'Stop'}
                        >
                            <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            <span>{t('node.content.generating')} (Stop)</span>
                        </button>
                    ) : (
                        <button
                            onClick={handleGenerateClick}
                            disabled={isExecutingChain || !!transformingRatio || isForming || !!activeBatchJob}
                            className={`w-full h-full px-4 font-bold text-white rounded-md disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center gap-1.5 ${
                                isBatchMode 
                                    ? 'bg-accent-secondary hover:bg-accent-secondary-hover active:bg-accent-secondary shadow-md' 
                                    : 'bg-accent hover:bg-accent-hover'
                            }`}
                        >
                            {isForming ? (
                                <>
                                    <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                    </svg>
                                    <span>{t('batch.formingRequest') || 'Forming batch request...'}</span>
                                </>
                            ) : activeBatchJob ? (
                                <span>{t('batch.waitingForResponseButton') || 'Waiting for response (Batch)'}</span>
                            ) : isBatchMode ? (
                                (t('node.content.generateImage_batch') || `${t('node.content.generateImage')} (Batch)`)
                            ) : (
                                t('node.content.generateImage')
                            )}
                        </button>
                    )}
                </TutorialTooltip>
                
                {isExecutingChain ? (
                    <button
                        onClick={onStopChainExecution}
                        className="h-10 w-10 flex-shrink-0 flex items-center justify-center font-bold text-white bg-red-600 rounded-md hover:bg-red-700 transition-colors duration-200"
                        title="Остановить выполнение"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8 7a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1zm4 0a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                        </svg>
                    </button>
                ) : (
                    <button
                        onClick={() => onExecuteChain(node.id)}
                        disabled={isGeneratingImage || isExecutingChain || !!transformingRatio}
                        className="h-10 w-10 flex-shrink-0 flex items-center justify-center font-bold text-white bg-accent-secondary rounded-md hover:bg-accent-secondary-hover disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors duration-200"
                        title={t('node.action.executeChainTitle')}
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                            <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </button>
                )}
            </div>
        </div>
    );
};
