import React from 'react';
import { PanelAnimation, Theme } from '../../../types';

export interface ThemeAnimationPalette {
  primary: string;
  secondary: string;
  highlight: string;
  dim: string;
  glow: string;
  subtleGlow: string;
  waveGradient: string[];
  auroraGradient: string[];
  neonStops: string[];
  svgStroke: string;
  svgFill: string;
  particleColor: string;
}

export const THEME_ANIMATION_PALETTES: Record<Theme, ThemeAnimationPalette> = {
  cyan: {
    primary: '#22d3ee',
    secondary: '#0891b2',
    highlight: '#67e8f9',
    dim: 'rgba(34, 211, 238, 0.10)',
    glow: 'rgba(34, 211, 238, 0.40)',
    subtleGlow: 'rgba(34, 211, 238, 0.16)',
    waveGradient: ['rgba(8, 145, 178, 0.05)', 'rgba(34, 211, 238, 0.18)', 'rgba(103, 232, 249, 0.28)', 'rgba(34, 211, 238, 0.18)', 'rgba(8, 145, 178, 0.05)'],
    auroraGradient: ['rgba(8, 145, 178, 0.25)', 'rgba(6, 182, 212, 0.35)', 'rgba(45, 212, 191, 0.35)', 'rgba(56, 189, 248, 0.30)'],
    neonStops: ['#0891b2', '#22d3ee', '#67e8f9', '#22d3ee', '#0891b2'],
    svgStroke: '#22d3ee',
    svgFill: 'rgba(34, 211, 238, 0.20)',
    particleColor: '#67e8f9',
  },
  orange: {
    primary: '#fb923c',
    secondary: '#ea580c',
    highlight: '#fed7aa',
    dim: 'rgba(251, 146, 60, 0.10)',
    glow: 'rgba(251, 146, 60, 0.40)',
    subtleGlow: 'rgba(251, 146, 60, 0.16)',
    waveGradient: ['rgba(234, 88, 12, 0.05)', 'rgba(251, 146, 60, 0.18)', 'rgba(254, 215, 170, 0.28)', 'rgba(251, 146, 60, 0.18)', 'rgba(234, 88, 12, 0.05)'],
    auroraGradient: ['rgba(194, 65, 12, 0.25)', 'rgba(234, 88, 12, 0.35)', 'rgba(251, 146, 60, 0.35)', 'rgba(245, 158, 11, 0.30)'],
    neonStops: ['#ea580c', '#fb923c', '#fed7aa', '#fb923c', '#ea580c'],
    svgStroke: '#fb923c',
    svgFill: 'rgba(251, 146, 60, 0.20)',
    particleColor: '#fed7aa',
  },
  pink: {
    primary: '#f472b6',
    secondary: '#db2777',
    highlight: '#fbcfe8',
    dim: 'rgba(244, 114, 182, 0.10)',
    glow: 'rgba(244, 114, 182, 0.40)',
    subtleGlow: 'rgba(244, 114, 182, 0.16)',
    waveGradient: ['rgba(219, 39, 119, 0.05)', 'rgba(244, 114, 182, 0.18)', 'rgba(251, 207, 232, 0.28)', 'rgba(244, 114, 182, 0.18)', 'rgba(219, 39, 119, 0.05)'],
    auroraGradient: ['rgba(190, 24, 93, 0.25)', 'rgba(219, 39, 119, 0.35)', 'rgba(244, 114, 182, 0.35)', 'rgba(168, 85, 247, 0.30)'],
    neonStops: ['#db2777', '#f472b6', '#fbcfe8', '#f472b6', '#db2777'],
    svgStroke: '#f472b6',
    svgFill: 'rgba(244, 114, 182, 0.20)',
    particleColor: '#fbcfe8',
  },
  gray: {
    primary: '#e4e4e7',
    secondary: '#71717a',
    highlight: '#ffffff',
    dim: 'rgba(228, 228, 231, 0.08)',
    glow: 'rgba(228, 228, 231, 0.35)',
    subtleGlow: 'rgba(228, 228, 231, 0.14)',
    waveGradient: ['rgba(113, 113, 122, 0.05)', 'rgba(228, 228, 231, 0.16)', 'rgba(255, 255, 255, 0.26)', 'rgba(228, 228, 231, 0.16)', 'rgba(113, 113, 122, 0.05)'],
    auroraGradient: ['rgba(82, 82, 91, 0.25)', 'rgba(161, 161, 170, 0.30)', 'rgba(212, 212, 216, 0.35)', 'rgba(113, 113, 122, 0.25)'],
    neonStops: ['#52525b', '#a1a1aa', '#ffffff', '#a1a1aa', '#52525b'],
    svgStroke: '#d4d4d8',
    svgFill: 'rgba(228, 228, 231, 0.18)',
    particleColor: '#ffffff',
  },
  lime: {
    primary: '#a3e635',
    secondary: '#65a30d',
    highlight: '#d9f99d',
    dim: 'rgba(163, 230, 53, 0.10)',
    glow: 'rgba(163, 230, 53, 0.40)',
    subtleGlow: 'rgba(163, 230, 53, 0.16)',
    waveGradient: ['rgba(101, 163, 13, 0.05)', 'rgba(163, 230, 53, 0.18)', 'rgba(217, 249, 157, 0.28)', 'rgba(163, 230, 53, 0.18)', 'rgba(101, 163, 13, 0.05)'],
    auroraGradient: ['rgba(77, 124, 15, 0.25)', 'rgba(101, 163, 13, 0.35)', 'rgba(163, 230, 53, 0.35)', 'rgba(202, 138, 4, 0.30)'],
    neonStops: ['#65a30d', '#a3e635', '#d9f99d', '#a3e635', '#65a30d'],
    svgStroke: '#a3e635',
    svgFill: 'rgba(163, 230, 53, 0.20)',
    particleColor: '#d9f99d',
  },
  purple: {
    primary: '#a78bfa',
    secondary: '#7c3aed',
    highlight: '#ede9fe',
    dim: 'rgba(167, 139, 250, 0.10)',
    glow: 'rgba(167, 139, 250, 0.40)',
    subtleGlow: 'rgba(167, 139, 250, 0.16)',
    waveGradient: ['rgba(124, 58, 237, 0.05)', 'rgba(167, 139, 250, 0.18)', 'rgba(237, 233, 254, 0.28)', 'rgba(167, 139, 250, 0.18)', 'rgba(124, 58, 237, 0.05)'],
    auroraGradient: ['rgba(109, 40, 217, 0.25)', 'rgba(124, 58, 237, 0.35)', 'rgba(167, 139, 250, 0.35)', 'rgba(99, 102, 241, 0.30)'],
    neonStops: ['#7c3aed', '#a78bfa', '#ede9fe', '#a78bfa', '#7c3aed'],
    svgStroke: '#a78bfa',
    svgFill: 'rgba(167, 139, 250, 0.20)',
    particleColor: '#ede9fe',
  },
  azure: {
    primary: '#38bdf8',
    secondary: '#0284c7',
    highlight: '#bae6fd',
    dim: 'rgba(56, 189, 248, 0.10)',
    glow: 'rgba(56, 189, 248, 0.40)',
    subtleGlow: 'rgba(56, 189, 248, 0.16)',
    waveGradient: ['rgba(2, 132, 199, 0.05)', 'rgba(56, 189, 248, 0.18)', 'rgba(186, 230, 253, 0.28)', 'rgba(56, 189, 248, 0.18)', 'rgba(2, 132, 199, 0.05)'],
    auroraGradient: ['rgba(2, 132, 199, 0.25)', 'rgba(59, 130, 246, 0.35)', 'rgba(96, 165, 250, 0.35)', 'rgba(14, 165, 233, 0.30)'],
    neonStops: ['#0284c7', '#38bdf8', '#bae6fd', '#38bdf8', '#0284c7'],
    svgStroke: '#38bdf8',
    svgFill: 'rgba(56, 189, 248, 0.20)',
    particleColor: '#bae6fd',
  },
  red: {
    primary: '#f87171',
    secondary: '#dc2626',
    highlight: '#fee2e2',
    dim: 'rgba(248, 113, 113, 0.10)',
    glow: 'rgba(248, 113, 113, 0.40)',
    subtleGlow: 'rgba(248, 113, 113, 0.16)',
    waveGradient: ['rgba(220, 38, 38, 0.05)', 'rgba(248, 113, 113, 0.18)', 'rgba(254, 226, 226, 0.28)', 'rgba(248, 113, 113, 0.18)', 'rgba(220, 38, 38, 0.05)'],
    auroraGradient: ['rgba(185, 28, 28, 0.25)', 'rgba(220, 38, 38, 0.35)', 'rgba(248, 113, 113, 0.35)', 'rgba(225, 29, 72, 0.30)'],
    neonStops: ['#dc2626', '#f87171', '#fee2e2', '#f87171', '#dc2626'],
    svgStroke: '#f87171',
    svgFill: 'rgba(248, 113, 113, 0.20)',
    particleColor: '#fee2e2',
  },
  amber: {
    primary: '#fbbf24',
    secondary: '#d97706',
    highlight: '#fef3c7',
    dim: 'rgba(251, 191, 36, 0.10)',
    glow: 'rgba(245, 158, 11, 0.40)',
    subtleGlow: 'rgba(245, 158, 11, 0.16)',
    waveGradient: ['rgba(217, 119, 6, 0.05)', 'rgba(251, 191, 36, 0.18)', 'rgba(254, 243, 199, 0.28)', 'rgba(251, 191, 36, 0.18)', 'rgba(217, 119, 6, 0.05)'],
    auroraGradient: ['rgba(180, 83, 9, 0.25)', 'rgba(217, 119, 6, 0.35)', 'rgba(251, 191, 36, 0.35)', 'rgba(245, 158, 11, 0.30)'],
    neonStops: ['#d97706', '#fbbf24', '#fef3c7', '#fbbf24', '#d97706'],
    svgStroke: '#fbbf24',
    svgFill: 'rgba(251, 191, 36, 0.20)',
    particleColor: '#fef3c7',
  },
  teal: {
    primary: '#2dd4bf',
    secondary: '#0d9488',
    highlight: '#ccfbf1',
    dim: 'rgba(45, 212, 191, 0.10)',
    glow: 'rgba(20, 184, 166, 0.40)',
    subtleGlow: 'rgba(20, 184, 166, 0.16)',
    waveGradient: ['rgba(13, 148, 136, 0.05)', 'rgba(45, 212, 191, 0.18)', 'rgba(204, 251, 241, 0.28)', 'rgba(45, 212, 191, 0.18)', 'rgba(13, 148, 136, 0.05)'],
    auroraGradient: ['rgba(15, 118, 110, 0.25)', 'rgba(13, 148, 136, 0.35)', 'rgba(45, 212, 191, 0.35)', 'rgba(6, 182, 212, 0.30)'],
    neonStops: ['#0d9488', '#2dd4bf', '#ccfbf1', '#2dd4bf', '#0d9488'],
    svgStroke: '#2dd4bf',
    svgFill: 'rgba(45, 212, 191, 0.20)',
    particleColor: '#ccfbf1',
  },
  rose: {
    primary: '#fb7185',
    secondary: '#e11d48',
    highlight: '#ffe4e6',
    dim: 'rgba(251, 113, 133, 0.10)',
    glow: 'rgba(244, 63, 94, 0.40)',
    subtleGlow: 'rgba(244, 63, 94, 0.16)',
    waveGradient: ['rgba(225, 29, 72, 0.05)', 'rgba(251, 113, 133, 0.18)', 'rgba(255, 228, 230, 0.28)', 'rgba(251, 113, 133, 0.18)', 'rgba(225, 29, 72, 0.05)'],
    auroraGradient: ['rgba(190, 18, 60, 0.25)', 'rgba(225, 29, 72, 0.35)', 'rgba(251, 113, 133, 0.35)', 'rgba(244, 63, 94, 0.30)'],
    neonStops: ['#e11d48', '#fb7185', '#ffe4e6', '#fb7185', '#e11d48'],
    svgStroke: '#fb7185',
    svgFill: 'rgba(251, 113, 133, 0.20)',
    particleColor: '#ffe4e6',
  },
  emerald: {
    primary: '#34d399',
    secondary: '#059669',
    highlight: '#a7f3d0',
    dim: 'rgba(52, 211, 153, 0.10)',
    glow: 'rgba(52, 211, 153, 0.40)',
    subtleGlow: 'rgba(52, 211, 153, 0.16)',
    waveGradient: ['rgba(5, 150, 105, 0.05)', 'rgba(52, 211, 153, 0.18)', 'rgba(167, 243, 208, 0.28)', 'rgba(52, 211, 153, 0.18)', 'rgba(5, 150, 105, 0.05)'],
    auroraGradient: ['rgba(5, 150, 105, 0.25)', 'rgba(16, 185, 129, 0.35)', 'rgba(45, 212, 191, 0.35)', 'rgba(13, 148, 136, 0.30)'],
    neonStops: ['#059669', '#34d399', '#a7f3d0', '#34d399', '#059669'],
    svgStroke: '#34d399',
    svgFill: 'rgba(52, 211, 153, 0.20)',
    particleColor: '#a7f3d0',
  },
  pastel_mint: {
    primary: '#5eead4',
    secondary: '#0f766e',
    highlight: '#99f6e4',
    dim: 'rgba(94, 234, 212, 0.12)',
    glow: 'rgba(94, 234, 212, 0.35)',
    subtleGlow: 'rgba(94, 234, 212, 0.14)',
    waveGradient: ['rgba(15, 118, 110, 0.05)', 'rgba(94, 234, 212, 0.16)', 'rgba(153, 246, 228, 0.24)', 'rgba(94, 234, 212, 0.16)', 'rgba(15, 118, 110, 0.05)'],
    auroraGradient: ['rgba(15, 118, 110, 0.20)', 'rgba(45, 212, 191, 0.25)', 'rgba(94, 234, 212, 0.25)', 'rgba(153, 246, 228, 0.22)'],
    neonStops: ['#0f766e', '#2dd4bf', '#99f6e4', '#2dd4bf', '#0f766e'],
    svgStroke: '#5eead4',
    svgFill: 'rgba(94, 234, 212, 0.18)',
    particleColor: '#99f6e4',
  },
  pastel_lavender: {
    primary: '#c4b5db',
    secondary: '#5b4b70',
    highlight: '#e2d9ee',
    dim: 'rgba(196, 181, 219, 0.12)',
    glow: 'rgba(196, 181, 219, 0.30)',
    subtleGlow: 'rgba(196, 181, 219, 0.14)',
    waveGradient: ['rgba(91, 75, 112, 0.05)', 'rgba(196, 181, 219, 0.16)', 'rgba(226, 217, 238, 0.24)', 'rgba(196, 181, 219, 0.16)', 'rgba(91, 75, 112, 0.05)'],
    auroraGradient: ['rgba(91, 75, 112, 0.20)', 'rgba(169, 154, 194, 0.25)', 'rgba(196, 181, 219, 0.25)', 'rgba(226, 217, 238, 0.20)'],
    neonStops: ['#5b4b70', '#a99ac2', '#e2d9ee', '#a99ac2', '#5b4b70'],
    svgStroke: '#c4b5db',
    svgFill: 'rgba(196, 181, 219, 0.16)',
    particleColor: '#e2d9ee',
  },
  pastel_peach: {
    primary: '#ebba9e',
    secondary: '#7d4e38',
    highlight: '#f5d5c3',
    dim: 'rgba(235, 186, 158, 0.12)',
    glow: 'rgba(235, 186, 158, 0.30)',
    subtleGlow: 'rgba(235, 186, 158, 0.14)',
    waveGradient: ['rgba(125, 78, 56, 0.05)', 'rgba(235, 186, 158, 0.16)', 'rgba(245, 213, 195, 0.24)', 'rgba(235, 186, 158, 0.16)', 'rgba(125, 78, 56, 0.05)'],
    auroraGradient: ['rgba(125, 78, 56, 0.20)', 'rgba(217, 156, 123, 0.25)', 'rgba(235, 186, 158, 0.25)', 'rgba(245, 213, 195, 0.20)'],
    neonStops: ['#7d4e38', '#d99c7b', '#f5d5c3', '#d99c7b', '#7d4e38'],
    svgStroke: '#ebba9e',
    svgFill: 'rgba(235, 186, 158, 0.16)',
    particleColor: '#f5d5c3',
  },
  pastel_rose: {
    primary: '#e2afc3',
    secondary: '#704859',
    highlight: '#f2d3df',
    dim: 'rgba(226, 175, 195, 0.12)',
    glow: 'rgba(226, 175, 195, 0.30)',
    subtleGlow: 'rgba(226, 175, 195, 0.14)',
    waveGradient: ['rgba(112, 72, 89, 0.05)', 'rgba(226, 175, 195, 0.16)', 'rgba(242, 211, 223, 0.24)', 'rgba(226, 175, 195, 0.16)', 'rgba(112, 72, 89, 0.05)'],
    auroraGradient: ['rgba(112, 72, 89, 0.20)', 'rgba(204, 162, 181, 0.25)', 'rgba(226, 175, 195, 0.25)', 'rgba(242, 211, 223, 0.20)'],
    neonStops: ['#704859', '#cca2b5', '#f2d3df', '#cca2b5', '#704859'],
    svgStroke: '#e2afc3',
    svgFill: 'rgba(226, 175, 195, 0.16)',
    particleColor: '#f2d3df',
  },
  pastel_sky: {
    primary: '#a5c6de',
    secondary: '#3d5a73',
    highlight: '#cde0ee',
    dim: 'rgba(165, 198, 222, 0.12)',
    glow: 'rgba(165, 198, 222, 0.30)',
    subtleGlow: 'rgba(165, 198, 222, 0.14)',
    waveGradient: ['rgba(61, 90, 115, 0.05)', 'rgba(165, 198, 222, 0.16)', 'rgba(205, 224, 238, 0.24)', 'rgba(165, 198, 222, 0.16)', 'rgba(61, 90, 115, 0.05)'],
    auroraGradient: ['rgba(61, 90, 115, 0.20)', 'rgba(142, 174, 200, 0.25)', 'rgba(165, 198, 222, 0.25)', 'rgba(205, 224, 238, 0.20)'],
    neonStops: ['#3d5a73', '#8eaec8', '#cde0ee', '#8eaec8', '#3d5a73'],
    svgStroke: '#a5c6de',
    svgFill: 'rgba(165, 198, 222, 0.16)',
    particleColor: '#cde0ee',
  },
  pastel_vanilla: {
    primary: '#e8d49d',
    secondary: '#6d5a37',
    highlight: '#f4e6be',
    dim: 'rgba(232, 212, 157, 0.12)',
    glow: 'rgba(232, 212, 157, 0.30)',
    subtleGlow: 'rgba(232, 212, 157, 0.14)',
    waveGradient: ['rgba(109, 90, 55, 0.05)', 'rgba(232, 212, 157, 0.16)', 'rgba(244, 230, 190, 0.24)', 'rgba(232, 212, 157, 0.16)', 'rgba(109, 90, 55, 0.05)'],
    auroraGradient: ['rgba(109, 90, 55, 0.20)', 'rgba(214, 190, 127, 0.25)', 'rgba(232, 212, 157, 0.25)', 'rgba(244, 230, 190, 0.20)'],
    neonStops: ['#6d5a37', '#d6be7f', '#f4e6be', '#d6be7f', '#6d5a37'],
    svgStroke: '#e8d49d',
    svgFill: 'rgba(232, 212, 157, 0.16)',
    particleColor: '#f4e6be',
  },
  pastel_sage: {
    primary: '#a8cbb3',
    secondary: '#405d4b',
    highlight: '#cee3d5',
    dim: 'rgba(168, 203, 179, 0.12)',
    glow: 'rgba(168, 203, 179, 0.30)',
    subtleGlow: 'rgba(168, 203, 179, 0.14)',
    waveGradient: ['rgba(64, 93, 75, 0.05)', 'rgba(168, 203, 179, 0.16)', 'rgba(206, 227, 213, 0.24)', 'rgba(168, 203, 179, 0.16)', 'rgba(64, 93, 75, 0.05)'],
    auroraGradient: ['rgba(64, 93, 75, 0.20)', 'rgba(145, 181, 157, 0.25)', 'rgba(168, 203, 179, 0.25)', 'rgba(206, 227, 213, 0.20)'],
    neonStops: ['#405d4b', '#91b59d', '#cee3d5', '#91b59d', '#405d4b'],
    svgStroke: '#a8cbb3',
    svgFill: 'rgba(168, 203, 179, 0.16)',
    particleColor: '#cee3d5',
  },
  pastel_sand: {
    primary: '#e6ccb2',
    secondary: '#78583c',
    highlight: '#fbf8f5',
    dim: 'rgba(230, 204, 178, 0.12)',
    glow: 'rgba(230, 204, 178, 0.30)',
    subtleGlow: 'rgba(230, 204, 178, 0.14)',
    waveGradient: ['rgba(120, 88, 60, 0.05)', 'rgba(230, 204, 178, 0.16)', 'rgba(251, 248, 245, 0.24)', 'rgba(230, 204, 178, 0.16)', 'rgba(120, 88, 60, 0.05)'],
    auroraGradient: ['rgba(120, 88, 60, 0.20)', 'rgba(212, 185, 150, 0.25)', 'rgba(230, 204, 178, 0.25)', 'rgba(237, 224, 212, 0.20)'],
    neonStops: ['#78583c', '#d4b996', '#fbf8f5', '#d4b996', '#78583c'],
    svgStroke: '#e6ccb2',
    svgFill: 'rgba(230, 204, 178, 0.16)',
    particleColor: '#fbf8f5',
  },
};

// Default signature palettes for standalone (non-adaptive) mode
export const DEFAULT_ANIMATION_PALETTES: Record<PanelAnimation, ThemeAnimationPalette> = {
  shimmer: THEME_ANIMATION_PALETTES.gray,
  pulse: THEME_ANIMATION_PALETTES.cyan,
  breath: THEME_ANIMATION_PALETTES.azure,
  wave: THEME_ANIMATION_PALETTES.azure,
  aurora: {
    ...THEME_ANIMATION_PALETTES.cyan,
    auroraGradient: ['rgba(16, 185, 129, 0.30)', 'rgba(6, 182, 212, 0.35)', 'rgba(168, 85, 247, 0.35)', 'rgba(236, 72, 153, 0.30)'],
  },
  neon: {
    ...THEME_ANIMATION_PALETTES.cyan,
    neonStops: ['#38bdf8', '#818cf8', '#c084fc', '#f472b6', '#38bdf8'],
  },
  shapes_bubbles: {
    ...THEME_ANIMATION_PALETTES.azure,
    svgStroke: '#38bdf8',
    svgFill: 'rgba(56, 189, 248, 0.25)',
    particleColor: '#bae6fd',
  },
  shapes_ocean: {
    ...THEME_ANIMATION_PALETTES.cyan,
    svgStroke: '#06b6d4',
    svgFill: 'rgba(8, 145, 178, 0.30)',
    particleColor: '#67e8f9',
  },
  shapes_geometry: {
    ...THEME_ANIMATION_PALETTES.purple,
    svgStroke: '#a855f7',
    svgFill: 'rgba(168, 85, 247, 0.20)',
    particleColor: '#e9d5ff',
  },
  shapes_techno: {
    ...THEME_ANIMATION_PALETTES.lime,
    svgStroke: '#84cc16',
    svgFill: 'rgba(132, 204, 22, 0.25)',
    particleColor: '#bef264',
  },
  shapes_cyber: {
    ...THEME_ANIMATION_PALETTES.purple,
    svgStroke: '#ec4899',
    svgFill: 'rgba(236, 72, 153, 0.25)',
    particleColor: '#38bdf8',
  },
  shapes_nature: {
    ...THEME_ANIMATION_PALETTES.emerald,
    svgStroke: '#10b981',
    svgFill: 'rgba(16, 185, 129, 0.25)',
    particleColor: '#fbbf24',
  },
  shapes_space: {
    ...THEME_ANIMATION_PALETTES.purple,
    svgStroke: '#818cf8',
    svgFill: 'rgba(99, 102, 241, 0.25)',
    particleColor: '#ffffff',
  },
  none: THEME_ANIMATION_PALETTES.gray,
};

export interface PanelAnimationOption {
  id: PanelAnimation;
  labelKey: string;
  descKey: string;
  badge?: string;
  iconName: string;
}

export interface PanelAnimationCategoryGroup {
  id: string;
  titleKey: string;
  icon: string;
  items: PanelAnimationOption[];
}

export const PANEL_ANIMATION_GROUPS: PanelAnimationCategoryGroup[] = [
  {
    id: 'lightEffects',
    titleKey: 'settings.panelAnimationGroup.lightEffects',
    icon: 'sparkles',
    items: [
      {
        id: 'shimmer',
        labelKey: 'settings.panelAnimation.shimmer',
        descKey: 'settings.panelAnimation.shimmerDesc',
        iconName: 'shimmer',
      },
      {
        id: 'pulse',
        labelKey: 'settings.panelAnimation.pulse',
        descKey: 'settings.panelAnimation.pulseDesc',
        iconName: 'pulse',
      },
      {
        id: 'breath',
        labelKey: 'settings.panelAnimation.breath',
        descKey: 'settings.panelAnimation.breathDesc',
        iconName: 'breath',
      },
      {
        id: 'wave',
        labelKey: 'settings.panelAnimation.wave',
        descKey: 'settings.panelAnimation.waveDesc',
        iconName: 'wave',
      },
      {
        id: 'aurora',
        labelKey: 'settings.panelAnimation.aurora',
        descKey: 'settings.panelAnimation.auroraDesc',
        iconName: 'aurora',
      },
      {
        id: 'neon',
        labelKey: 'settings.panelAnimation.neon',
        descKey: 'settings.panelAnimation.neonDesc',
        iconName: 'neon',
      },
      {
        id: 'none',
        labelKey: 'settings.panelAnimation.none',
        descKey: 'settings.panelAnimation.noneDesc',
        iconName: 'none',
      },
    ],
  },
  {
    id: 'vectorShapes',
    titleKey: 'settings.panelAnimationGroup.vectorShapes',
    icon: 'shapes',
    items: [
      {
        id: 'shapes_bubbles',
        labelKey: 'settings.panelAnimation.shapes_bubbles',
        descKey: 'settings.panelAnimation.shapes_bubblesDesc',
        iconName: 'bubbles',
      },
      {
        id: 'shapes_ocean',
        labelKey: 'settings.panelAnimation.shapes_ocean',
        descKey: 'settings.panelAnimation.shapes_oceanDesc',
        iconName: 'ocean',
      },
      {
        id: 'shapes_geometry',
        labelKey: 'settings.panelAnimation.shapes_geometry',
        descKey: 'settings.panelAnimation.shapes_geometryDesc',
        iconName: 'geometry',
      },
      {
        id: 'shapes_techno',
        labelKey: 'settings.panelAnimation.shapes_techno',
        descKey: 'settings.panelAnimation.shapes_technoDesc',
        iconName: 'techno',
      },
      {
        id: 'shapes_cyber',
        labelKey: 'settings.panelAnimation.shapes_cyber',
        descKey: 'settings.panelAnimation.shapes_cyberDesc',
        iconName: 'cyber',
      },
      {
        id: 'shapes_nature',
        labelKey: 'settings.panelAnimation.shapes_nature',
        descKey: 'settings.panelAnimation.shapes_natureDesc',
        iconName: 'nature',
      },
      {
        id: 'shapes_space',
        labelKey: 'settings.panelAnimation.shapes_space',
        descKey: 'settings.panelAnimation.shapes_spaceDesc',
        iconName: 'space',
      },
    ],
  },
];

export const getEffectivePalette = (
  anim: PanelAnimation,
  theme: Theme,
  isAdaptive: boolean
): ThemeAnimationPalette => {
  if (isAdaptive) {
    return THEME_ANIMATION_PALETTES[theme] || THEME_ANIMATION_PALETTES.cyan;
  }
  return DEFAULT_ANIMATION_PALETTES[anim] || THEME_ANIMATION_PALETTES.cyan;
};

export interface BubbleAnimationConfig {
  count: number;          // Bubble density / count (4 - 40, default: 14)
  baseSize: number;       // Base bubble radius (15 - 90 px, default: 40)
  sizeVariance: number;   // Random size variance % (0 - 100%, default: 50%)
  baseSpeed: number;      // Base upward speed (6 - 60 px/s, default: 24)
  speedVariance: number;  // Speed variance % (0 - 100%, default: 45%)
  opacity: number;        // Opacity / Glow intensity (0.1 - 1.0, default: 0.65)
  wobbleAmp: number;      // Horizontal wave wobble amplitude (0 - 25 px, default: 10)
}

export interface CyberGridAnimationConfig {
  count: number;          // Photon tracer density / count (2 - 30, default: 9)
  gridWidth: number;      // Matrix cell width (16 - 80 px, default: 36)
  gridHeight: number;     // Matrix cell height (8 - 40 px, default: 14)
  baseSize: number;       // Tracer head radius (1.0 - 5.0 px, default: 2.2)
  sizeVariance: number;   // Size variance % (0 - 100%, default: 40%)
  baseSpeed: number;      // Base tracer speed (40 - 360 px/s, default: 160)
  speedVariance: number;  // Speed variance % (0 - 100%, default: 40%)
  tailLength: number;     // Laser trail length (20 - 300 px, default: 120)
  tailOpacity: number;    // Trail opacity / brightness (0.1 - 1.0, default: 0.85)
  allowTurns: boolean;    // Allow tracers to turn 90° at grid intersections (default: true)
  turnChance: number;     // Probability to turn at junction % (5 - 95%, default: 35%)
}

export interface PanelAnimationConfig {
  shapes_bubbles: BubbleAnimationConfig;
  shapes_cyber: CyberGridAnimationConfig;
}

export const DEFAULT_BUBBLE_CONFIG: BubbleAnimationConfig = {
  count: 14,
  baseSize: 40,
  sizeVariance: 50,
  baseSpeed: 24,
  speedVariance: 45,
  opacity: 0.65,
  wobbleAmp: 10,
};

export const DEFAULT_CYBER_CONFIG: CyberGridAnimationConfig = {
  count: 9,
  gridWidth: 36,
  gridHeight: 14,
  baseSize: 2.2,
  sizeVariance: 40,
  baseSpeed: 160,
  speedVariance: 40,
  tailLength: 120,
  tailOpacity: 0.85,
  allowTurns: true,
  turnChance: 35,
};

export const DEFAULT_PANEL_ANIMATION_CONFIG: PanelAnimationConfig = {
  shapes_bubbles: DEFAULT_BUBBLE_CONFIG,
  shapes_cyber: DEFAULT_CYBER_CONFIG,
};

export const isConfigurableAnimation = (
  anim: string
): anim is keyof PanelAnimationConfig => {
  return anim === 'shapes_bubbles' || anim === 'shapes_cyber';
};

