
import React, { useMemo, useRef, useEffect, useState } from 'react';
import { NodeType, ConnectingInfo, Point } from '../types';
import { useLanguage } from '../localization';
import { useAppContext } from '../contexts/AppContext';
import { ThreeDModelIcon, BatchPrepareIcon } from './icons/AppIcons';

interface ConnectionQuickAddMenuProps {
  isOpen: boolean;
  info: { position: Point; connectingInfo: ConnectingInfo; sourceNodeType?: NodeType } | null;
  onClose: () => void;
  onSelect: (type: NodeType) => void;
}

const NODE_HOTKEY_MAP: Partial<Record<NodeType, string>> = {
  [NodeType.IMAGE_INPUT]: 'I',
  [NodeType.IMAGE_EDITOR]: 'Shift+I',
  [NodeType.BATCH_PREPARE]: 'Shift+D',
  [NodeType.THREE_D_VIEWER]: 'Shift+G',
  [NodeType.IMAGE_OUTPUT]: 'O',
  [NodeType.PROMPT_ANALYZER]: 'A',
  [NodeType.IMAGE_ANALYZER]: 'Shift+A',
  [NodeType.PROMPT_PROCESSOR]: 'P',
  [NodeType.VIDEO_PROMPT_PROCESSOR]: 'Shift+P',
  [NodeType.TRANSLATOR]: 'L',
  [NodeType.REROUTE_DOT]: 'R',
  [NodeType.DATA_READER]: 'Shift+R',
  [NodeType.VIDEO_EDITOR]: 'E',
  [NodeType.IMAGE_SEQUENCE_GENERATOR]: 'Shift+Q',
  [NodeType.THREE_D_GENERATOR]: 'Shift+T',
};

const ConnectionQuickAddMenu: React.FC<ConnectionQuickAddMenuProps> = ({ isOpen, info, onClose, onSelect }) => {
  const { t } = useLanguage();
  const context = useAppContext();
  const menuRef = useRef<HTMLDivElement>(null);
  const [style, setStyle] = useState<React.CSSProperties>({ opacity: 0, pointerEvents: 'none' });

  const menuItems = useMemo(() => ({
    text: [
      { type: NodeType.IMAGE_INPUT, title: t('toolbar.addImageInput'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><rect x="3" y="3" width="18" height="18" rx="2" ry="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path strokeLinecap="round" strokeLinejoin="round" d="M21 15l-5-5L5 21" /></svg> },
      { type: NodeType.IMAGE_EDITOR, title: t('toolbar.addImageEditor'), icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-6 w-6"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5z" /><path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125" /></svg> },
      { type: NodeType.THREE_D_VIEWER, title: t('toolbar.addThreeDViewer') || 'Add 3D GLB Viewer', icon: <ThreeDModelIcon className="h-6 w-6 text-cyan-400" /> },
      { type: NodeType.BATCH_PREPARE, title: t('toolbar.addBatchPrepare') || 'Add 3D Batch Prepare', icon: <BatchPrepareIcon className="h-6 w-6" /> },
      { type: NodeType.THREE_D_GENERATOR, title: t('toolbar.addThreeDGenerator'), icon: <ThreeDModelIcon className="h-6 w-6" /> },
      { type: NodeType.PROMPT_ANALYZER, title: t('toolbar.addPromptAnalyzer'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" /><path strokeLinecap="round" strokeLinejoin="round" d="M9 14h6M9 11h6M9 8h6" /></svg> },
      { type: NodeType.PROMPT_PROCESSOR, title: t('toolbar.addPromptProcessor'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.898 20.562L16.25 22.5l-.648-1.938a3.375 3.375 0 00-2.672-2.672L11.25 18l1.938-.648a3.375 3.375 0 002.672 2.672L16.25 13l.648 1.938a3.375 3.375 0 002.672 2.672L21.75 18l-1.938.648a3.375 3.375 0 00-2.672 2.672z" /></svg> },
      { type: NodeType.VIDEO_PROMPT_PROCESSOR, title: t('toolbar.addVideoPromptProcessor'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /><path strokeLinecap="round" strokeLinejoin="round" d="M12 7l-2 4 4 2-4 2-2 4-2-4-4-2 4-2z" /></svg> },
      { type: NodeType.TRANSLATOR, title: t('toolbar.addTranslator'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L12 6l6 12M8 14h8" /></svg> },
      { type: NodeType.IMAGE_OUTPUT, title: t('toolbar.addImageOutput'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.774 48.774 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316z" /><path strokeLinecap="round" strokeLinejoin="round" d="M16.5 12.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0z" /></svg> },
      { type: NodeType.REROUTE_DOT, title: t('node.title.reroute_dot'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M13 5l7 7-7 7M5 5l7 7-7 7" /></svg> },
      { type: NodeType.DATA_READER, title: t('toolbar.addDataReader'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg> },
    ],
    image: [
      { type: NodeType.IMAGE_INPUT, title: t('toolbar.addImageInput'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><rect x="3" y="3" width="18" height="18" rx="2" ry="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path strokeLinecap="round" strokeLinejoin="round" d="M21 15l-5-5L5 21" /></svg> },
      { type: NodeType.IMAGE_EDITOR, title: t('toolbar.addImageEditor'), icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-6 w-6"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5z" /><path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125" /></svg> },
      { type: NodeType.THREE_D_VIEWER, title: t('toolbar.addThreeDViewer') || 'Add 3D GLB Viewer', icon: <ThreeDModelIcon className="h-6 w-6 text-cyan-400" /> },
      { type: NodeType.BATCH_PREPARE, title: t('toolbar.addBatchPrepare') || 'Add 3D Batch Prepare', icon: <BatchPrepareIcon className="h-6 w-6" /> },
      { type: NodeType.THREE_D_GENERATOR, title: t('toolbar.addThreeDGenerator'), icon: <ThreeDModelIcon className="h-6 w-6" /> },
      { type: NodeType.IMAGE_ANALYZER, title: t('toolbar.addImageAnalyzer'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M21 12.792V5.25a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 5.25v13.5A2.25 2.25 0 005.25 21h7.55" /><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 15.75a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M18.375 18.375L21 21" /></svg> },
      { type: NodeType.IMAGE_OUTPUT, title: t('toolbar.addImageOutput'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.774 48.774 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316z" /><path strokeLinecap="round" strokeLinejoin="round" d="M16.5 12.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0z" /></svg> },
      { type: NodeType.REROUTE_DOT, title: t('node.title.reroute_dot'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M13 5l7 7-7 7M5 5l7 7-7 7" /></svg> },
      { type: NodeType.DATA_READER, title: t('toolbar.addDataReader'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg> },
    ],
    video: [
      { type: NodeType.VIDEO_EDITOR, title: t('node.title.video_editor'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M3 6a2 2 0 012-2h14a2 2 0 012 2v12a2 2 0 01-2 2H5a2 2 0 01-2-2V6z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg> },
      { type: NodeType.REROUTE_DOT, title: t('node.title.reroute_dot'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M13 5l7 7-7 7M5 5l7 7-7 7" /></svg> },
      { type: NodeType.DATA_READER, title: t('toolbar.addDataReader'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg> },
    ],
    audio: [
      { type: NodeType.VIDEO_EDITOR, title: t('node.title.video_editor'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M3 6a2 2 0 012-2h14a2 2 0 012 2v12a2 2 0 01-2 2H5a2 2 0 01-2-2V6z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg> },
      { type: NodeType.REROUTE_DOT, title: t('node.title.reroute_dot'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M13 5l7 7-7 7M5 5l7 7-7 7" /></svg> },
      { type: NodeType.DATA_READER, title: t('toolbar.addDataReader'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg> },
    ],
    character_data: [
      { type: NodeType.IMAGE_SEQUENCE_GENERATOR, title: t('toolbar.addImageSequenceGenerator'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6 5h12M6 9h12M6 13h12M6 17h12M3 3h2.5v18H3zm15.5 0H21v18h-2.5z" /></svg> },
      { type: NodeType.REROUTE_DOT, title: t('node.title.reroute_dot'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M13 5l7 7-7 7M5 5l7 7-7 7" /></svg> },
      { type: NodeType.DATA_READER, title: t('toolbar.addDataReader'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg> },
    ],
    prompt_sequence: [
      { type: NodeType.IMAGE_SEQUENCE_GENERATOR, title: t('toolbar.addImageSequenceGenerator'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6 5h12M6 9h12M6 13h12M6 17h12M3 3h2.5v18H3zm15.5 0H21v18h-2.5z" /></svg> },
      { type: NodeType.DATA_READER, title: t('toolbar.addDataReader'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg> },
      { type: NodeType.REROUTE_DOT, title: t('node.title.reroute_dot'), icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M13 5l7 7-7 7M5 5l7 7-7 7" /></svg> },
    ]
  }), [t]);

  const currentOptions = useMemo(() => {
    if (!info) return [];
    if (info.sourceNodeType === NodeType.PROMPT_SEQUENCE_EDITOR) {
      return menuItems['prompt_sequence'];
    }
    return (info.connectingInfo.fromType ? menuItems[info.connectingInfo.fromType as 'text' | 'image' | 'character_data' | 'video' | 'audio'] : []) || [];
  }, [info, menuItems]);

  const currentConnectionColor = useMemo(() => {
    switch (info?.connectingInfo.fromType) {
      case 'image': return 'var(--color-connection-image)';
      case 'video': return 'var(--color-connection-video)';
      case 'audio': return 'var(--color-connection-audio)';
      case 'character_data': return 'var(--color-connection-character)';
      case 'text':
      default:
        return 'var(--color-connection-text)';
    }
  }, [info?.connectingInfo.fromType]);

  const borderColorClass = useMemo(() => {
    switch (info?.connectingInfo.fromType) {
      case 'image': return 'border-connection-image';
      case 'video': return 'border-connection-video';
      case 'audio': return 'border-connection-audio';
      case 'character_data': return 'border-connection-character';
      case 'text':
      default:
        return 'border-connection-text';
    }
  }, [info?.connectingInfo.fromType]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onClose();
      }
    };
    
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)) return;

      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        onClose();
        return;
      }

      const key = parseInt(e.key);
      if (!isNaN(key) && key > 0 && key <= 9) {
        const index = key - 1;
        if (currentOptions[index]) {
          e.preventDefault();
          e.stopPropagation();
          onSelect(currentOptions[index].type);
          return;
        }
      }

      const pressedKey = e.key.toUpperCase();
      const pressedCode = e.code;

      const matchedItem = currentOptions.find(item => {
        const expectedHotkey = NODE_HOTKEY_MAP[item.type];
        if (!expectedHotkey) return false;
        
        const parts = expectedHotkey.split('+').map(p => p.trim().toUpperCase());
        const needsShift = parts.includes('SHIFT');
        const needsCtrl = parts.includes('CTRL') || parts.includes('CMD');
        const needsAlt = parts.includes('ALT');
        const keyPart = parts[parts.length - 1];
        
        if (e.shiftKey !== needsShift) return false;
        if ((e.ctrlKey || e.metaKey) !== needsCtrl) return false;
        if (e.altKey !== needsAlt) return false;
        
        return pressedKey === keyPart || pressedCode === `Key${keyPart}`;
      });

      if (matchedItem) {
        e.preventDefault();
        e.stopPropagation();
        onSelect(matchedItem.type);
        return;
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      window.addEventListener('keydown', handleKeyDown, true);
    }
    
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      window.removeEventListener('keydown', handleKeyDown, true);
    };
  }, [isOpen, onClose, currentOptions, onSelect]);

  useEffect(() => {
    if (isOpen && menuRef.current && info) {
      const { position } = info;
      if (currentOptions.length === 0) {
        onClose();
        return;
      }

      const menuRect = menuRef.current.getBoundingClientRect();
      const minTop = context?.isStatusBarOpen ? 135 : 84;
      let left = position.x + 10;
      let top = position.y + 10;
      if (left + menuRect.width > window.innerWidth) {
        left = position.x - menuRect.width - 10;
      }
      if (top + menuRect.height > window.innerHeight) {
        top = position.y - menuRect.height - 10;
      }
      setStyle({ 
        left: Math.max(0, left), 
        top: Math.max(minTop, top),
        position: 'fixed',
        opacity: 1,
        transition: 'opacity 150ms ease-in-out',
      });
    } else if (!isOpen) {
      setStyle({ opacity: 0, pointerEvents: 'none' });
    }
  }, [isOpen, info, currentOptions, onClose]);

  return (
    <div
      ref={menuRef}
      className={`fixed bg-gray-900/95 backdrop-blur-md rounded-xl shadow-2xl p-2 flex flex-col space-y-1 z-50 border-2 border-dashed ${borderColorClass}`}
      style={{
        ...style,
        borderColor: currentConnectionColor,
        boxShadow: `0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 0 15px -2px ${currentConnectionColor}`
      }}
      onMouseDown={e => e.stopPropagation()}
    >
      {currentOptions.map((item, index) => {
        const hotkey = NODE_HOTKEY_MAP[item.type];
        const cleanTitle = item.title.replace(/\s*\([^)]+\)\s*$/, '');
        return (
          <button
            key={item.type}
            onClick={() => onSelect(item.type)}
            className="flex items-center justify-between p-2 rounded-lg text-left w-full text-gray-200 hover:bg-accent hover:text-white transition-colors group"
          >
            <div className="flex items-center space-x-3">
              <span className="text-xs font-mono font-bold text-gray-500 group-hover:text-white w-4 text-right">{index + 1}.</span>
              <div className="flex-shrink-0 w-6 h-6 flex items-center justify-center text-gray-300 group-hover:text-white">{item.icon}</div>
              <span className="text-sm font-semibold">{cleanTitle}</span>
            </div>
            {hotkey && (
              <span className="ml-3 text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-gray-800 group-hover:bg-accent-hover text-gray-400 group-hover:text-white border border-gray-700/60 transition-colors">
                {hotkey}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
};

export default ConnectionQuickAddMenu;
