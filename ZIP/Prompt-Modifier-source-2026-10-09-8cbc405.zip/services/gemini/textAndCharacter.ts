import { Type } from "@google/genai";
import { getModelForMode } from '../modelConfig';
import { createAIClient, callWithRetry } from './client';
import {
    isOpenAiTextModel,
    openAiEnhancePrompt,
    openAiSanitizePrompt,
    openAiEnhanceVideoPrompt,
    openAiAnalyzePrompt,
    openAiAnalyzeCharacter,
    openAiUpdateCharacterDescription,
    openAiUpdateCharacterSection,
    openAiUpdateCharacterPersonality,
    openAiModifyCharacter,
    openAiTranslateText,
    openAiGenerateScript,
    openAiGenerateCharacters,
    openAiTranslateScript,
    openAiModifyPromptSequence,
    openAiGenerateMultiviewPrompt
} from '../openaiService';
import { DEFAULT_MULTIVIEW_PROMPT } from './constants';

export const enhancePrompt = async (texts: string[], safePrompt: boolean, technicalPrompt: boolean, model: string = 'flash'): Promise<string> => {
    const targetModel = getModelForMode(model);
    if (isOpenAiTextModel(targetModel)) {
        return openAiEnhancePrompt(texts, safePrompt, technicalPrompt, targetModel);
    }

    return callWithRetry(async () => {
        const ai = createAIClient();
        const validTexts = texts.filter(text => text && text.trim() !== '');
        if (validTexts.length === 0) {
            return "High-quality masterpiece, 8k, detailed textures, cinematic lighting.";
        }

        const combinedDescription = validTexts.join(', ');

        const commercialSafetyInstruction = safePrompt
            ? `STRICT REQUIREMENT: Zero trademarked terms, brand names, or specific artist identities. Use generic descriptive artistic terminology only.`
            : '';

        let systemInstruction = '';

        if (technicalPrompt) {
            systemInstruction = `
        You are a technical prompt architect for generative AI imaging systems. 
        Your task is to aggregate the provided concepts into a singular, high-precision technical specification string.

        GUIDELINES:
        - Use structured technical language.
        - Specify precise attributes: [Subject topology], [Material properties/textures], [Physical lighting parameters], [Optical camera settings], [Render engine characteristics].
        - ABSOLUTELY NO flowery, poetic, or evocative adjectives (e.g., avoid "beautiful", "mysterious").
        - Combine all concepts into a cohesive, high-density technical instruction set.
        - ${commercialSafetyInstruction}
        - Output ONLY the final technical string. No introductions, no markdown blocks.
      `;
        } else {
            systemInstruction = `
        You are an expert prompt engineer for high-end AI image generation.
        Your goal is to transform the user's basic concepts into a rich, descriptive, and highly aesthetic image prompt.
        
        GUIDELINES:
        - Use evocative language and sensory details.
        - Describe lighting, mood, atmosphere, and artistic style in detail.
        - Ensure the output is a single, cohesive paragraph optimized for high-quality results.
        - ${commercialSafetyInstruction}
        - Output ONLY the enhanced prompt. No introductions, no markdown.
      `;
        }

        const prompt = `Concepts to process: ${combinedDescription}`;

        try {
            const response = await ai.models.generateContent({
                model: targetModel,
                contents: prompt,
                config: { systemInstruction }
            });
            return response.text || "";
        } catch (error: any) {
            console.error("Error processing prompt:", error);
            throw error;
        }
    });
};

export const sanitizePrompt = async (promptToSanitize: string): Promise<string> => {
    const targetModel = getModelForMode('flash');
    if (isOpenAiTextModel(targetModel)) {
        return openAiSanitizePrompt(promptToSanitize, targetModel);
    }

    return callWithRetry(async () => {
        const ai = createAIClient();
        if (!promptToSanitize || promptToSanitize.trim() === '') return "";

        const systemInstruction = `You are a prompt safety expert. Rewrite the user's prompt to be safer for image generation policies while preserving artistic intent. Replace age-specific terms (teenager, child) with neutral terms (young person, figure). Output only the sanitized prompt.`;

        try {
            const response = await ai.models.generateContent({
                model: targetModel,
                contents: `Sanitize: "${promptToSanitize}"`,
                config: { systemInstruction },
            });
            return response.text || "";
        } catch (error: any) {
            console.error("Error sanitizing prompt:", error);
            throw error;
        }
    });
};

export const enhanceVideoPrompt = async (texts: string[]): Promise<string> => {
    const targetModel = getModelForMode('flash');
    if (isOpenAiTextModel(targetModel)) {
        return openAiEnhanceVideoPrompt(texts, targetModel);
    }

    return callWithRetry(async () => {
        const ai = createAIClient();
        const validTexts = texts.filter(text => text && text.trim() !== '');
        if (validTexts.length === 0) return "A cinematic video, 4k, high resolution.";

        const combinedDescription = validTexts.join(', ');
        const prompt = `
      You are an expert video prompt engineer. Combine these concepts into a single, cohesive, detailed video prompt.
      Describe the scene, subjects, actions, camera movements, and lighting.
      Output only the prompt.
      
      Concepts: ${combinedDescription}
    `;

        try {
            const response = await ai.models.generateContent({
                model: targetModel,
                contents: prompt,
            });
            return response.text || "";
        } catch (error: any) {
            console.error("Error enhancing video prompt:", error);
            throw error;
        }
    });
};

export const analyzePrompt = async (text: string, softPrompt: boolean | undefined): Promise<{ environment: string; characters: string[]; action: string; emotion: string; style: string; }> => {
    const targetModel = getModelForMode('pro');
    if (isOpenAiTextModel(targetModel)) {
        return openAiAnalyzePrompt(text, softPrompt, targetModel);
    }

    return callWithRetry(async () => {
        const ai = createAIClient();
        if (!text || text.trim() === '') {
            throw new Error("Input prompt for analysis cannot be empty.");
        }

        const softPromptInstruction = softPrompt
            ? `Important: When analyzing, formulate descriptions to be as neutral and safe as possible. Avoid potentially sensitive, intimate, or age-specific terms (like 'teenager', 'boy', 'girl'). Instead, use more general, age-ambiguous descriptions (like 'young person', 'figure', 'youthful character') while preserving the core artistic details and intent.`
            : '';

        const prompt = `
      ${softPromptInstruction}
      You are a meticulous and detailed prompt analyzer. Your task is to analyze the following text and deconstruct it into five distinct, comprehensive components. Do not summarize or shorten the information; instead, extract and organize all relevant details for each component.

      1.  **Environment/Setting**: Extract a complete and detailed description of the environment, setting, or background. Include all mentioned elements, atmosphere, lighting, time of day, and any contextual details. Crucially, also include descriptions of any secondary, background, or non-focal characters here (e.g., 'a crowd of people in the distance', 'birds flying in the sky').
      
      2.  **Characters/Subjects**: Identify and list ONLY the key, main, or foreground characters/subjects. Do NOT include background, secondary, or minor characters in this list. 
          For each main character, extract a detailed **physical description only**. 
          CRITICAL: **Exclude** all descriptions of actions (e.g., running, fighting, sitting), poses, and the surrounding environment/background. 
          Focus strictly on physical appearance, facial features, body type, hair, clothing, armor, and equipment/held items. The goal is to describe the character purely as they look, as if they were a 3D model or concept art asset in isolation.
          IMPORTANT: Append ", grey background, character concept" to the end of each character description. For example, if the text says "a hero fighting a dragon in a cave", the character entry for the hero should be "a hero in shining armor, detailed face, muscular build, grey background, character concept" (removing 'fighting' and 'cave').

      3.  **Action**: Describe the action being performed by the main characters in full detail. Generalize the subjects by replacing specific character names or descriptions with neutral terms such as "the character(s)" or "the subject(s)". The description of the action itself must be comprehensive and include all associated details.
      
      4.  **Emotion**: Describe the emotion being expressed by the main character(s) in general terms, detached from the specific subjects. For example, 'The character(s) are experiencing joy,' 'The subject(s) show signs of fear,' or 'A sense of wonder is being conveyed.' If no emotion is explicitly mentioned, infer a plausible one from the context of the action and environment. Focus on the feeling itself.
      
      5.  **Style**: CRITICAL: Your description for this category MUST be completely detached from the specific subjects and environment of the prompt. Analyze and describe ONLY the artistic essence. Focus on abstract elements like: art medium (e.g., photorealistic, oil painting, 3D render, anime, watercolor), mood (e.g., mysterious, cheerful, epic, melancholic), color palette (e.g., vibrant warm tones, monochromatic cool colors, pastel), lighting style (e.g., dramatic, soft, neon, chiaroscuro), composition (e.g., close-up, wide shot, rule of thirds), and artistic techniques (e.g., impressionistic brush strokes, sharp focus, cel shading). Under NO circumstances should you mention any objects, people, or places from the scene in this section. For example, instead of "cinematic shot of a knight", say "cinematic, dramatic lighting, sharp focus".

      If any component is missing from the input text, you should infer and create a plausible and complementary description for it based on the available context. The goal is to produce a complete set of components that could be used to reconstruct a detailed image prompt.

      Provide the output strictly as a JSON object with the keys "environment", "characters", "action", "emotion", and "style".

      Text to analyze: ${text}
    `;

        const schema = {
            type: Type.OBJECT,
            properties: {
                environment: {
                    type: Type.STRING,
                    description: 'A detailed description of the background, setting, or environment.'
                },
                characters: {
                    type: Type.ARRAY,
                    description: 'A list of all distinct characters or subjects in the prompt.',
                    items: {
                        type: Type.STRING
                    }
                },
                action: {
                    type: Type.STRING,
                    description: 'A generalized description of the action the characters/subjects are performing, with specific subjects replaced by neutral terms.'
                },
                emotion: {
                    type: Type.STRING,
                    description: 'A generalized description of the emotion expressed by the character(s), such as joy, fear, or wonder.'
                },
                style: {
                    type: Type.STRING,
                    description: 'A detailed description of the art style, mood, and color palette.'
                }
            },
            required: ['environment', 'characters', 'action', 'emotion', 'style']
        };

        try {
            const response = await ai.models.generateContent({
                model: getModelForMode('pro'),
                contents: prompt,
                config: { responseMimeType: "application/json", responseSchema: schema },
            });

            const responseText = response.text;
            if (!responseText) {
                throw new Error("Received an empty response from the model. The prompt may have been blocked due to safety settings.");
            }

            const parsed = JSON.parse(responseText);
            if (!Array.isArray(parsed.characters)) parsed.characters = [String(parsed.characters || '')];
            return parsed;
        } catch (error: any) {
            console.error("Error analyzing prompt:", error);
            throw error;
        }
    });
};

export const analyzeCharacter = async (text: string): Promise<{ character: string; clothing: string; }> => {
    const targetModel = getModelForMode('flash');
    if (isOpenAiTextModel(targetModel)) {
        return openAiAnalyzeCharacter(text, targetModel);
    }

    return callWithRetry(async () => {
        const ai = createAIClient();
        if (!text || text.trim() === '') throw new Error("Input cannot be empty.");

        const prompt = `
      Analyze the character description. Split it into:
      1. character (physical features only)
      2. clothing (outfit only)
      Output JSON.
      Text: ${text}
    `;

        const schema = {
            type: Type.OBJECT,
            properties: {
                character: { type: Type.STRING },
                clothing: { type: Type.STRING }
            },
            required: ['character', 'clothing']
        };

        try {
            const response = await ai.models.generateContent({
                model: targetModel,
                contents: prompt,
                config: { responseMimeType: "application/json", responseSchema: schema },
            });
            return JSON.parse(response.text || "{}");
        } catch (error: any) {
            console.error("Error analyzing character:", error);
            throw error;
        }
    });
};

export const updateCharacterDescription = async (imagePrompt: string, currentFullDescription: string, targetLanguageName: string): Promise<string> => {
    const targetModel = getModelForMode('flash');
    if (isOpenAiTextModel(targetModel)) {
        return openAiUpdateCharacterDescription(imagePrompt, currentFullDescription, targetLanguageName, targetModel);
    }

    return callWithRetry(async () => {
        const ai = createAIClient();
        if (!imagePrompt || !imagePrompt.trim()) throw new Error("Image prompt is required.");

        const systemInstruction = `You are a character design expert. Your task is to update an existing character description based on a specific image generation prompt.
    
    INPUTS:
    1. Image Prompt: A description of a specific visual instance of the character.
    2. Current Description: A full markdown-formatted description of the character.

    GOAL:
    1. Rewrite the "Appearance" and "Clothing" sections of the description to match the details found in the Image Prompt.
    2. The "Personality" section must be preserved in meaning but TRANSLATED to ${targetLanguageName}.
    
    CRITICAL REQUIREMENT:
    The entire output (headers AND content) MUST be in the target language: ${targetLanguageName}.
    If the current description is in a different language, translate everything to ${targetLanguageName}.
    
    OUTPUT FORMAT:
    The output must be a single string in Markdown format, using the following headers in ${targetLanguageName}:
    - #### Appearance (translated header)
    - #### Personality (translated header)
    - #### Clothing (translated header)

    Output ONLY the updated description text.`;

        const contents = `Update this character description:
    
    IMAGE PROMPT:
    ${imagePrompt}
    
    CURRENT DESCRIPTION:
    ${currentFullDescription}`;

        try {
            const response = await ai.models.generateContent({
                model: targetModel,
                contents,
                config: { systemInstruction },
            });
            return response.text || "";
        } catch (error: any) {
            console.error("Error updating character description:", error);
            throw error;
        }
    });
};

export const updateCharacterSection = async (sectionName: string, imagePrompt: string, currentText: string, targetLanguageName: string): Promise<string> => {
    const targetModel = getModelForMode('flash');
    if (isOpenAiTextModel(targetModel)) {
        return openAiUpdateCharacterSection(sectionName, imagePrompt, currentText, targetLanguageName, targetModel);
    }

    return callWithRetry(async () => {
        const ai = createAIClient();

        const systemInstruction = `You are a creative writer and character designer. 
        Your task is to generate or rewrite the "${sectionName}" section of a character description based on an image generation prompt.
        
        INPUTS:
        1. Image Prompt: Visual details of the character.
        2. Current Section Text: The existing text for this section (if any).
        
        GOAL:
        - Analyze the Image Prompt to extract details relevant to "${sectionName}" (e.g. physical features for Appearance, outfit for Clothing).
        - Rewrite the section text to be descriptive, cohesive, and aligned with the visual prompt.
        - Output strictly in the target language: ${targetLanguageName}.
        
        Output ONLY the new text for the section. Do not include headers.`;

        const contents = `IMAGE PROMPT:
        ${imagePrompt}
        
        CURRENT SECTION TEXT:
        ${currentText}`;

        try {
            const response = await ai.models.generateContent({
                model: targetModel,
                contents,
                config: { systemInstruction },
            });
            return response.text || "";
        } catch (error: any) {
            console.error(`Error updating character ${sectionName}:`, error);
            throw error;
        }
    });
};

export const updateCharacterPersonality = async (currentPersonality: string, targetLanguageName: string): Promise<string> => {
    const targetModel = getModelForMode('flash');
    if (isOpenAiTextModel(targetModel)) {
        return openAiUpdateCharacterPersonality(currentPersonality, targetLanguageName, targetModel);
    }

    return callWithRetry(async () => {
        const ai = createAIClient();

        const systemInstruction = `You are a creative writer and character designer. 
        Your task is to rewrite or improve the provided character personality description.
        The input may contain the current personality text AND a user request for changes mixed together.
        
        GOAL:
        1. Extract the core personality traits and the user's modification request (if any).
        2. Rewrite the personality description to incorporate the requested changes or simply improve the writing style if no specific change is requested.
        3. The output should be a cohesive, well-written paragraph describing the character's personality.
        4. Output strictly in the target language: ${targetLanguageName}.
        
        Output ONLY the new personality text. Do not include headers.`;

        const contents = `Current Personality / Request:
        ${currentPersonality}`;

        try {
            const response = await ai.models.generateContent({
                model: targetModel,
                contents,
                config: { systemInstruction },
            });
            return response.text || "";
        } catch (error: any) {
            console.error("Error updating character personality:", error);
            throw error;
        }
    });
};

export const modifyCharacter = async (instruction: string, currentPrompt: string, currentDescription: string, targetLanguageName: string): Promise<{ newPrompt: string, newDescription: string }> => {
    const targetModel = getModelForMode('pro');
    if (isOpenAiTextModel(targetModel)) {
        return openAiModifyCharacter(instruction, currentPrompt, currentDescription, targetLanguageName, targetModel);
    }

    return callWithRetry(async () => {
        const ai = createAIClient();

        const systemInstruction = `You are a professional character concept artist.
    Your goal is to modify an existing character based on a user instruction.
    
    INPUTS:
    1. Instruction: What to change (e.g., "Change her clothes to a space suit").
    2. Current Image Prompt: The current short prompt used for image generation.
    3. Current Full Description: The detailed markdown description.

    TASK:
    - Update the Image Prompt to reflect the changes.
    - Update the Full Description (sections Appearance, Personality and Clothing) in ${targetLanguageName}.
    - Ensure all sections are consistent with the new instruction.
    - Output only a JSON object with keys 'newPrompt' and 'newDescription'.`;

        const schema = {
            type: Type.OBJECT,
            properties: {
                newPrompt: { type: Type.STRING },
                newDescription: { type: Type.STRING }
            },
            required: ['newPrompt', 'newDescription']
        };

        const contents = `INSTRUCTION: ${instruction}\nCURRENT PROMPT: ${currentPrompt}\nCURRENT DESCRIPTION: ${currentDescription}`;

        try {
            const response = await ai.models.generateContent({
                model: targetModel,
                contents,
                config: { systemInstruction, responseMimeType: "application/json", responseSchema: schema },
            });
            return JSON.parse(response.text || "{}");
        } catch (error: any) {
            console.error("Error modifying character:", error);
            throw error;
        }
    });
};

export const translateText = async (text: string, targetLanguageName: string, model: string = 'flash'): Promise<string> => {
    const targetModel = getModelForMode(model);
    if (isOpenAiTextModel(targetModel)) {
        return openAiTranslateText(text, targetLanguageName, targetModel);
    }

    return callWithRetry(async () => {
        const ai = createAIClient();
        if (!text || text.trim() === '') throw new Error("Input empty.");

        try {
            const response = await ai.models.generateContent({
                model: targetModel,
                contents: text,
                config: { systemInstruction: `Translate to ${targetLanguageName}. Return only translated text.` },
            });
            return response.text || "";
        } catch (error: any) {
            console.error("Error translating:", error);
            throw error;
        }
    });
};

export const generateScript = async (prompt: string, targetLanguageName: string): Promise<any> => {
    const targetModel = getModelForMode('pro');
    if (isOpenAiTextModel(targetModel)) {
        return openAiGenerateScript(prompt, targetLanguageName, targetModel);
    }

    return callWithRetry(async () => {
        const ai = createAIClient();
        const schema = {
            type: Type.OBJECT,
            properties: {
                summary: { type: Type.STRING },
                detailedCharacters: {
                    type: Type.ARRAY,
                    items: { type: Type.OBJECT, properties: { name: { type: Type.STRING }, fullDescription: { type: Type.STRING } } }
                },
                scenes: {
                    type: Type.ARRAY,
                    items: { type: Type.OBJECT, properties: { sceneNumber: { type: Type.INTEGER }, description: { type: Type.STRING }, narratorText: { type: Type.STRING } } }
                }
            },
            required: ['summary', 'detailedCharacters', 'scenes']
        };

        try {
            const response = await ai.models.generateContent({
                model: targetModel,
                contents: prompt,
                config: {
                    systemInstruction: `Generate a script structure in ${targetLanguageName}. Use markdown in fullDescription.`,
                    responseMimeType: "application/json",
                    responseSchema: schema
                },
            });
            return JSON.parse(response.text || "{}");
        } catch (error: any) {
            console.error("Error generating script:", error);
            throw error;
        }
    });
};

export const generateCharacters = async (prompt: string): Promise<any[]> => {
    const targetModel = getModelForMode('flash');
    if (isOpenAiTextModel(targetModel)) {
        return openAiGenerateCharacters(prompt, targetModel);
    }

    return callWithRetry(async () => {
        const ai = createAIClient();
        const schema = {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING },
                    index: { type: Type.STRING },
                    imagePrompt: { type: Type.STRING },
                    fullDescription: { type: Type.STRING }
                },
                required: ['name', 'fullDescription', 'index', 'imagePrompt']
            }
        };

        try {
            const response = await ai.models.generateContent({
                model: targetModel,
                contents: prompt,
                config: {
                    systemInstruction: "Generate detailed characters. Use markdown headings in fullDescription. Ensure 'index' is provided (e.g. 'Entity-1', 'Entity-2').",
                    responseMimeType: "application/json",
                    responseSchema: schema
                },
            });
            return JSON.parse(response.text || "[]");
        } catch (error: any) {
            console.error("Error generating characters:", error);
            throw error;
        }
    });
};

export const translateScript = async (script: any, targetLanguageName: string): Promise<any> => {
    const targetModel = getModelForMode('pro');
    if (isOpenAiTextModel(targetModel)) {
        return openAiTranslateScript(script, targetLanguageName, targetModel);
    }

    return callWithRetry(async () => {
        const ai = createAIClient();
        const systemInstruction = `Translate user-facing fields to ${targetLanguageName}. Preserve structure and markdown.`;

        try {
            const response = await ai.models.generateContent({
                model: targetModel,
                contents: `Translate:\n${JSON.stringify(script)}`,
                config: { systemInstruction, responseMimeType: "application/json" }
            });
            return JSON.parse(response.text || "{}");
        } catch (error: any) {
            throw new Error(error.message);
        }
    });
};

export const modifyPromptSequence = async (
    prompts: any[],
    instruction: string,
    targetLanguage: string = 'en',
    modelName: string = 'flash',
    includeVideoPrompts: boolean = false,
    sceneContexts: Record<string, string> = {}
): Promise<{ modifiedFrames: any[], modifiedSceneContexts: { sceneNumber: number, context: string }[] }> => {
    const targetModel = getModelForMode(modelName);
    if (isOpenAiTextModel(targetModel)) {
        return openAiModifyPromptSequence(prompts, instruction, targetLanguage, targetModel, includeVideoPrompts, sceneContexts);
    }

    return callWithRetry(async () => {
        const ai = createAIClient();
        const schema = {
            type: Type.OBJECT,
            properties: {
                modifiedFrames: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            frameNumber: { type: Type.INTEGER },
                            sceneNumber: { type: Type.INTEGER },
                            prompt: { type: Type.STRING },
                            videoPrompt: { type: Type.STRING },
                            shotType: { type: Type.STRING, description: 'The type of shot (e.g., WS, CU, ECU, LS, MS).' },
                            characters: { type: Type.ARRAY, items: { type: Type.STRING } },
                            duration: { type: Type.INTEGER }
                        },
                        required: ['frameNumber', 'sceneNumber', 'prompt', 'characters', 'duration', 'shotType', ...(includeVideoPrompts ? ['videoPrompt'] : [])]
                    }
                },
                modifiedSceneContexts: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            sceneNumber: { type: Type.INTEGER },
                            context: { type: Type.STRING, description: 'The updated scene context description.' }
                        },
                        required: ['sceneNumber', 'context']
                    }
                }
            },
            required: ['modifiedFrames']
        };

        const languageInstruction = targetLanguage === 'ru'
            ? 'Ensure the response fields (like prompts and context) are in Russian.'
            : 'Ensure the response fields (like prompts and context) are in English.';

        let videoInstruction = "";
        if (includeVideoPrompts) {
            videoInstruction = `
        CRITICAL: You MUST also generate or modify the 'videoPrompt' field for every frame.
        - If 'videoPrompt' is empty or missing in the source: Generate a NEW video prompt based on the image 'prompt'. It MUST describe specific actions happening in the frame and camera movements (e.g., "Camera pans left", "Zoom in").
        - If 'videoPrompt' exists: Modify it according to the user's instruction, while maintaining consistency with the image 'prompt'.
        `;
        }

        let contextInstruction = "";
        if (Object.keys(sceneContexts).length > 0) {
            contextInstruction = `
        **SCENE CONTEXT**:
        The input data includes "sceneContexts". This dictionary maps scene numbers to context descriptions.
        
        TASK:
        1. Apply the user's instruction to the frames.
        2. IF the instruction implies changing the overall setting, mood, or context of a scene (e.g., "Change the weather to snow", "Make it night time"), YOU MUST ALSO MODIFY the Scene Context text for that scene.
        3. Return the updated scene contexts in the 'modifiedSceneContexts' array. Only include contexts that have changed or are relevant to the modified frames.
        
        Context Data: ${JSON.stringify(sceneContexts)}
        `;
        }

        try {
            const response = await ai.models.generateContent({
                model: targetModel,
                contents: `Instruction: ${instruction}\n${contextInstruction}\nData: ${JSON.stringify(prompts)}`,
                config: {
                    systemInstruction: `Modify prompts based on instruction. Return a structured object with modified frames and modified scene contexts. ${languageInstruction} ${videoInstruction} For every frame, you MUST either preserve or generate a logical 'shotType' value (e.g., WS, MS, CU, etc.) representing the camera angle. Also, always ensure to return the correct 'sceneNumber' for each frame corresponding to the source.`,
                    responseMimeType: "application/json",
                    responseSchema: schema
                },
            });

            const parsed = JSON.parse(response.text || "{}");
            return {
                modifiedFrames: parsed.modifiedFrames || [],
                modifiedSceneContexts: parsed.modifiedSceneContexts || []
            };

        } catch (error: any) {
            console.error("Error modifying sequence:", error);
            throw error;
        }
    });
};

export const generateMultiviewTurnaroundPrompt = async (
    image: { base64ImageData: string; mimeType: string } | null,
    prompt: string,
    model: string = 'flash'
): Promise<string> => {
    const targetModel = getModelForMode(model);
    if (isOpenAiTextModel(targetModel)) {
        return openAiGenerateMultiviewPrompt(image, prompt || DEFAULT_MULTIVIEW_PROMPT, targetModel);
    }

    return callWithRetry(async () => {
        const ai = createAIClient();
        const parts: any[] = [];
        if (image && image.base64ImageData) {
            parts.push({
                inlineData: {
                    data: image.base64ImageData,
                    mimeType: image.mimeType || 'image/png'
                }
            });
        }
        parts.push({
            text: prompt && prompt.trim() ? prompt : DEFAULT_MULTIVIEW_PROMPT
        });

        try {
            const response = await ai.models.generateContent({
                model: targetModel,
                contents: { parts }
            });
            return response.text || "";
        } catch (error: any) {
            console.error("Error generating multiview turnaround prompt:", error);
            throw error;
        }
    });
};
